package main

func main(){i:=2
	print(i)
}
