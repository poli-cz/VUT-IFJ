package main

func main(){
	int
	a = 2
	print(a)
}
