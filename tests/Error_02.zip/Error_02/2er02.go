package main

func main(){
	for a:=1;
	a<2;a++
	print(a)
}
