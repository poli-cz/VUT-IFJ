package main

func main(){
	i := 2
	for ;i!=3;i++;{
		print(i)
	}	
}
