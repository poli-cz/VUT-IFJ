package main

func main(){
	i := 2
	if .{
		print(i)
	}else{
		print("nic")
	}
}
