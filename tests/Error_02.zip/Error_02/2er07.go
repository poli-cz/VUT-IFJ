package main

func main(){
	i := 2
	if i == 2;{
		print(i)
	}else{
		print("Nic")
	}
}
