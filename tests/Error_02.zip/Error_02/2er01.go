package main

func 
main(){
	a := 1
	print(a)	
}
