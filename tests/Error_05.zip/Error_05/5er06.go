package main

func main(){
	i := 2
	for;i <> 4;i++{
		print(i)
	}
}

