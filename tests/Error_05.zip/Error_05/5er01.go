package main

func main(){
	i := 1++2
	print(i)
}
