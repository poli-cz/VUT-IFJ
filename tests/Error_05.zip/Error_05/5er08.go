package main

func main(){
	i := 2 -+ 1
	print(i)
}

