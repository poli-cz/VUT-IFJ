package main

func main(){
	i := 1 = 4
	print(i)
}

