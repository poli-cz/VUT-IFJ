package main

func main(){
	i := 3
	for;i+2;i++{
		print(i)
	}
}

