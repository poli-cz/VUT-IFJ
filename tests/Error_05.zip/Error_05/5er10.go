package main

func main(){
	i := 3
	for; i<=>5; i--{
		print(i)
	}
}

