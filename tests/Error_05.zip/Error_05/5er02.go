package main

func main(){
	i := 2w2 - 1
	print(i)
}

