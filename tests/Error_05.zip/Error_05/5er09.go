package main

func main(){
	i := 1004e2r + 2
	print(i)
}

