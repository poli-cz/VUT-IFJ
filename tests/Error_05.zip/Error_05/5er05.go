package main

func main(){
	s1 := "\m"
	s2 := "Text"
	print(s1, "\n", s2)
}

