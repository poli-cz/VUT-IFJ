package main

func main(){
	i := 3 + r2
	print(i)
}

