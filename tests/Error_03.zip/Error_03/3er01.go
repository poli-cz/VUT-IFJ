package main

func main(){
	a := 0
	a := 0
	print(a)
}

