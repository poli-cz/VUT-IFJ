package main

func main(){
	vysl := 0
	a := 2
	vysl = suma(a)
}

