package main

func main(){
	a := 2
	if ;a<5;a++{
		s := 2
		s := 2
		print(a)
		print(s)
	}else{
		print("Nothing")
	}
}

