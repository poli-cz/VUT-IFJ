package main

func main(){
	vysl := 2
	print(vysl)
}

func number(){
}

