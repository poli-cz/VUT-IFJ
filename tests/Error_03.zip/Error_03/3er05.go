package main

func number(){
}

func main(){
	vysl := 2
	print(vysl)
}

