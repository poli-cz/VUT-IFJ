package main

func main{
	a := 1
	vysledek(a)
}

func vysledek(a string)(a int){
	b := a+1
	return b
}

