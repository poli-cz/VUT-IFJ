package main

func main{
	a:=6
	b:="str"
	vysledek(a,b)
}

func vysledek(a int, b float)(string){
	return a+b
}
