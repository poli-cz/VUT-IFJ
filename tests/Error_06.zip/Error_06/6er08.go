package main

func main{
	a:=1
	b:=2
	vysledek(a,b)
}

func vysledek(float a. float b)(int){
	return a+b
}
