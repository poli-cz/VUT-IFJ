package main

func main{
	a := 2
	vypocet(a)
}

func vypocet(a int)(string){
	b := a+1
	return b
}

