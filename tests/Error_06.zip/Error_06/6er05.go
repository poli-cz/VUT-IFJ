package main

func main{
	a := 1
	b := 2
	vysledek(a,b)
}

func vysledek(a int)(int){
	c:= a+1
	return c
}

