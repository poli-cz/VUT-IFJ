package main

func main{
	a:=1
	b:=2
	vysledek(a,b)
}

func vysledek(a int, c int)(int){
	return a+b
}
