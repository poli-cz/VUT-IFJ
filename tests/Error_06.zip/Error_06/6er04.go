package main

func main{
	a := 1
	vysledek(a)
}

func vysledek(a float)(string){
	b := a-2
	return b 
}

