/**
 * File is part of project IFJ2018.
 *
 * Brno University of Technology, Faculty of Information Technology
 *
 * @package IFJ2018
 * @authors
 */

#include <assert.h>
#include "list.h"
#include "m_manage.h"

List* init_list(free_data free_data) {
    List* l;
    l = (List*) mm_malloc(sizeof(List));
    
    l->first_one = NULL;
    l->last_one = NULL;
    l->active = NULL;
    l->free_data = free_data;
    
    return l;
}

void free_list(List *l) {
    assert(l != NULL);
    
    activate_first_list(l);
    while (active_list(l)) {
        if (l->free_data != NULL) {
            l->free_data(delete_and_succ_list(l));
        } else {
            delete_and_succ_list(l);
        }
    }
    
    mm_free(l);
}

List* copy_list(List *l) {
    assert(l != NULL);
    
    List *l_copied = init_list(l->free_data);
    
    activate_first_list(l);
    if (active_list(l)) {
        insert_first_list(l_copied, get_active_list(l));
        succ_list(l);
        while (active_list(l)) {
            insert_last_list(l_copied, get_active_list(l));
            succ_list(l);
        }
    }
    return l_copied;
}

void insert_first_list(List *l, void *data) {
    assert(l != NULL);
    
    ListItem* new;
    new = (ListItem*) mm_malloc(sizeof(ListItem));
    
    new->data = data;
    new->prev_one = NULL;
    
    if (l->first_one == NULL) {
        new->next_one = NULL;
        l->last_one = new;
    } else {
        new->next_one = l->first_one;
        l->first_one->prev_one = new;
    }
    
    l->first_one = new;
}

void insert_last_list(List *l, void *data) {
    assert(l != NULL);
    
    ListItem* new;
    new = (ListItem*) mm_malloc(sizeof(ListItem));
    
    new->data = data;
    new->next_one = NULL;
    
    if (l->last_one == NULL) {
        new->prev_one = NULL;
        l->first_one = new;
    } else {
        new->prev_one = l->last_one;
        l->last_one->next_one = new;
    }
    
    l->last_one = new;
}

void post_insert_list(List *l, void *data) {
    assert(l != NULL);
    
    if (l->active == NULL)
        return;
    
    ListItem* new;
    new = (ListItem*) mm_malloc(sizeof(ListItem));
    
    new->data = data;
    new->next_one = l->active->next_one;
    new->prev_one = l->active;
    
    if (l->active->next_one == NULL) {
        l->last_one = new;
    } else {
        l->active->next_one->prev_one = new;
    }
    
    l->active->next_one = new;
}

void pre_insert_list(List *l, void *data) {
    assert(l != NULL);
    
    if (l->active == NULL)
        return;
    
    ListItem* new;
    new = (ListItem*) mm_malloc(sizeof(ListItem));
    
    new->data = data;
    new->next_one = l->active;
    new->prev_one = l->active->prev_one;
    
    if (l->active->prev_one == NULL) {
        l->first_one = new;
    } else {
        l->active->prev_one->next_one = new;
    }
    
    l->active->prev_one = new;
}

bool empty_list(List *l) {
    assert(l != NULL);
    
    return l->first_one == NULL;
}

bool active_list(List *l) {
    assert(l != NULL);
    
    return l->active != NULL;
}

void* get_active_list(List *l) {
    assert(l != NULL);
    
    if (l->active == NULL)
        return NULL;
    
    return l->active->data;
}

void* get_first_list(List *l) {
    assert(l != NULL);
    
    if (l->first_one == NULL)
        return NULL;
    
    return l->first_one->data;
}

void* get_last_list(List *l) {
    assert(l != NULL);
    
    if (l->last_one == NULL)
        return NULL;
    
    return l->last_one->data;
}

void* delete_first_list(List *l) {
    assert(l != NULL);
    
    if (l->first_one == NULL)
        return NULL;
    
    if (l->first_one == l->active)
        l->active = NULL;
    
    void* data;
    data = l->first_one->data;
    ListItem* deleted;
    deleted = l->first_one;
    l->first_one = l->first_one->next_one;
    
    if (l->first_one == NULL)
        l->last_one = NULL;
    else
        l->first_one->prev_one = NULL;
    
    mm_free(deleted);
    return data;
}

void* delete_last_list(List *l) {
    assert(l != NULL);
    
    if (l->last_one == NULL)
        return NULL;
    
    if (l->last_one == l->active)
        l->active = NULL;
    
    void* data;
    data = l->last_one->data;
    ListItem* deleted;
    deleted = l->last_one;
    l->last_one = l->last_one->prev_one;
    
    if (l->last_one == NULL)
        l->first_one = NULL;
    else
        l->last_one->next_one = NULL;
    
    mm_free(deleted);
    return data;
}

void* delete_and_succ_list(List *l) {
    assert(l != NULL);
    
    if (l->active == NULL)
        return NULL;
    
    void* data;
    data = l->active->data;
    ListItem* deleted;
    deleted = l->active;
    
    if (l->first_one == l->active) {
        l->first_one = l->active->next_one;
        
        if (l->first_one != NULL) {
            l->first_one->prev_one = NULL;
        }
    }
    
    if (l->last_one == l->active) {
        l->last_one = l->active->prev_one;
        
        if (l->last_one != NULL) {
            l->last_one->next_one = NULL;
        }
    }
    
    if (l->active->prev_one != NULL)
        l->active->prev_one->next_one = l->active->next_one;
    if (l->active->next_one != NULL)
        l->active->next_one->prev_one = l->active->prev_one;
    
    l->active = l->active->next_one;
    
    mm_free(deleted);
    return data;
}

void* delete_and_pred_list(List *l) {
    assert(l != NULL);
    
    if (l->active == NULL)
        return NULL;
    
    void* data;
    data = l->active->data;
    ListItem* deleted;
    deleted = l->active;
    
    if (l->first_one == l->active) {
        l->first_one = l->active->next_one;
        
        if (l->first_one != NULL) {
            l->first_one->prev_one = NULL;
        }
    }
    
    if (l->last_one == l->active) {
        l->last_one = l->active->prev_one;
        
        if (l->last_one != NULL) {
            l->last_one->next_one = NULL;
        }
    }
    
    if (l->active->prev_one != NULL)
        l->active->prev_one->next_one = l->active->next_one;
    if (l->active->next_one != NULL)
        l->active->next_one->prev_one = l->active->prev_one;
    
    l->active = l->active->prev_one;
    
    mm_free(deleted);
    return data;
}

void* update_list(List *l, void* data) {
    assert(l != NULL);
    
    if (l->active == NULL)
        return NULL;
    
    void* old_one;
    old_one = l->active->data;
    l->active->data = data;
    return old_one;
}

void activate_first_list(List *l) {
    assert(l != NULL);
    
    l->active = l->first_one;
}

void activate_last_list(List *l) {
    assert(l != NULL);
    
    l->active = l->last_one;
}

void succ_list(List *l) {
    assert(l != NULL);
    
    l->active = l->active->next_one;
}

void pred_list(List *l) {
    assert(l != NULL);
    
    l->active = l->active->prev_one;
}

int length_list(List *l) {
    assert(l != NULL);
    
    int length = 0;
    activate_first_list(l);
    while (active_list(l)) {
        length++;
        succ_list(l);
    }
    
    return length;
}

void debug_list(void* l, debug_func func) {
    List* list = (List*) l;
    
    debug("List@%p: {\n", list);
    activate_first_list(list);
    while (active_list(list)) {
        debugs("\t");
        func(get_active_list(list));
        debugs("\n");
        succ_list(list);
    }
    debugs("}\n\n");
}
