/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Header file for m_manage.c
 *
 * @author Viktória Halečková xhalec00
 */
#ifndef _M_MANAGE_
#define _M_MANAGE_
#include <stdio.h>


/**
 * Štruktúra Memory Manage
 */
typedef struct MMNode{

  void *pointer;
  struct MMNode *next_one;

}tMMNode;

/**
 * Alokácia pamäte danej veľkosti
 * @param s veľkosť
 */
void *mm_malloc(int s);

/**
 * Vyčistí pamäť
 * @param f0 súbor
 * @param f1 súbor
 */
void clear_memory(FILE *f0, FILE *f1);

/**
 * Uvoľní pamäť kam ukazuje pointer
 * @param pointer Ukazateľ
 */
void mm_free(void * pointer);

/**
 * Realokuje pamäť pointera na danú veľkosť
 * @param pointer Ukazateľ
 * @param s veľkosť
 */
void *mm_realloc(void *pointer, size_t s);

#endif
