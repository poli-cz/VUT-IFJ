/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Types
 *
 * @author Peter Dragúň xdragu01
 */

#include "types.h"

void inst_fill(List* il,op_enum op,char*pref1,char *var1,char*pref2,char *var2,char*pref3,char *var3){
  Ad ad1,ad2,ad3;
  if ((var1==NULL)||(pref1 == NULL)) {
    ad1.t = AD_T_E;
    ad1.s = NULL;
  }else{
    ad1 = ad_for_symbol(pref1,var1);
  }
  if ((var2==NULL)||(pref2 == NULL)) {
    ad2.t = AD_T_E;
    ad2.s = NULL;
  }else{
    ad2 = ad_for_symbol(pref2,var2);
  }
  if ((var2==NULL)||(pref2 == NULL)) {
    ad3.t = AD_T_E;
    ad3.s = NULL;
  }else{
    ad3 = ad_for_symbol(pref3,var3);
  }
  Ins* i = init_ins(op,ad1,ad2,ad3);
  add_to_il(il, i);
}

int int2double_convert (List *l,st_item **item1, st_item **item2){
  char *u_id = gen_u();
  if (((*item1)->d_type == T_INT)&&((*item2)->d_type == T_FLOAT)) {
    inst_fill(l,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
    inst_fill(l,OP_INT2FLOAT, "LF@", u_id, "LF@", (*item1)->var_n,NULL,NULL);
    (*item1)->var_n=u_id;
  }else if (((*item1)->d_type == T_FLOAT)&&((*item2)->d_type == T_INT)) {
    inst_fill(l,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
    inst_fill(l,OP_INT2FLOAT, "LF@", u_id, "LF@", (*item2)->var_n,NULL,NULL);
    (*item2)->var_n=u_id;
  }else{//chyba vysledok porovnania bude nil
    return TYPE_ERROR;
  }
  return SUCC;
}


st_item *type_control(List *l,st_item *item1, st_item *item2, stToken *op){
  int err_n = 0;
  st_item *vys =  s_item_init();

  if ((op->type == MINUS)||(op->type == MUL)) {
    if (item1->d_type == item2->d_type) {
      if (item1->d_type != T_STRING) {
        vys->d_type = item1->d_type;
        char *u_id=gen_u();
        inst_fill(l,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        if (op->type == MINUS) {
          inst_fill(l,OP_SUB, "LF@", u_id,NULL,NULL,NULL,NULL);
        }else{
          inst_fill(l,OP_MUL, "LF@", u_id,NULL,NULL,NULL,NULL);
        }
        vys->var_n = u_id;
      }else{
        return NULL;
        //odpocitavanie a nasobenie string nie je dovolene
      }
    }else{//rozny type
      err_n = int2double_convert(l,&item1,&item2);
      if (err_n!=0) {
        return NULL;
      }
      vys->d_type = T_FLOAT;
      char *u_id=gen_u();
      inst_fill(l,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
      if (op->type == MINUS) {
        inst_fill(l,OP_SUB, "LF@", u_id,NULL,NULL,NULL,NULL);
      }else{
        inst_fill(l,OP_MUL, "LF@", u_id,NULL,NULL,NULL,NULL);
      }
      vys->var_n = u_id;
    }
  }else if (op->type == PLUS) {
    if (item1->d_type == item2->d_type) {
      char *u_id=gen_u();
      inst_fill(l,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
      if (item1->d_type == T_STRING) {
        inst_fill(l,OP_CONCAT, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      }else{
        inst_fill(l,OP_ADD, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      }
      return vys;
    }else{
      err_n = int2double_convert(l,&item1,&item2);
      if (err_n!=0) {
        return NULL;
      }
      vys->d_type = T_FLOAT;
      char *u_id=gen_u();
      inst_fill(l,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_ADD, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      return vys;
    }
  }else if (op->type == DIV){
    vys->d_type = T_FLOAT;
    if (item1->d_type == item2->d_type) {
      if (item1->d_type == T_FLOAT) {
        char *u_id=gen_u();
        inst_fill(l,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_DIV, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
        vys->var_n = u_id;
      }else if (item1->d_type == T_INT) {
        char *u_id=gen_u();
        inst_fill(l,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_DIV, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        vys->var_n = u_id;
        return vys;
      }
    }else {//rozdielne typy
      err_n = int2double_convert(l,&item1,&item2);
      if (err_n!=0) {
        return NULL;
      }
      char *u_id=gen_u();
      inst_fill(l,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_DIV, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      vys->var_n = u_id;
    }
    return vys;
  }else if(!strcmp(op->value->str, "<")||!strcmp(op->value->str, ">")||!strcmp(op->value->str, "<=")||!strcmp(op->value->str, ">=")||!strcmp(op->value->str, "!=")||!strcmp(op->value->str, "==")){
    if (item1->d_type != item2->d_type) {
      err_n = int2double_convert(l,&item1,&item2);
      if (err_n!=0) {
        return NULL;
      }
    }
    char *u_id=gen_u();
    inst_fill(l,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
    vys->d_type = T_BOOL;
    vys->var_n = u_id;
    if(!strcmp(op->value->str, "<")){//<
      inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
    } else if (!strcmp(op->value->str, ">")) {//>
      inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
    } else if (!strcmp(op->value->str, ">=")) {//> or =
      inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
      char *u_id1=gen_u();
      inst_fill(l,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
      inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
    } else if (!strcmp(op->value->str, "<=")) {//< or =
      inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
      char *u_id1=gen_u();
      inst_fill(l,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
      inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
    } else if (!strcmp(op->value->str, "==")) {//=
      inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
    } else if (!strcmp(op->value->str, "!=")) {//not =
      inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
      inst_fill(l,OP_NOT, "LF@", u_id,  "LF@", u_id,NULL,NULL);
    }
    return vys;
  }else {
    return NULL;
  }
  return NULL;
}



st_item *s_item_init(){
  st_item *temp = (st_item *) mm_malloc(sizeof(st_item));
  temp->t = T_EXPR;
  temp->d_type = T_ELSE;
  temp->tok = NULL;
  temp->isTerm = false;
  temp->var_n = NULL;
  return temp;
}
