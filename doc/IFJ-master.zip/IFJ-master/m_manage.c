/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief File m_manage
 *
 * @author Viktória Halečková xhalec00
 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "m_manage.h"

tMMNode *m_manage_list;
void *mm_malloc(int s){
  tMMNode *temp = malloc(sizeof(tMMNode));
  tMMNode **next_one = &m_manage_list;
  if (temp == NULL) {
    clear_memory(NULL,NULL);
    exit(99);
  }
  void *Pointer = malloc(s);
  if (Pointer == NULL){
    free(temp);
    clear_memory(NULL,NULL);
    exit(99);
  }

  temp->pointer = Pointer;
  if ((*next_one) != NULL){
      temp->next_one = (*next_one);
      (*next_one) = temp;
      return Pointer;
  }
  else{
      (*next_one) = temp;
      return Pointer;
  }

}

void clear_memory(FILE *f0,FILE *f1){
  if (f0!=NULL && f0!=stdin)
    fclose(f0);
  if (f1!=NULL && f1!=stdin)
    fclose(f1);
  while (m_manage_list != NULL) {
      tMMNode *delete = m_manage_list;
      m_manage_list = (m_manage_list)->next_one;
      if ((delete->pointer)!=NULL)
          free(delete->pointer);
      free(delete);
  }

}

void mm_free(void *pointer){
    tMMNode **temp = &m_manage_list;
    while ((*temp) != NULL){
        if (((*temp)->pointer) == pointer)
            break;
        (*temp) = (*temp)->next_one;
    }
    if ((*temp) ==  NULL)
        return;
    void *ptr=(*temp)->pointer;
    if (pointer!=NULL)
        free(ptr);
    (*temp)->pointer=NULL;
    return;

}

void *mm_realloc(void * pointer, size_t s){
    tMMNode **temp = &(m_manage_list);
    while((*temp) != NULL){
        if ((*temp)->pointer == pointer){
            pointer = realloc(pointer,s);
            if (pointer == NULL)
                if (s > 0) {
                    exit(99);
                    clear_memory(NULL,NULL);
                }
            (*temp)->pointer = pointer;
            return pointer;
        }
        (*temp) = (*temp)->next_one;
    }
    return pointer;
    
}
