/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Inbuild Functions
 *
 * @author Patricia Ramosova xramos00
 */

#include "three_adress_code.h"


#ifndef IFJ18_COMPILER_INBUILD_FCE_H
#define IFJ18_COMPILER_INBUILD_FCE_H

/**
 * Vypise vstavane funkcie na standardny vystup v instrukciach ifjcode18
 */
void create_inbuildFce();


#endif 