/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Parser
 *
 * @author Peter Dragúň xdragu01
 *         Jakub Sadílek xsadil07
 */
#include "parser.h"


#define GET_TOKEN  delete_token(tok); create_token(&tok); if(get_token(tok)==1){ fprintf(stderr,"Chyba pri nacitani tokenu\n"); return LEX_ERROR;}
#define SERROR(exp) fprintf(stderr,"SYNTAX ERROR on line %d : Expecting %s\n",line,exp); return(SYNTH_ERROR);
#define SEMERROR(exp,err) fprintf(stderr,"SEMANTIC ERROR on line %d : %s\n",line,exp); return(err);


globalTable *gtab;

int u_cnt = 0;//pre generovanie unikatnych premennych
stToken *tok;// -globalna premenna
int line = 1;//riadok v subore pre error nepocita riadky s blokovym komentarom resp. pocita za 1 riadok

char *gen_u(){
  char id[10] = {0};
  char *ptr = (char *) mm_malloc(11*sizeof(char));
  sprintf(id, "%d", u_cnt);
  u_cnt++;
  strcpy(ptr,"$");
  strcat(ptr, id);
  return ptr;
}

int check_sem_ud(char *name, struct parameter *p){
  struct global_symbol *f = global_Search (gtab, name);
  if (f->isDefined == false)
    return 0;
  while (f->par != NULL){
    if (p->type != f->par->type){
      fprintf(stderr, "Spatny datovy typ argumentu funkce!\n");
      return SEM_ERROR;
    }
    p = p->next;
    f->par = f->par->next;
  }
  return 0;
}

int del_e_line(){//zmaze prazdne riadky
  while (tok->type == EOL) {
    GET_TOKEN;
    line++;
  }
  return SUCC;//pre kontrolu lexikalnej analyzy
}

int prog(){
  int err_n = 0;//ERROR NUMBER
  localTable *ltab;
  inst_fill(main_il,OP_CREATEFRAME, NULL, NULL, NULL,NULL, NULL, NULL);
  inst_fill(main_il,OP_PUSHFRAME, NULL, NULL, NULL,NULL, NULL, NULL);
  ltab = mm_malloc(sizeof(localTable));
  local_Init(ltab);
  del_e_line();
  if (tok->type == END) {//pre pripad prazdneho suboru
    return SUCC;
  }
  err_n = stat_list(0,ltab,false,main_il);
  if (err_n <= RETEND) {
    fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected end or else\n",line);
  }
  if ((err_n > 0)||(err_n <= RETEND)) { //chyba v programe najdi koniec riadku a pokracuj v analyze
    /*while (tok->type != EOL) {
      if (tok->type == END) {
        return SYNTH_ERROR;
      }
      GET_TOKEN;
    }
    GET_TOKEN;
    if (tok->type == END) {
      return SYNTH_ERROR;
    }
    line++;
    prog();*/
    if (err_n <= RETEND) {
      err_n = SYNTH_ERROR;
    }
    return err_n;
  }
  if (tok->type != END) {
    SERROR("EOF");
  }
  return SUCC;
}

int stat_list (int ew,localTable *ltab, bool def,List* l){
  if (tok->type == KEY_WORD) { //koniec sekvencie prikazov v definicii funkcie pripadne v if a while
    if (!strcmp(tok->value->str,"end")) {
      return RETEND;
    }else if (!strcmp(tok->value->str,"else")) {
      return RETELSE;
    }else if (!strcmp(tok->value->str,"do")) { //chyba
      fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected do\n",line);
      return(SYNTH_ERROR);
    }else if (!strcmp(tok->value->str,"then")) { //chyba
      fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected then\n",line);
      return(SYNTH_ERROR);
    }
  }
  int err_n = stat(ltab,def,l); //ERROR NUMBER
  if (err_n != 0) {
    return err_n;
  }
  if (tok->type != EOL) {//koniec riadku za instrukciou
    SERROR("EOL");
  }else{
    del_e_line();
  }
  if (tok->type == END) {//koniec suboru
    if (ew != 0) {
      fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected EOF\n",line);
      return(SYNTH_ERROR);
    }
    return SUCC;
  }
  err_n = stat_list(ew,ltab,def,l);
  if ((ew == 1)&&(err_n == RETEND)) {//skonict ak prisiel end
    return err_n;
  } else if ((ew == 2)&&(err_n == RETELSE)) {//skonict ak prisiel else
    return err_n;
  } else if (err_n <= RETEND){//prisiel end alebo else ale neocakavali sme ho
    fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected keyword\n",line);
    return(SYNTH_ERROR);
  }
  return err_n;
}
int check_sem_dek(globalTable *gtab, char *name, struct parameter *p){
  struct global_symbol *tmp = global_Search(gtab, name);
  if (tmp == NULL){
    fprintf(stderr, "Funkce nebyla nalezena\n");
    return SEM_ERROR;
  }
  struct parameter *ptr = p;
  while ((tmp != NULL) && (!strcmp(tmp->name, name))){
    while (ptr->type != T_NDEF){
      if (tmp->par->type != ptr->type){
        fprintf(stderr, "Spatny datovy typ argumentu funkce!\n");
        return SEM_ERROR;
      }
      ptr = ptr->next;
      tmp->par = tmp->par->next;
    }
    if (tmp->par != NULL)
      return SEM_ERROR;
    ptr = p;
    tmp = tmp->next;
  }
  return 0;
}
int stat(localTable *ltab,bool def,List* l){
  int err_n = 0; //ERROR NUMBER
  if (tok->type == IDENTIFICATOR) {//funkcie a premenne
    char *name=mm_malloc(sizeof(char) * (tok->value->length+1));
    strcpy(name,tok->value->str);
    GET_TOKEN;
    struct local_symbol *var = mm_malloc(sizeof(struct local_symbol));
    if (tok->type == EOL){//funkcia alebo premenna?
      if (global_isDeclared(gtab,name)==-1) {
        if(!local_isDeclared(ltab,name)){
          var->type = T_NIL;
          var->name = mm_malloc((strlen(name)+1)*sizeof(char));
          strcpy(var->name,name);
          local_InsertDeclared(ltab,var);
          inst_fill(l,OP_DEFVAR,"LF@",name,NULL,NULL,NULL,NULL);
        }
      }else{//funkcia bez parametrov
        if ((global_isDefined(gtab,name)<=0)&&(!def)) {
          //v definicii funkcie bez erroru, inak semanticka chyba
          SEMERROR("Not defined function",UNDEF_ERROR);
        }else{
          struct global_symbol *tmp = global_Search(gtab, name);
          if (tmp->par == NULL)
            return SUCC;
          return SEM_ERROR;
        }
      }//ako zistit ci ide o nedefinovanu funkciu alebo premennu?
      return SUCC;
    }
    if(!local_isDeclared(ltab,name)){
      var->type = T_NIL;
      var->name = mm_malloc((strlen(name)+1)*sizeof(char));
      strcpy(var->name,name);
      local_InsertDeclared(ltab,var);
      inst_fill(l,OP_DEFVAR,"LF@",name,NULL,NULL,NULL,NULL);
    }
    if (tok->type != ASSIGNMENT){//pridat moznost funkcie
      int p_fun[]={LBRACKET,IDENTIFICATOR,INTEGER,STRING,DOUBLE,EOL};//EOL->funkcia bez zatvoriek a parametrov
      int n_fun = 0;//1->dalsia je funkcia 0->dalsi je vyraz
      for (int i = 0; i < 5; i++) {
        if (tok->type==p_fun[i]) {
          n_fun = 1;
          break;
        }
      }
      int dek = false;//funkcia nebola definovana ideme ju deklarovat(plati iba v definicii inej funkcie)
      if (n_fun) {
        if (global_isDefined(gtab,name)<=0) {
          //v definicii funkcie bez error inak semanticka chyba
          if((def)&&(global_isDeclared(gtab,name)<=0)){
            global_InsertDeclared(gtab,name);
            dek = true;
          }else if(!def){
            SEMERROR("Not defined function",UNDEF_ERROR);
          }//bola deklarovana ale nie definovana
        }
        struct parameter *p = mm_malloc(sizeof(struct parameter));
        if (dek) {
          if(!global_addParam(gtab,p)){
            return INTERN_ERROR;
          }
        }
        int *par_cnt = mm_malloc(sizeof(int));
        *par_cnt = 0;
        if (func(p,l,par_cnt,ltab) == SYNTH_ERROR)
          return SYNTH_ERROR;
        else if (check_sem_ud(name, p))
          return SEM_ERROR;
        else return SUCC;
      }else {
        SERROR("=");
      }
    }
    GET_TOKEN;
    var_types *t = mm_malloc(sizeof(int));
    err_n = value(t,def,l,ltab);
    if (err_n!=0) {
      return err_n;
    }
    var->type = *t;
    if(!local_isDeclared(ltab,name)){
      struct local_symbol *var = mm_malloc(sizeof(struct local_symbol));
      var->type = *t;
      var->name = mm_malloc((strlen(name)+1)*sizeof(char));
      strcpy(var->name,name);
      local_InsertDeclared(ltab,var);
      inst_fill(l,OP_DEFVAR,"LF@",name,NULL,NULL,NULL,NULL);
    }
    return SUCC; //pridat do tabulky symbolo a inicializovat na hodnotu podla value (pravdepodobne cez parameter odkazom)
  }else if (tok->type == KEY_WORD) {//if, while , value
    if (!strcmp(tok->value->str,"def")) { //definicia funkcie
      if(def){
        fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected def\n",line);
        return(SYNTH_ERROR);
      }
      GET_TOKEN;
      if (tok->type != IDENTIFICATOR) {
        SERROR("identificator");
      }
      char *name=mm_malloc(sizeof(char) * (tok->value->length+1));
      strcpy(name,tok->value->str);
      if (global_isDefined(gtab,name)==1) {
        //error redefinicia funkcie
        SEMERROR("Redefinition of function",UNDEF_ERROR);
      }
      if (local_isDeclared(ltab,name)) {
        SEMERROR("Redefinition of variable",UNDEF_ERROR);
        //error premenna s rovnakym menom v hlavnom programe
      }
      bool dek = false;//funkcia bola deklarovana pred definiciou
      if (global_isDeclared(gtab,name)==1) {  //ak bola dekalrovana len zmenit na defined
        struct global_symbol* tmp = global_Search(gtab,name);
        tmp->isDefined=true;
        dek = true;
      }else{
        global_InsertDefined(gtab,name);
        //ulozit identificator do tabulky funkcii
      }
      inst_fill(func_il,OP_LABEL,"",name,NULL,NULL,NULL,NULL);
      localTable *fun_ltab;
      fun_ltab = mm_malloc(sizeof(localTable));
      local_Init(fun_ltab);
      inst_fill(func_il,OP_PUSHFRAME,NULL,NULL,NULL,NULL,NULL,NULL);
      inst_fill(func_il,OP_CREATEFRAME,NULL,NULL,NULL,NULL,NULL,NULL);
      GET_TOKEN;
      if (tok->type != LBRACKET) {
        SERROR("left bracket");
      }
      GET_TOKEN;
      if (tok->type != RBRACKET) {//preskakuje parametre ak je dalsi token ")"
        struct parameter *p = mm_malloc(sizeof(struct parameter));
        if(!dek){
          if(!global_addParam(gtab,p)){
            return INTERN_ERROR;
          }
        }
        err_n = param(p,1,func_il,ltab);
        if (err_n != 0) {
          return err_n;
        }
        p->next = mm_malloc(sizeof(struct parameter));
        int *par_cnt = mm_malloc(sizeof(int));
        *par_cnt = 0;
        err_n = param_list(p->next,1,func_il,par_cnt,ltab);//ulozit parametre do tabulky funkcii
        if (dek){//skontrolovat parametre v deklaracii s parametrami v definicii
          if (check_sem_dek(gtab, name, p))
           return SYNTH_ERROR;
        }
        if (err_n != 0) {
          return err_n;
        }
        if (tok->type != RBRACKET) {
          SERROR("right bracket");
        }
      }
      GET_TOKEN;
      if (tok->type != EOL) {
        SERROR("EOL");
      }
      del_e_line();
      err_n = stat_list(1,fun_ltab,true,func_il);
      if (err_n > 0 ) {
        return err_n;
      }
      if (err_n != RETEND) {
        SERROR("end");
      }
      GET_TOKEN;
      inst_fill(func_il,OP_POPFRAME,NULL,NULL,NULL,NULL,NULL,NULL);
      inst_fill(func_il,OP_RETURN,NULL,NULL,NULL,NULL,NULL,NULL);
      return SUCC;
    } else if (!strcmp(tok->value->str,"if")) { //if
      char ch_line[12] = {0};
      sprintf(ch_line, "%d", line);
      char lab_f [12] = {0};
      strcpy(lab_f,ch_line);
      strcat(lab_f,"$iff");
      GET_TOKEN;
      token=tok;
      expr_ret_type *ret = mm_malloc(sizeof(expr_ret_type));
      ret = expr(0,l,ltab);
      if (ret->err_id!=SUCC) {
        return ret->err_id;
      }
      tok=token;
      //var_types t = ret->t;
      if ((tok->type != KEY_WORD)&&(strcmp(tok->value->str,"then"))) {
        SERROR("then");
      }
      //JUMP podla vyrazu if false na hodnotu lab_f;
      GET_TOKEN;
      if (tok->type != EOL) {
        SERROR("EOL");
      }
      del_e_line();
      err_n = stat_list(2,ltab,def,l);
      if (err_n > 0 ) {
        return err_n;
      }
      inst_fill(l,OP_JUMP,"$ife",ch_line,NULL,NULL,NULL,NULL);
      if (err_n != RETELSE) {
        SERROR("else");
      }
      GET_TOKEN;
      if (tok->type != EOL) {
        SERROR("EOL");
      }
      inst_fill(l,OP_LABEL,"$iff",ch_line,NULL,NULL,NULL,NULL);
      del_e_line();
      err_n = stat_list(1,ltab,def,l);
      if (err_n > 0 ) {
        return err_n;
      }
      if (err_n != RETEND) {
        SERROR("end");
      }
      GET_TOKEN;
      inst_fill(l,OP_LABEL,"$ife",ch_line,NULL,NULL,NULL,NULL);
      return SUCC;
    } else if (!strcmp(tok->value->str,"while")) { //while
      char ch_line[12] = {0};
      sprintf(ch_line, "%d", line);
      inst_fill(l,OP_LABEL,"$whi",ch_line,NULL,NULL,NULL,NULL);
      GET_TOKEN;
      token=tok;
      expr_ret_type *ret = expr(0,l,ltab);
      if (ret->err_id!=SUCC) {
        return ret->err_id;
      }
      tok=token;
      //t =  ret->t;
      if ((tok->type != KEY_WORD)&&(strcmp(tok->value->str,"do"))) {
        SERROR("do");
      }
      GET_TOKEN;
      if (tok->type != EOL) {
        SERROR("EOL");
      }
      //JUMP podla podmienky false = jump na whe (end)
      del_e_line();
      err_n = stat_list(1,ltab,def,l);
      if (err_n > 0 ) {
        return err_n;
      }
      if (err_n != RETEND) {
        SERROR("end");
      }
      GET_TOKEN;
      inst_fill(l,OP_JUMP,"$whi",ch_line,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_LABEL,"$whe",ch_line,NULL,NULL,NULL,NULL);
      return SUCC;
    }
  }
  var_types *t = mm_malloc(sizeof(int));
  return value(t,def,l,ltab);
}
int check_sem(char *val, struct parameter *p,List *l){
  if (!strcmp(val, "input")){
    if (p->type == T_NDEF)
      return 0;
    fprintf(stderr, "Funkce typu input nesmi mit zadne argumenty!\n");
    return 1;
  }
  else if (!strcmp(val, "print")){
    if (p->type != T_NDEF)
      return 0;
    fprintf(stderr, "Funkce print musi mit aspon 1 parametr!\n");
    return 1;
  }
  else if (!strcmp(val, "length")){
    if (p->type == T_STRING && p->next->type == T_NDEF){
      return 0;
    }
    fprintf(stderr, "Spatny datovy typ argumentu ve funkci length!\n");
    return 1;
  }
  else if (!strcmp(val, "substr")){
    var_types tmp[] = { T_STRING, T_INT, T_INT, T_NDEF };
    for (int i = 0; i < 4; i++){
      if (tmp[i] != p->type){
        if (i == 1 || i == 2){
          if (p->type == T_FLOAT){//konverzia na INT
            char *u_id = gen_u();
            inst_fill(l,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_INT2FLOAT, "LF@", u_id, "LF@", p->name,NULL,NULL);
          }
        }
        fprintf(stderr, "Spatny datovy typ argumentu ve funkci substr!\n");
        return 1;
      }
      p = p->next;
    }
    return 0;
  }
  else if (!strcmp(val, "ord")){
    if (p->type == T_STRING && (p->next->type == T_INT || p->next->type == T_FLOAT) && p->next->next->type == T_NDEF)
      return 0;
    fprintf(stderr, "Spatny datovy typ argumentu ve funkci ord!\n");
    return 1;
  }
  else if (!strcmp(val, "chr")){
    if ((p->type == T_INT || p->type == T_FLOAT) && p->next->type == T_NDEF)
      return 0;
    fprintf(stderr, "Spatny datovy typ argumentu ve funkci chr!\n");
    return 1;
  }
  return 0;
}

int value (var_types *t,bool def,List* l,localTable *ltab){

  if (tok->type == KEY_WORD) {
    struct parameter *p = mm_malloc(sizeof(struct parameter));
    p->type = T_NDEF;
    /*************************INPUT******************************/
    if (!strcmp(tok->value->str,"inputs")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, "input");
      GET_TOKEN;
      *t = T_STRING;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      if (func(p,l,par_cnt,ltab) == SYNTH_ERROR)
        return SYNTH_ERROR;
      else if (check_sem(val, p,l))
        return SEM_ERROR;
      else{
        inst_fill(l,OP_CALL,"input","s",NULL,NULL,NULL,NULL);
        return SUCC;
      }
    }else if (!strcmp(tok->value->str,"inputi")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, "input");
      GET_TOKEN;
      *t = T_INT;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      if (func(p,l,par_cnt,ltab) == SYNTH_ERROR)
        return SYNTH_ERROR;
      else if (check_sem(val, p,l))
        return SEM_ERROR;
      else{
          inst_fill(l,OP_CALL,"input","i",NULL,NULL,NULL,NULL);
          return SUCC;
      }
    }else if (!strcmp(tok->value->str,"inputf")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, "input");
      GET_TOKEN;
      *t = T_FLOAT;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      if (func(p,l,par_cnt,ltab) == SYNTH_ERROR)
        return SYNTH_ERROR;
      else if (check_sem(val, p,l))
        return SEM_ERROR;
      else{
        inst_fill(l,OP_CALL,"input","f",NULL,NULL,NULL,NULL);
        return SUCC;
      }
    /*********************************PRINT*************************/
    }else if (!strcmp(tok->value->str,"print")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, tok->value->str);
      GET_TOKEN;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      if (func(p,l,par_cnt,ltab) == SYNTH_ERROR)
        return SYNTH_ERROR;
      else if (check_sem(val, p,l))
        return SEM_ERROR;
      else{
        char ch_p_c[5] = {0};
        sprintf(ch_p_c, "%d", *par_cnt);
        inst_fill(l,OP_PUSHS,"int@",ch_p_c,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_CALL,"prin","t",NULL,NULL,NULL,NULL);
        return SUCC;
      }
    /******************************LENGTH****************************/
    }else if (!strcmp(tok->value->str,"length")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, tok->value->str);
      GET_TOKEN;
      *t = T_INT;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      if (func(p,l,par_cnt,ltab) == SYNTH_ERROR)
        return SYNTH_ERROR;
      else if (check_sem(val, p,l))
        return SEM_ERROR;
      else{
        inst_fill(l,OP_CALL,"lengt","h",NULL,NULL,NULL,NULL);
        return SUCC;
      }
    /******************************ORD******************************/
    }else if (!strcmp(tok->value->str,"ord")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, tok->value->str);
      GET_TOKEN;
      *t = T_INT;//v pripade chyby T_NIL
      int *par_cnt = mm_malloc(sizeof(int));
      par_cnt = 0;
      if (func(p,l,par_cnt,ltab) == SYNTH_ERROR)
        return SYNTH_ERROR;
      else if (check_sem(val, p,l))
        return SEM_ERROR;
      else{
        inst_fill(l,OP_CALL,"or","d",NULL,NULL,NULL,NULL);
        return SUCC;
      }
    /******************************CHR******************************/
    }else if (!strcmp(tok->value->str,"chr")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, tok->value->str);
      GET_TOKEN;
      *t = T_STRING;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      if (func(p,l,par_cnt,ltab) == SYNTH_ERROR)
        return SYNTH_ERROR;
      else if (check_sem(val, p,l))
        return SEM_ERROR;
      else{
        inst_fill(l,OP_CALL,"ch","r",NULL,NULL,NULL,NULL);
        return SUCC;
      }
      /*************************SUBSTR******************************/
    }else if (!strcmp(tok->value->str,"substr")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, tok->value->str);
      GET_TOKEN;
      *t = T_STRING;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      if (func(p,l,par_cnt,ltab) == SYNTH_ERROR)
        return SYNTH_ERROR;
      else if (check_sem(val, p,l))
        return SEM_ERROR;
      else{
        inst_fill(l,OP_CALL,"sub","str",NULL,NULL,NULL,NULL);
        return SUCC;
      }
    }else {
      SERROR("function name");
    }
  /********************ID******************************/
  }else if (tok->type == IDENTIFICATOR) { //volanie funkcie pripadne vyraz!!!!
      char *name=mm_malloc(sizeof(char) * (strlen(tok->value->str)+1));
      strcpy(name,tok->value->str);
      GET_TOKEN;
      int p_fun[]={LBRACKET,IDENTIFICATOR,INTEGER,STRING,DOUBLE,EOL};//EOL->funkcia bez zatvoriek a parametrov
      int n_fun = 0;//1->dalsia je funkcia 0->dalsi je vyraz
      for (int i = 0; i < 5; i++) {
        if (tok->type==p_fun[i]) {
          n_fun = 1;
          break;
        }
      }
      int dek = false;//funkcia nebola definovana ideme ju deklarovat(plati iba v definicii inej funkcie)
      if (n_fun) {//skontrolovat ci sa funkcia nachadza v tabulke symbolov, ak nie nastavit na declarated (pripadne error v hlavnom tele)
        if (global_isDefined(gtab,name)<=0) {
          //v definicii funkcie bez error inak semanticka chyba
          if((def)&&(global_isDeclared(gtab,name)<=0)){
            global_InsertDeclared(gtab,name);
            dek = true;
          }else if(!def){
            SEMERROR("Not defined function",UNDEF_ERROR);
          }
        }
        struct parameter *p = mm_malloc(sizeof(struct parameter));
        if (dek) {
          if(!global_addParam(gtab,p)){
            return INTERN_ERROR;
          }
        }
        int *par_cnt = mm_malloc(sizeof(int));
        *par_cnt = 0;
        int err_n = func(p,l,par_cnt,ltab);
        if (err_n != 0) {
          return err_n;
        }
        inst_fill(l,OP_CALL,name,"",NULL,NULL,NULL,NULL);
        return SUCC;
      }else{//vyraz
        /*while (tok->type != EOL) {////////////////////////testovanie ZMAZAT////////////////////////////////////
          GET_TOKEN;
        }*/
        token=tok;
        expr_ret_type *ret = expr(0,l,ltab);
        if (ret->err_id!=SUCC) {
          return ret->err_id;
        }
        tok=token;
        *t =  ret->t;
      }
  }else{ //vyhodnot vyraz
    //GET_TOKEN;
    /*while (tok->type != EOL) {////////////////////////testovanie ZMAZAT////////////////////////////////////
      GET_TOKEN;
    }*/
    token=tok;
    expr_ret_type *ret = expr(0,l,ltab);
    if (ret->err_id!=SUCC) {
      return ret->err_id;
    }
    *t =  ret->t;
    tok=token;
    //expression parser
  }
  return SUCC;
}

int func(struct parameter *p,List *l, int *par_cnt,localTable *ltab){
  int lb = 0;//LEFT bracket -> 1 ak parametre zacinaju zatvorkou
  int err_n = 0;//ERROR NUMBER
  if (tok->type == EOL) {
    return SUCC; //funkcia bez parametrov a zatvoriek
  }
  if (tok->type == LBRACKET) {
    lb = 1;
    GET_TOKEN;
  }
  if (tok->type == RBRACKET) {
    if (lb==0) {
      fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected )\n",line);
      return(SYNTH_ERROR);
    }
    GET_TOKEN;
    return SUCC; //funkcia bez parametrov
  }
  err_n = param(p,0,l,ltab);
  if (err_n != 0) {
    return err_n;
  }
  (*par_cnt)++;
  p->next = mm_malloc(sizeof(struct parameter));
  p->next->type = T_NDEF;
  err_n = param_list(p->next,0,l,par_cnt,ltab);
  if (err_n != 0) {
    return err_n;
  }
  if (lb) {
    if (tok->type != RBRACKET) {
      SERROR("right bracket");
    }else{
      GET_TOKEN;
    }
  }
  return SUCC;
}

int param_list(struct parameter *p,int def,List *l, int *par_cnt,localTable *ltab){
  int err_n = 0;//ERROR NUMBER
  if (tok->type == COMMA) {
    GET_TOKEN;
    err_n = param(p,def,l,ltab);
    if (err_n != 0) {
      return err_n;
    }
    (*par_cnt)++;
    p->next = mm_malloc(sizeof(struct parameter));
    p->next->type = T_NDEF;
    err_n = param_list(p->next,def,l,par_cnt,ltab);
    if (err_n != 0) {
      return err_n;
    }
  }
  return SUCC;
}

int param(struct parameter *p,int def,List *l,localTable *ltab){
  if (def){
    if (tok->type == IDENTIFICATOR) {
      p->name = mm_malloc(sizeof(char)*(tok->value->length+1));
      strcpy(p->name,tok->value->str);
      if (local_isDeclared(ltab,p->name)) {
        return SUCC;//je to chyba?
      }
      struct local_symbol *var = mm_malloc(sizeof(struct local_symbol));
      var->type = T_NIL;
      var->name = mm_malloc((strlen(p->name)+1)*sizeof(char));
      strcpy(var->name,p->name);
      local_InsertDeclared(ltab,var);
      inst_fill(l,OP_POPS,"LF@",p->name,NULL,NULL,NULL,NULL);
      GET_TOKEN;
      return SUCC;
    }else{
      SERROR(tok->value->str);
    }
  }
  if (tok->type == IDENTIFICATOR) {//parameter je premenna
    p->name = mm_malloc(sizeof(char)*(tok->value->length+1));
    strcpy(p->name,tok->value->str);
    struct local_symbol *tmp = local_Search(ltab, p->name);
    p->type = tmp->type;
    inst_fill(l,OP_PUSHS,"LF@",p->name,NULL,NULL,NULL,NULL);
  }else if (tok->type == INTEGER) {//ulozit hodnotu a typ parametra do tabulky symbolov
    p->name = NULL;
    p->type = T_INT;
    inst_fill(l,OP_PUSHS,"int@",tok->value->str,NULL,NULL,NULL,NULL);
  }else if (tok->type == DOUBLE) {
    p->name = NULL;
    p->type = T_FLOAT;
    inst_fill(l,OP_PUSHS,"float@",tok->value->str,NULL,NULL,NULL,NULL);
  }else if (tok->type == STRING) {
    p->name = NULL;
    p->type = T_STRING;
    inst_fill(l,OP_PUSHS,"string@",tok->value->str,NULL,NULL,NULL,NULL);
  }else if (!strcmp(tok->value->str,"nil")){
    p->name = NULL;
    p->type = T_NIL;
    inst_fill(l,OP_PUSHS,"nil@","nil",NULL,NULL,NULL,NULL);
  }else{
    SERROR("identificator or constant");
  }
  GET_TOKEN;
  return SUCC;
}

int main(int argc, char const *argv[]) {
  file = stdin;
  int err_n = 0;//ERROR NUMBER
  create_token(&tok);
  init_memory();
  init_il();
  gtab = mm_malloc(sizeof(globalTable));
  global_Init(gtab);
  GET_TOKEN;
  err_n = prog();
  if (err_n==SUCC) {
    gen_code();
    printf("\n# INBUILD FUNCTIONS\n");
    create_inbuildFce();
    printf("LABEL $PROGRAM_END\n");
  }
  delete_token(tok);
  free_memory();
  fclose(file);
return err_n;
}
