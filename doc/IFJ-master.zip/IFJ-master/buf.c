/**
 * File is part of project IFJ2018.
 *
 * Brno University of Technology, Faculty of Information Technology
 *
 * @package IFJ2018
 * @authors
 */

#include <assert.h>
#include <string.h>
#include "buf.h"
#include "deb.h"
#include "m_manage.h"


static void realloc_buffer(Buff* b, size_t size) {
    if (size == b->buff_size)
        return;
    
    b->string = (char*) mm_realloc(b->string, size);
    
    if (size < b->buff_size) {
        b->length = 0;
        if (size != 0)
            b->string[0] = '\0';
    }
    
    b->buff_size = size;
}

Buff* init_buffer(size_t size) {
    if (size < 1)
        size = 1;
    
    Buff* b = (Buff*) mm_malloc(sizeof(Buff));
    
    b->buff_size = size;
    b->length = 0;
    b->string = (char*) mm_malloc(sizeof(char) * b->buff_size);
    
    b->string[0] = '\0';
    
    return b;
}

void free_buffer(Buff* b) {
    assert(b != NULL);
    if (b->string != NULL)
        mm_free(b->string);
    mm_free(b);
}

void append_char_to_buffer(Buff* b, char c) {
    assert(b != NULL);
    
    if (b->length + 1 >= b->buff_size) {
        realloc_buffer(b, b->buff_size + CHUNK_BUF);
    }
    
    b->string[b->length] = c;
    b->string[b->length+1] = '\0';
    b->length++;
}

void append_string_to_buffer(Buff* b, const char* str) {
    assert(b != NULL);
    
    size_t str_len, tmp;
    str_len = strlen(str);
    tmp = str_len + 1;
    
    if (b->length + tmp > b->buff_size) {
        realloc_buffer(b, b->length + strlen(str) + 1);
    }
    
    strcat(b->string, str);
    b->length = b->length + str_len;
}

void clear_buffer(Buff* b) {
    assert(b != NULL);
    
    realloc_buffer(b, CHUNK_BUF);
    
    b->string[0] = '\0';
    b->length = 0;
    b->buff_size = CHUNK_BUF;
}

void set_string_to_buffer(Buff* b, const char* str) {
    assert(b != NULL);
    
    size_t str_len, tmp;
    str_len = strlen(str);
    tmp = str_len + 1;
    if (tmp > b->buff_size)
        realloc_buffer(b, strlen(str) + 1);
    
    strcpy(b->string, str);
    b->length = str_len;
}

void debug_buffer(void* b) {
    Buff* buffer;
    buffer = (Buff*) b;
    debug("Buffer@%p: {", buffer);
    
    if (buffer != NULL) {
        debug(".len = %lu, .buffer_size = %lu, .str = %s", buffer->length, buffer->buff_size, buffer->string);
    }
    
    debugs("}");
}
