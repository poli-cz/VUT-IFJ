#include "dynamic_string.h"
#include "scanner.h"

int main(int argc, char *argv[]){
	if (argc != 2) {
		fprintf(stderr, "Spatny pocet argumentu.\n");
		return 1;
	}
    file = fopen(argv[1], "r");
	if (file == NULL)
		return 1;
	printf("Vstup: %s\n", argv[1]);
    stToken *token = NULL;
	create_token(&token);
    for (int i = 1; !get_token(token); i++){
        printf("TOKEN CISLO: %d\n", i);
		switch (token->type) {
			case UNDEFINED:
				printf("TYP: UNDEFINED\n");
				break;
			case IDENTIFICATOR:
				printf("TYP: IDENTIFICATOR\n");
				break;
			case KEY_WORD:
				printf("TYP: KEY_WORD\n");
				break;
			case INTEGER:
				printf("TYP: INTEGER\n");
				break;
			case DOUBLE:
				printf("TYP: DOUBLE\n");
				break;
			case STRING:
				printf("TYP: STRING\n");
				break;
			case ASSIGNMENT:
				printf("TYP: ASSIGNMENT\n");
				break;
			case PLUS:
				printf("TYP: PLUS\n");
				break;
			case MINUS:
				printf("TYP: MINUS\n");
				break;
			case MUL:
				printf("TYP: MUL\n");
				break;
			case DIV:
				printf("TYP: DIV\n");
				break;
			case LT:
				printf("TYP: LT\n");
				break;
			case GT:
				printf("TYP: GT\n");
				break;
			case LE:
				printf("TYP: LE\n");
				break;
			case GE:
				printf("TYP: GE\n");
				break;
			case EQ:
				printf("TYP: EQ\n");
				break;
			case NEQ:
				printf("TYP: NEQ\n");
				break;
			case LBRACKET:
				printf("TYP: LEFT BRACKET\n");
				break;
			case RBRACKET:
				printf("TYP: RIGHT BRACKET\n");
				break;
			case COMMA:
				printf("TYP: COMMA\n");
				break;
			case SEMICOLON:
				printf("TYP: SEMICOLON\n");
				break;
		}
        printf("HODNOTA: %s\n", token->value->str);
		printf("------------------\n");
		delete_token(token);
        create_token(&token);
    }
	delete_token(token);
    fclose(file);
    return 0;
}
