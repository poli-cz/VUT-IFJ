>make  
./scanner_test test_input  
make clean  

soubor test.c je jen testovací.
