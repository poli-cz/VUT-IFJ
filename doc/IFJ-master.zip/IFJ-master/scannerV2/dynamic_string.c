#include "dynamic_string.h"

/**
 * AUTOR: Jakub Sadílek
 * LOGIN: xsadil07
*/

int init_string (dynamic_str **string){
	if ((*string = (dynamic_str *)malloc(sizeof(dynamic_str))) == NULL) {
		fprintf(stderr, "Chyba alokace paměti při inicializaci dynamického stringu!");
		return 1;
	}
    (*string)->str = (char *) malloc(ALLOCATION_SIZE * sizeof(char));
    if ((*string)->str == NULL){
        fprintf(stderr, "Chyba alokace paměti při inicializaci dynamického stringu!");
        free(*string);
        return 1;
    }
    (*string)->length = 0;
    (*string)->allocated = ALLOCATION_SIZE;
    (*string)->str[(*string)->length] = '\0';
    return 0;
}

int add_char (char symbol, dynamic_str *string){
    if (string->length + 1 >= string->allocated){
        string->str = (char *)realloc(string->str, string->length + ALLOCATION_SIZE);
        if (string->str == NULL){
            fprintf(stderr, "Chyba při reallokaci dynamického stringu!\n");
            return 1;
        }
		string->allocated += ALLOCATION_SIZE;
    }
    string->str[string->length] = symbol;
    string->str[string->length + 1] = '\0';
    string->length++;
    return 0;
}

void free_string (dynamic_str *string){
	free(string->str);
    string->length = 0;
    string->allocated = 0;
}