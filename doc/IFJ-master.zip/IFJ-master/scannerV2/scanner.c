#include "scanner.h"
#include "dynamic_string.h"

/**
 * AUTOR: Jakub Sadílek
 * LOGIN: xsadil07
*/

const char *KEY_WORDS[] = { "def", "do", "else", "end", "if", "not", "nil", "then", "while",
 "inputs", "inputi", "inputf", "print", "length", "substr", "ord", "chr" };

static scan_states state;
static int symbol;
FILE *file = NULL;

static void fill_token (stToken *token, token_type t, dynamic_str *string){
    token->type = t;
    token->value = string;
}

static void check_token_type (stToken *token){
    for (int i = 0; i < KEYWORD_NUM; i++){
		if (!strcmp(token->value->str, KEY_WORDS[i])) {
			token->type = KEY_WORD;
			return;
		}
    }
}

static int do_id (stToken *token){
    dynamic_str *string = NULL;
	if (init_string(&string) || !islower(symbol) || (!islower(symbol) && symbol != '_'))
        return 1;
    add_char(symbol, string);

    while (true){
        symbol = getc(file);
        if (isalnum(symbol) || symbol == '_' || symbol == '?' || symbol == '!'){
            if (add_char(symbol, string))
                return 1;
            if (symbol == '?' || symbol == '!'){
                fill_token(token, IDENTIFICATOR, string);
                check_token_type(token);
                return 0;
            }
        }
        else {
            ungetc(symbol, file);
            fill_token(token, IDENTIFICATOR, string);
            check_token_type(token);
            return 0;
        }
    }
}

static int do_exp (stToken *token, dynamic_str *string){
    add_char(symbol, string);
    symbol = getc(file);
    if (symbol == '+' || symbol == '-'){
        add_char(symbol, string);
        while ((symbol = getc(file)) == '0');
        if (!isdigit(symbol)){
            ungetc(symbol, file);
            fprintf(stderr, "Exponenciální část desetinného čísla nesmí být prázdná!\n");
            free_string(string);
            return 1;
        }
    }
    else if (symbol == '0') {
        while ((symbol = getc(file)) == '0');
    }
    add_char(symbol, string);

    while (isdigit(symbol = getc(file)))
        add_char(symbol, string);
    ungetc(symbol, file);
    fill_token(token, DOUBLE, string);
    return 0;
}

static int do_double (stToken *token, dynamic_str *string){
    add_char(symbol, string);
    if (!isdigit(symbol = getc(file))){
        fprintf(stderr, "Desetinná část nesmí být prázdná!\n");
        free_string(string);
        return 1;
    }
    add_char(symbol, string);

    while (isdigit(symbol = getc(file)))
        add_char(symbol, string);
    if (symbol == 'e' || symbol == 'E')
        return (do_exp(token, string)) ? 1 : 0;
    else {
        ungetc(symbol, file);
        fill_token(token, DOUBLE, string);
    }
    return 0;
}

static int do_number (stToken *token){
    dynamic_str *string = NULL;
    if (symbol == '0'){
        int tmp = symbol;
        symbol = getc(file);
        if (symbol != 'e' && symbol != 'E' && symbol != '.'){
            fprintf(stderr, "Počáteční číslice nemůže být 0!\n");
            return 1;
        }
        ungetc(symbol, file);
        symbol = tmp;
    }
    if (init_string(&string))
        return 1;
    add_char(symbol, string);

    while (isdigit(symbol = getc(file)))
        add_char(symbol, string);
    if (symbol == '.')
        return (do_double(token, string)) ? 1 : 0;
    else if (symbol == 'e' || symbol == 'E')
        return (do_exp(token, string)) ? 1 : 0;
    else {
        ungetc(symbol, file);
        fill_token(token, INTEGER, string);
    }
    return 0;
}

static int do_hex (dynamic_str *string){
    int x1, x2 = 0;
    if (isxdigit(x1 = getc(file))){
        if (!isxdigit(x2 = getc(file))) 
            ungetc(symbol, file);
    }
    else {
        fprintf(stderr, "Neznámá sekvence znaků \\x%d, očekávám hexadecimální číslo!\n", x1);
        free_string(string);
        return 1;
    }

    char hexStr[10];
    x1 = x1 * 10 + x2;
    sprintf(hexStr, "0x%d", x1);
    symbol = (int)strtol(hexStr, NULL, 16);
    add_char(symbol, string);
    return 0;
}

static int do_literal (stToken *token){
    dynamic_str *string = NULL;
    if (init_string(&string))
        return 1;

    while ((symbol = getc(file)) != '\"'){
        if (symbol == '\n'){
            fprintf(stderr, "Řeťezcový literál může být pouze na jediném řádku!\n");
            free_string(string);
            return 1;
        }
        else if (symbol == '\\'){
            switch (symbol = getc(file)){
                case '\"':
                    if (add_char('\"', string))
                        return 1;
                    break;
                case 'n':
                    if (add_char('\n', string))
                        return 1;
                    break;
                case 't':
                    if (add_char('\t', string))
                        return 1;
                    break;
                case 's':   // Mezera \s není podporovaná?
                    if (add_char(' ', string))
                        return 1;
                    break;
                case '\\':
                    if (add_char('\\', string))
                        return 1;
                    break;
                case 'x':
                    if (do_hex(string))
                        return 1;
                    break;
                default:
                    fprintf(stderr, "Neočekávaná sekvence \\%d!\n", symbol);
                    free_string(string);
                return 1;
            }
        }
        else if (symbol == EOF){
            fprintf(stderr, "Neočekávaný konec souboru!\n");
            free_string(string);
            return 1;
        }
        else {
            if (add_char(symbol, string))
                return 1;
        }
    }
    fill_token(token, STRING, string);
    return 0;
}

static int do_sign (stToken *token, token_type t){
    dynamic_str *string = NULL;
    if (init_string(&string))
        return 1;
    add_char(symbol, string);
    fill_token(token, t, string);
    return 0;
}

static int do_relation (stToken *token){
    dynamic_str *string = NULL;
    if (init_string(&string))
        return 1;
    add_char(symbol, string);
    switch (symbol){
        case '=':
            if ((symbol = getc(file)) == '='){
                add_char(symbol, string);
                fill_token(token, EQ, string);
                return 0;
            }
            else {
                ungetc(symbol, file);
                fill_token(token, ASSIGNMENT, string);
                return 0;
            }
        case '!':
            if ((symbol = getc(file)) == '='){
                add_char(symbol, string);
                fill_token(token, NEQ, string);
                return 0;
            }
            else {
                ungetc(symbol, file);
                fprintf(stderr, "Neočekávaný znak '!'\n");
                return 1;
            }
        case '<':
            if ((symbol = getc(file)) == '='){
                add_char(symbol, string);
                fill_token(token, LE, string);
                return 0;
            }
            else {
                ungetc(symbol, file);
                fill_token(token, LT, string);
                return 0;
            }
        case '>':
            if ((symbol = getc(file)) == '='){
                add_char(symbol, string);
                fill_token(token, GE, string);
                return 0;
            }
            else {
                ungetc(symbol, file);
                fill_token(token, GT, string);
                return 0;
            }
    }
    return 0;
}

void do_line_com (){
    while((symbol = getc(file))){
        if (symbol == '\n' || symbol == EOF){
            ungetc(symbol, file);
            break;
        }
    }
    state = S_BEGIN;
}

int create_token (stToken **token){
    if ((*token = malloc(sizeof(struct sToken))) == NULL){
        fprintf(stderr, "Inicializace tokenu se nezdařila!\n");
        return 1;
    }
    (*token)->type = UNDEFINED;
    (*token)->value = NULL;
    return 0;
}

void delete_token (stToken *token){
	free_string(token->value);
    free(token);
}

int get_token (stToken *token){
    state = S_BEGIN;
    while (true){
        switch (state){
            case S_BEGIN:
                symbol = getc(file);
                if (islower(symbol) || symbol == '_') { state = S_ID; }
                if (isdigit(symbol)) { state = S_NUMBER; }
                if (symbol == '\"') { state = S_LITERAL; }
                if (symbol == '+') { state = S_PLUS; }
                if (symbol == '-') { state = S_MINUS; }
                if (symbol == '*') { state = S_MUL; }
                if (symbol == '/') { state = S_DIV; }
                if (symbol == '=') { state = S_EQ; }
                if (symbol == '<') { state = S_LT; }
                if (symbol == '>') { state = S_GT; }
                if (symbol == '!') { state = S_NEQ; }
                if (symbol == '#') { state = S_LCOM; }
                if (symbol == EOF) { return 1;}
            break;
            case S_ID:
                return (do_id(token)) ? 1 : 0;
            case S_NUMBER:
                return (do_number(token)) ? 1 : 0;
            case S_LITERAL:
                return (do_literal(token)) ? 1 : 0;
            case S_PLUS:
                return (do_sign(token, PLUS)) ? 1 : 0;
            case S_MINUS:
                return (do_sign(token, MINUS)) ? 1 : 0;
            case S_MUL:
                return (do_sign(token, MUL)) ? 1 : 0;
            case S_DIV:
                return (do_sign(token, DIV)) ? 1 : 0;
            case S_EQ:
                return (do_relation(token)) ? 1 : 0;
            case S_LT:
                return (do_relation(token)) ? 1 : 0;
            case S_GT:
                return (do_relation(token)) ? 1 : 0;
            case S_NEQ:
                return (do_relation(token)) ? 1 : 0;
            case S_LCOM :
                do_line_com();
                break;
        }
    }
}
