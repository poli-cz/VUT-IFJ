/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Parser
 *
 * @author Peter Dragúň xdragu01
 *         Jakub Sadílek xsadil07
 */
#ifndef PARSER_H
#define PARSER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "scanner.h"
#include "m_manage.h"
#include "symtable.h"
#include "err.h"
#include "expression_parser.h"
#include "three_adress_code.h"
#include "inbuildFCE.h"



#define RETEND -5
#define RETELSE -6

char *gen_u();
int prog();
/* ew(end when)
ew = 0 ->prikazy mimo cyklu
ew = 1 ->ocakava end
ew = 2 ->ocakava else
ltab = odkaz na lokalnu tabulku symbolov
def = sme v definici funkcie
*/
int stat_list (int ew,localTable *ltab,bool def,List* l);
/*
ltab = odkaz na lokalnu tabulku symbolov
def = sme v definici funkcie
*/
int stat(localTable *ltab,bool def,List* l);
/*
t = navratovy typ v pripade ze sa da nastavit implicitne
def = sme v definici funkcie
*/
int value (var_types *t, bool def,List* l,localTable *ltab,char **expr_ret);
/*
p = odkaz na linerny zoznam parametrov
*/
int func(struct parameter *p,List *l,int *par_cnt,localTable *ltab,int pr);
/*
p = odkaz na linerny zoznam parametrov
def = sme v definici funkcie

*/
int param_list(struct parameter *p,int def,List *l, int *par_cnt,localTable *ltab,int pr);
/*
p = odkaz na linerny zoznam parametrov
def = sme v definici funkcie
*/
int param(struct parameter *p,int def,List *l,localTable *ltab, int pr);



#endif
