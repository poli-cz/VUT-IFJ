/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Framestack
 *
 * @author Patricia Ramosova xramos00
 */

#include "framestack.h"



struct frame* pushFrame (struct framestack* ptr_stack, struct frame* ptr_frame){

    ptr_frame->next = ptr_stack->last;
    ptr_stack->last = ptr_frame;
    return ptr_frame;

}



void popFrame (struct framestack* ptr){

    if(ptr == NULL){
        return;
    }
    if(ptr->last == NULL){
        return;
    }

    ptr->last = ptr->last->next;

}



struct frame* topFrame (struct framestack* ptr){

    if(ptr == NULL){
        return NULL;
    }
    return ptr->last;
}



bool isFrameStackEmpty (struct framestack* ptr){

    return (ptr->last == NULL? true : false );

}