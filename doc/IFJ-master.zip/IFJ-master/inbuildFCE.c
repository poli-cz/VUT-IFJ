/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Inbuild Functions
 *
 * @author Patricia Ramosova xramos00
 */

#include "three_adress_code.h"

void create_inbuildFce(){

//inputs()
	printf("LABEL inputs\n");
	printf("CREATEFRAME\n");
	printf("PUSHFRAME\n");
	printf("DEFVAR LF@s\n");
	printf("READ LF@s string\n");
	printf("PUSHS LF@s\n");
	printf("POPFRAME\n");
	printf("RETURN\n");

//inputi()
	printf("LABEL inputi\n");
	printf("CREATEFRAME\n");
	printf("PUSHFRAME\n");
	printf("DEFVAR LF@i\n");
	printf("READ LF@i int\n");
	printf("PUSHS LF@i\n");
	printf("POPFRAME\n");
	printf("RETURN\n");

//inputf()
	printf("LABEL inputf\n");
	printf("CREATEFRAME\n");
	printf("PUSHFRAME\n");
	printf("DEFVAR LF@f\n");
	printf("READ LF@f float\n");
	printf("PUSHS LF@f\n");
	printf("POPFRAME\n");
	printf("RETURN\n");

//print()
    printf("LABEL print\n");
    printf("CREATEFRAME\n");
    printf("PUSHFRAME\n");
    printf("DEFVAR LF@n\n");
    // pocet opakovani for cyklu, resp. pocet vypis.
    printf("POPS LF@n\n");
    // pomocna premenna pre vypis
    printf("DEFVAR LF@tmp\n");
    // riadiaca premenna cyklu
    printf("DEFVAR LF@i\n");
    printf("MOVE LF@i int@0\n");
    printf("DEFVAR LF@condition\n");
    printf("DEFVAR LF@nil_type\n");
    printf("LABEL print_FOR\n");
    printf("LT LF@condition LF@i LF@n\n");
    printf("JUMPIFEQ print_FOR_end LF@condition bool@false\n");
    printf("POPS LF@tmp\n");
    printf("TYPE LF@nil_type LF@tmp\n")
    printf("EQ LF@condition LF@nil_type string@nil\n");
    printf("JUMPIFNEQ NO_NIL LF@condition bool@true\n")
    printf("WRITE string@\n")
    printf("JUMP NIL_LABEL\n");
    printf("LABEL NO_NIL\n");
    printf("WRITE LF@tmp\n");
    printf("LABEL NIL_LABEL\n");
    printf("ADD LF@i LF@i int@1\n");
    printf("JUMP print_FOR\n");
    printf("LABEL print_FOR_end\n");
    printf("PUSHS nil@nil");
    printf("POPFRAME\n");
    printf("RETURN\n");

//length(s)
    printf("LABEL length\n");
    printf("CREATEFRAME\n");
    printf("PUSHFRAME\n");
    printf("DEFVAR LF@s\n");
    printf("POPS LF@s\n");
    printf("DEFVAR LF@result\n");
    printf("STRLEN LF@result LF@s\n");
    printf("PUSHS LF@result\n");
    printf("POPFRAME\n");
    printf("RETURN\n");

//substr(s, i, n)
    printf("LABEL substr\n");
	printf("CREATEFRAME\n");
	printf("PUSHFRAME\n");
	printf("DEFVAR LF@s\n");
	printf("DEFVAR LF@i\n");
	printf("DEFVAR LF@n\n");
	printf("DEFVAR LF@result\n");
	printf("DEFVAR LF@tmp\n");
	printf("DEFVAR LF@tmp1\n");
	printf("DEFVAR LF@tmp_str\n");
	printf("DEFVAR LF@finnish\n");
	printf("DEFVAR LF@length\n");
	printf("POPS LF@n\n");
	printf("POPS LF@i\n");
	printf("POPS LF@s\n");
	printf("MOVE LF@i LF@length\n");
	printf("MOVE LF@result string@\n");
	printf("STRLEN LF@length LF@s\n");
	printf("GT LF@finnish LF@i LF@length\n");           //i sa nachadza mimo retazca - za retazcom
	printf("JUMPIFNEQ $LABEL1 LF@finnish bool@true\n");
	printf("PUSHS nil@nil\n");
	printf("POPFRAME\n");
	printf("RETURN\n");
	printf("LABEL $LABEL1\n");
	printf("LT LF@finnish LF@i int@0\n");               //i sa nachadza mimo retazca - pred retazcom
	printf("JUMPIFNEQ $LABEL2 LF@finnish bool@true\n");
	printf("PUSHS nil@nil\n");
	printf("POPFRAME\n");
	printf("RETURN\n");
	printf("LABEL $LABEL2\n");
	printf("LT LF@finnish LF@n int@0\n");               //n je mensie ako nula
	printf("JUMPIFNEQ $LABEL3 LF@finnish bool@true\n");
	printf("SUB LF@n LF@length LF@i\n");
	printf("LABEL $LABEL3\n");
	printf("DEFVAR LF@tmp2\n");                         // n+1 > length(s) upravena podmienka
	printf("ADD LF@tmp2 LF@i LF@n\n");
	printf("GT LF@finnish LF@tmp2 LF@length\n");
	printf("JUMPIFNEQ $LABEL4 LF@finnish bool@true\n");
	printf("SUB LF@n LF@length LF@i\n");
	printf("LABEL $LABEL4\n");
	printf("LABEL $LABEL_WHILE\n");
	printf("GT LF@finnish LF@n int@0\n");
	printf("JUMPIFNEQ $LABEL_finnish LF@finnish bool@true\n");
	printf("GETCHAR LF@tmp_str LF@s LF@i\n");
	printf("ADD LF@tmp1 LF@i int@1\n");
	printf("MOVE LF@i LF@tmp1\n");
	printf("SUB LF@tmp1 LF@n int@1\n");
	printf("MOVE LF@n LF@tmp1\n");
	printf("MOVE LF@tmp LF@result\n");
	printf("CONCAT LF@result LF@tmp LF@tmp_str\n");
	printf("JUMP $LABEL_WHILE\n");
	printf("LABEL $LABEL_finnish\n");
	printf("PUSHS LF@result\n");
	printf("POPFRAME\n");
	printf("RETURN\n");

//ord(s, i)
    printf("LABEL ord\n");
	printf("CREATEFRAME\n");
	printf("PUSHFRAME\n");
	printf("DEFVAR LF@s\n");
	printf("DEFVAR LF@i\n");
	printf("DEFVAR LF@length\n");
	printf("DEFVAR LF@condition\n");
	printf("DEFVAR LF@equal\n");
	printf("DEFVAR LF@greater\n");
	printf("POPS LF@s\n");
	printf("POPS LF@i\n");
	printf("MOVE LF@length int@0\n");
	printf("STRLEN LF@length LF@s\n");
	printf("LT LF@condition LF@i int@0\n");
	printf("JUMPIFEQ $LABEL_ORD_finnish LF@condition bool@true\n");
	printf("GT LF@greater LF@i LF@length\n");
	printf("EQ LF@equal LF@i LF@length\n");
	printf("OR LF@condition LF@greater LF@equal\n");
	printf("JUMPIFEQ $LABEL_ORD_finnish LF@condition bool@true\n");
	printf("DEFVAR LF@result\n");
	printf("STRI2INT LF@result LF@s LF@i\n");
	printf("PUSHS LF@result\n");
	printf("POPFRAME\n");
	printf("RETURN\n");
	printf("LABEL $LABEL_ORD_finnish\n");
	printf("PUSHS nil@nil\n");
	printf("POPFRAME\n");
	printf("RETURN\n");

//chr(i)
    printf("LABEL chr\n");
	printf("CREATEFRAME\n");
	printf("PUSHFRAME\n");
	printf("DEFVAR LF@i\n");
	printf("POPS LF@i\n");
	printf("DEFVAR LF@result\n");
	printf("INT2CHAR LF@result LF@i\n");
	printf("PUSHS LF@result\n");
	printf("POPFRAME\n");
	printf("RETURN\n");

}
