/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief File dynamic string
 *
 * @author Jakub Sadílek xsadil07
 */
 
 #include "dynamic_string.h"

/**
 * Funkce inicializuje paměť pro dynamické pole včetně pole charu.
 * Velikost pole určuje makro ALLOCATION_SIZE. Při úspěchu vrací 0,
 * jinak 1.
*/
int init_string (dynamic_str **string){
	if ((*string = (dynamic_str *)malloc(sizeof(dynamic_str))) == NULL) {
		fprintf(stderr, "Chyba alokace paměti při inicializaci dynamického stringu!");
		return 1;
	}
    (*string)->str = (char *) malloc(ALLOCATION_SIZE * sizeof(char));
    if ((*string)->str == NULL){
        fprintf(stderr, "Chyba alokace paměti při inicializaci dynamického stringu!");
        free(*string);
        return 1;
    }
    (*string)->length = 0;
    (*string)->allocated = ALLOCATION_SIZE;
    (*string)->str[(*string)->length] = '\0';
    return 0;
}

/**
 * Funkce přidá znak na konec pole. V případě, že je pole malé, tak ho realokuje.
 * Při úspěchu vrací 0, jinak 1.
*/
int add_char (char symbol, dynamic_str *string){
    if (string->length + 1 >= string->allocated){
        string->str = (char *)realloc(string->str, string->allocated + ALLOCATION_SIZE * (sizeof(char)));
        if (string->str == NULL){
            fprintf(stderr, "Chyba při reallokaci dynamického stringu!\n");
            return 1;
        }
		string->allocated += ALLOCATION_SIZE;
    }
    string->str[string->length] = symbol;
    string->str[string->length + 1] = '\0';
    string->length++;
    return 0;
}
