/**
 * File is part of project IFJ2018.
 *
 * Brno University of Technology, Faculty of Information Technology
 *
 * @package IFJ2018
 * @authors
 */

#ifndef IFJ18_COMPILER_3AC_H
#define IFJ18_COMPILER_3AC_H

// Operation code with string representation, all codes are prefixed by OP_
#include "scanner.h"
#include "list.h"

#define FOREACH_OP_CODE(OP_CODE) \
    OP_CODE(MOVE) \
    OP_CODE(CREATEFRAME) \
    OP_CODE(PUSHFRAME) \
    OP_CODE(POPFRAME) \
    OP_CODE(DEFVAR) \
    OP_CODE(CALL) \
    OP_CODE(RETURN) \
    OP_CODE(PUSHS) \
    OP_CODE(POPS) \
    OP_CODE(CLEARS) \
    OP_CODE(ADD) \
    OP_CODE(SUB) \
    OP_CODE(MUL) \
    OP_CODE(DIV) \
    OP_CODE(IDIV) \
    OP_CODE(ADDS) \
    OP_CODE(SUBS) \
    OP_CODE(MULS) \
    OP_CODE(DIVS) \
    OP_CODE(IDIVS) \
    OP_CODE(LT) \
    OP_CODE(GT) \
    OP_CODE(EQ) \
    OP_CODE(LTS) \
    OP_CODE(GTS) \
    OP_CODE(EQS) \
    OP_CODE(AND) \
    OP_CODE(OR) \
    OP_CODE(NOT) \
    OP_CODE(ANDS) \
    OP_CODE(ORS) \
    OP_CODE(NOTS) \
    OP_CODE(INT2FLOAT) \
    OP_CODE(FLOAT2INT) \
    OP_CODE(INT2CHAR) \
    OP_CODE(STRI2INT) \
    OP_CODE(INT2FLOATS) \
    OP_CODE(FLOAT2INTS) \
    OP_CODE(INT2CHARS) \
    OP_CODE(STRI2INTS) \
    OP_CODE(READ) \
    OP_CODE(WRITE) \
    OP_CODE(CONCAT) \
    OP_CODE(STRLEN) \
    OP_CODE(GETCHAR) \
    OP_CODE(SETCHAR) \
    OP_CODE(TYPE) \
    OP_CODE(LABEL) \
    OP_CODE(JUMP) \
    OP_CODE(JUMPIFEQ) \
    OP_CODE(JUMPIFNEQ) \
    OP_CODE(JUMPIFEQS) \
    OP_CODE(JUMPIFNEQS) \
    OP_CODE(EXIT) \
    OP_CODE(BREAK) \
    OP_CODE(DPRINT)

#define GEN_ENUM(ENUM) OP_##ENUM,
#define GEN_STR(STR) #STR,

#define NO_ADDRESS ((Address) {.type = ADDR_TYPE_EMPTY, {NULL}})

// Helper macros for adding instructions
#define ADD_IL(il, op, addr1, addr2, addr3) add_to_il(il, init_inst(op, addr1, addr2, addr3))
#define ADD_SPACE(il) add_to_il(il, init_inst(OP_SPACE, NO_ADDRESS, NO_ADDRESS, NO_ADDRESS))

#define MAX_AD 3

/**
 * Enum of operation codes
 */
typedef enum {
    FOREACH_OP_CODE(GEN_ENUM) OP_SPACE
} op_enum;

/**
 * Enum of operand types, used to determine the value of operand
 */
typedef enum {
    AD_T_S,  // Symbol from symtable
    AD_T_C,  // Constant
    AD_T_E,  // No operand
    AD_T_ERR  // Error occurred allocating content of address
} ad_t_enum;

/**
 * Instruction address data type
 */
typedef struct ad_type {
    ad_t_enum t;  /// Type of address, used to determine the value of address
    
    union {
        char* s;  /// Symbol identifier with frame prefix (GF@, LF@, TF@)
        stToken* c;  /// Constant in token form
    };
} Ad;

/**
 * Instruction data type
 */
typedef struct i_t {
    op_enum op;  /// Instruction operation code
    Ad ads[MAX_AD];  /// Array of addresses
} Ins;


extern List* main_il;  /// Global instruction list for main
extern List* func_il;  /// Global instruction list for functions
extern List* global_il;  /// Global instruction list for global variables

/**
 * Initialize new intruction
 * @param ad1 Address 1
 * @param ad2 Address 2
 * @param ad3 Address 3
 * @return new instruction
 */
Ins* init_ins(op_enum op, Ad ad1, Ad ad2, Ad ad3);

/**
 * Free instruction
 * @param inst Instruction
 */
void free_ins(void* inst);

/**
 * Create new address for given symbol
 * @param pref symbol prefix ("GF@", "LF@", "TF@")
 * @param s identifier (will be copied)
 * @return Address
 */
Ad ad_for_symbol(const char* pref, const char* s);

/**
 * Create new address for given constant
 * @param token constant in Token form (content will be copied)
 * @return Address
 */
Ad ad_for_constant(stToken token);

/**
 * Free the content of address
 * @param addr Address
 */
void free_ad(Ad addr);

/**
 * Initialize instruction list
 */
void init_il(void);

/**
 * Free instruction list
 */
void free_il(void);

/**
 * Adds instruction to instruction list
 * @param instruction Instruction to add
 */
void add_to_il(List* il, Ins* instr);

/**
 * Generate 3 address code
 */
void gen_code(void);

/**
 * Print instruction
 * @param inst Instruction
 */
void debug_ins(void *inst);

#endif //IFJ18_COMPILER_3AC_H
