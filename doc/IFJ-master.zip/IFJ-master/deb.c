/**
 * File is part of project IFJ2018.
 *
 * Brno University of Technology, Faculty of Information Technology
 *
 * @package IFJ2018
 * @authors
 */

#include "deb.h"

void deb_int(void* i) {
    if (i == NULL) {
        debug("%p", i);
    } else {
        debug("%d", *(int*) i);
    }
}

void deb_float(void* f) {
    if (f == NULL) {
        debug("%p", f);
    } else {
        debug("%g", *(float*) f);
    }
}
