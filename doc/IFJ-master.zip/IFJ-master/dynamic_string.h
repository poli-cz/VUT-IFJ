/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Header file for dynamic string
 *
 * @author Jakub Sadílek xsadil07
 */
 
 #ifndef DYNAMIC_STRING_H
#define DYNAMIC_STRING_H
#include <stdio.h>
#include <stdlib.h>
/**
 *  Alokační velikost pole.
 */
#define ALLOCATION_SIZE 5

/**
 * Struktura dynamického pole.
 * *str - řetězec,
 * length - délka řetězce,
 * allocated - naalokovaná paměť pro řetězec.
*/
typedef struct {
    char *str;
    unsigned int length;
    unsigned int allocated;
} dynamic_str;

/**
 * Inicializuje prázdné pole na počáteční délku.
 * Pokud uspěje vrací 0, jinak 1.
*/
int init_string (dynamic_str **string);

/**
 * Přidá znak na konec pole, v případě, že je pole malé, tak
 * reallokuje a pak přidá znak. Vrací 0 v případě úspěchu, jinak 1.
*/
int add_char (char symbol, dynamic_str *string);
#endif