/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Types
 *
 * @author Peter Dragúň xdragu01
 */


#ifndef TYPES_H
#define TYPES_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "scanner.h"
#include "m_manage.h"
#include "expression_parser.h"
#include "three_adress_code.h"
#include "err.h"

/*datove typy
  int,
  double,
  string,
  nil
*/
/*
  mozne konverzie:
  int -> float
  float -> int

  int +-* int = int
  int +-* float = float
  float +-* float = float
  string1 + string2 = string1string2 (konkatenacia)
  int / int = int div int

  <, >, <=, >=, ==, != rozdielne typy -> int convert na double inak je hodnota nill

*/

void inst_fill(List* il,op_enum op,char*pref1,char *var1,char*pref2,char *var2,char*pref3,char *var3);

int int2double_convert (List *l,st_item **item1, st_item **item2);

st_item *type_control(List *l,st_item *item1, st_item *item2, stToken *op);

st_item *s_item_init();

#endif
