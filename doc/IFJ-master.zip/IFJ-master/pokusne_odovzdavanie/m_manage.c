/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief File m_manage
 *
 * @author Viktória Halečková xhalec00
 */

#include <stdlib.h>
#include <assert.h>

#include "m_manage.h"
#include "err.h"
#include "deb.h"

#define CHUNK_MEM 100

typedef void* Bl;

/**
 * Memory Manager
 */
struct {
    Bl* mem;  /// Array of allocated memory blocks
    unsigned f_free;  /// Index of first free Block in memory (always last unused Block)
    unsigned s;  /// Actual allocated size of memory
    unsigned max_bl;  /// Max blocks allocated in the lifespan of memory manager
} mm;

/**
 * Swap two memory blocks
 * @param item1 ...
 * @param item2 ...
 */
static void mem_bl_sw(Bl *item1, Bl *item2) {
    void* ptr = *item1;
    *item1 = *item2;
    *item2 = ptr;
}

/**
 * Expand Memory Manager memory for storing allocated blocks by CHUNK_MEM
 */
static void mem_exp() {
    mm.mem = (Bl*) realloc(mm.mem, sizeof(Bl) * (mm.s + CHUNK_MEM));
    if (mm.mem == NULL)
        exit(INTERN_ERROR);

    mm.s = mm.s + CHUNK_MEM;
}

/**
 * Get free memory block, expand memory if full
 * @return free memory block (considered used after call)
 */
static Bl* get_mem_bl() {
    if (mm.f_free >= mm.s - 1) {
        mem_exp();
    }

    if (mm.f_free + 1 > mm.max_bl)
        mm.max_bl = mm.f_free + 1;

    return &mm.mem[mm.f_free++];
}

/**
 * Find memory block with given ptr
 * @param ptr Allocated memory
 * @return memory block with given ptr
 */
static Bl* find_mem_bl(void *ptr) {
    for (unsigned i = 0; i < mm.f_free; ++i) {
        if (mm.mem[i] == ptr)
            return &mm.mem[i];
    }

    debugs("(Memory Manager) ERROR: Memory was not allocated or was already freed!");
    exit(INTERN_ERROR);
}

// PUBLIC INTERFACE

void init_memory() {
    mm.mem = (Bl *) malloc(sizeof(Bl) * CHUNK_MEM);
    if (mm.mem == NULL)
        exit(INTERN_ERROR);

    mm.s = CHUNK_MEM;
    mm.f_free = 0;
    mm.max_bl = 0;
}

void free_memory() {
    /*-debugs("\n======= Memory Manager =======\n");
    debug("In use at exit: %d blocks\n", mm.f_free);
    debug("Max blocks used: %d blocks\n", mm.max_bl);
    debugs("==============================\n");*/

#ifndef MEM_MNG_NO_FREE
    for (; mm.f_free > 0; mm.f_free--) {
        free(mm.mem[mm.f_free - 1]);
    }
#endif

    free(mm.mem);
}

void* mm_malloc(size_t size) {
    Bl* item;
    item = get_mem_bl();

    *item = malloc(size);
    if (*item == NULL) {
        free_memory();
        exit(INTERN_ERROR);
    }

    return *item;
}

void* mm_realloc(void* ptr, size_t size) {
    Bl* item;
    item = find_mem_bl(ptr);

    *item = realloc(ptr, size);
    if (*item == NULL) {
        if (size != 0) {
            free_memory();
            exit(INTERN_ERROR);
        }
    }

    return *item;
}

void mm_free(void* ptr) {
    assert(ptr != NULL);
    Bl * item;
    item = find_mem_bl(ptr);
    free(*item);

    mm.f_free--;
    mem_bl_sw(item, &mm.mem[mm.f_free]);
    }
