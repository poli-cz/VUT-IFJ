/**
 * Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Expression parser, header file
 *
 * @authors Viktoria Haleckova xhalec00
 *          Peter Dragun xdragu01
 */
#ifndef EXPR_PARSER_H
#define EXPR_PARSER_H

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "scanner.h"
#include <string.h>
#include "symtable.h"
#include "framestack.h"
#include "three_adress_code.h"

extern char precedence_table[15][15];

extern struct local_frame_stack *local_stack;

stToken *token;

/**
 * Return type of expression
 */
typedef struct expr_return {
    char *var_name; //name of variable
    var_types t; //data type of return
    int err_id; //identificator in case of error
}expr_ret_type;

struct global_symbol *g_search(char *k);

/**
 * Main function to evaluate expressions
 * @param assign switch
 * @return expr_ret_type
 */
expr_ret_type *expr(int assign,List *l,localTable *ltab,stToken *tok_id);

int function(stToken *t2,List *l,localTable *ltab);
/**
 * Enum of st_item types
 */

typedef enum {
    T_ID,
    T_VAL,
    T_OP,
    T_OP_REL,
    T_ST_BTM,
    T_L,
    T_EXPR
} st_item_type;

/**
 * Item in list of tokens from input
 */
typedef struct token_listitem {
    stToken *token_from_i;
    struct token_listitem *next_one;
}token_item;

/**
 * Adds item to the end of list
 * @param it Item to add
 */
void add_last_to_list(token_item *it);

/**
 * Creates token $ - means end of input file
 * @return stToken
 */
stToken *create_$_token(void);

/**
 * Adds $ to the end of list - $ means end of input file
 * @param h $ to add
 */
void add_eof_to_list(token_item * h);

/**
 * Returns token type of item
 * @param it Item
 * @return Integer
 */
int ret_t(token_item *it);

/**
 * Returns size of list
 * @param h Pointer to the first item of list
 * @return Integer
 */
int list_size(token_item *h);

/**
 * Function for recursion, simulation of rule
 * @return Integer
 */
//int function(void);

/**
 * Function for recursion, simulation of rule
 * @return Integer
 */
int function_expression_list(List *l,localTable *ltab);

/**
 * Function for recursion, simulation of rule
 * @return Integer
 */
int function_expression_list_2(List *l,localTable *ltab);

/**
 * Stack item
 */
typedef struct stack_item {
    st_item_type t; //type of item
    var_types d_type; //type of data
    stToken *tok; //token
    bool isTerm; //if value is terminal
    char *var_n; //name of temporary variable
}st_item;

/**
 * Stack of precedence table
 */
typedef struct stack{
    st_item **array; //array of item pointers
    int t; //pointer to the top
    int s; //size of stack
}st;

/**
 * Creates item '<' for stack
 * @return pointer to item '<'
 */
st_item *less_item(void);

/**
 * Finds top terminal of stack
 * @param s Pointer to stack
 * @return index, in case of error returns -1
 */
int search_for_top_t(st *s);

/**
 * Finds nearest '<' to the top of stack
 * @param s Pointer to stack
 * @return index, in case of error returns -1
 */
int search_less_item(st *s);

/**
 * Inserts '<' to array
 * @param s Pointer to stack
 */
void ins_less_item(st *s);

/**
 * Push bottom of stack to stack
 * @param s Pointer to stack
 */
void p_b_stack(st *s);

/**
 * Push item to stack
 * @param s Pointer to stack
 * @param i Pointer to item
 */
void p_it(st *s, st_item *i);

/**
 * Creates item
 * @param token Pointer to token
 * @return Pointer to item
 */
st_item *make_item(stToken *token);

/**
 * Applies rule for reduction of stack
 * @param s Pointer to stack
 * @return 1 if successfully, otherwise 0
 */
int reduction_rule(st *s, List *l,localTable *ltab);

/**
 * Prints all values of stack, from top to bottom
 * @param s Pointer to stack
 */
void print_s(st *s);

/**
 * Makes index in precedence table from item in stack
 * @param it Pointer to item
 * @return index in precedence table
 */
int idx_from_it(st_item *it);

/**
 * Gets data type of terminal
 * @param it Pointer to item
 * @return data type, t_else for undefined (err3)
 */
var_types terminal_d_type(st_item *it,localTable *ltab);

char * conv_instr(char *t,char *v_t, var_types d_type);

/**
 *    int  strcmparray(char *retazec, char **pole, int len)
 *
 *    Vstupne hodnoty
 *    char *retazec - vstupny retazec
 *    char **pole   - pole stringov pre porovnanie
 *    int  len      - dlzka pola
 *
 *    Porovnava string s polozkami pola
 *
 *    Navratova hodnota
 *
 *    int - 0  -OK
 *        - 1  -Lexikalna chyba
 *        - 99 -Vnutorna chyba lexikalnej analyzy
 */
int  strcmparray(char *r, char **p, int l);

/**
 * Gets data type from string
 * @param val String
 * @return data type
 */
var_types data_type_from_str(char *val);

/*
  mozne konverzie:
  int -> float
  float -> int

  int +-* int = int
  int +-* float = float
  float +-* float = float
  string1 + string2 = string1string2 (konkatenacia)
  int / int = int div int

  <, >, <=, >=, ==, != rozdielne typy -> int convert na double inak je hodnota nill

*/

/*
 * Ulozi instrukciu do vnutornej pamate
 * l -> seckcia do ktorej pridat instrukcie
 * pref -> prefixy premennych a konstant (LF@,GF@,int@,nil@...)
 * var -> odkaz na nazvy premennych
 */
void inst_fill(List* il,op_enum op,char*pref1,char *var1,char*pref2,char *var2,char*pref3,char *var3);


/*
 * Konvertuje cislo z int na double pricom nezalezi na poradi
 * item -> odkaz na polozku zasobnika ktora sa bude konvertovat
 */
int int2double_convert (List *l,struct stack_item **item1, struct stack_item **item2);


/*
 * Funkcia urobi typovu kontrolu a pripadne konverzie. V pripade uspechu generuje kod IFJcode18.
 * Konstanty kontroluje pri preklade, premenne az v IFJcode18
 * l -> seckcia do ktorej pridat instrukcie
 * item -> odkaz na polozku zasobnika ktora sa bude kontrolovat, operator v instrukcii
 * op -> operator
 */
struct stack_item *type_control(List *l,struct stack_item *item1, struct stack_item *item2, stToken *op);


/*
 * Vytvori polozku zasobnika potrebnu pre typovu kontrolu
 */
struct stack_item *s_item_init();

/*
 * Funkcia prida instrukcie na kontrolu typu premennej na urovni IFJcode18
 * l -> seckcia do ktorej pridat instrukcie
 * name -> nazov premennej definovanej na lokalnom zasobniku
 * type -> ocakavany typ
 * v pripade ze type je int alebo float vrati meno premennej v ktorej je konvertovana hodnota
 * inak vracia NULL
*/
char *type_asm_ch (List *l,char *name,var_types type);


#endif
