/**
 * Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * Three adress code
 *
 * @authors Viktoria Haleckova xhalec00
 *          
 */

#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include "three_adress_code.h"
#include "deb.h"
#include "m_manage.h"

static const char* opcodes_str[] = {
    FOREACH_OP_CODE(GEN_STR) ""
};

List* main_il = NULL;
List* func_il = NULL;
List* while_def_il = NULL;

Ins* init_ins(op_enum op, Ad ad1, Ad ad2, Ad ad3) {
    Ins* inst = (Ins*) mm_malloc(sizeof(Ins));

    if (ad1.t == AD_T_ERR ||
        ad2.t == AD_T_ERR||
        ad3.t == AD_T_ERR)
    {
        free_ad(ad1);
        free_ad(ad2);
        free_ad(ad3);
        mm_free(inst);
        return NULL;
    }

    inst->op = op;
    inst->ads[0] = ad1;
    inst->ads[1] = ad2;
    inst->ads[2] = ad3;

    return inst;
}

void free_ins(void* inst) {
    Ins* instruction = (Ins*) inst;
    int i = 0;
    while (i < MAX_AD) {
        free_ad(instruction->ads[i]);
        i++;
    }

    mm_free(inst);
}

Ad ad_for_symbol(const char* pref, const char* s) {
    Ad address;

    address.s = (char*) mm_malloc(sizeof(char) * (strlen(pref) + strlen(s) + 1));

    strcpy(address.s, pref);
    strcat(address.s, s);
    address.t = AD_T_S;

    return address;
}

Ad ad_for_constant(stToken token) {
    Ad address;

    address.c = copy_token(&token);

    address.t = AD_T_C;

    return address;
}

void free_ad(Ad addr) {
    if (addr.t == AD_T_S)
        mm_free(addr.s);
    else if (addr.t == AD_T_C) {
        if (addr.c != NULL)
            if ((addr.c->type == IDENTIFICATOR) || (addr.c->type == STRING))
                if (addr.c->value != NULL)
                    mm_free(addr.c->value);
        mm_free(addr.c);
    }
    else
        return;
}

void init_il() {
    main_il = init_list(free_ins);
    func_il = init_list(free_ins);
    while_def_il = init_list(free_ins);
}

void free_il() {
    free_list(main_il);
    free_list(func_il);
    free_list(while_def_il);
}

void add_to_il(List* il, Ins* instruction) {
    if (instruction == NULL)
        return;

    if (il == NULL)
        return;

    insert_last_list(il, instruction);
}

stToken *copy_token(stToken *token) {
    if (token == NULL)
        return NULL;

    stToken *c = (stToken*) mm_malloc(sizeof(stToken));
    c->type = token->type;
    c->value->str = (char*) mm_malloc(sizeof(char) * (strlen(token->value->str) + 1));
    strcpy(c->value->str, token->value->str);
    return c;
}

static void print_ins(Ins* instruction) {
    assert(instruction != NULL);

    printf("%s ", opcodes_str[instruction->op]);

    for (int i = 0; i < MAX_AD; ++i) {
        if (instruction->ads[i].t == AD_T_S)
                printf("%s ", instruction->ads[i].s);
        if (instruction->ads[i].t == AD_T_C) {
                if (instruction->ads[i].c->type == STRING)
                        printf("string@%s ", instruction->ads[i].c->value->str);
                else if (instruction->ads[i].c->type == INTEGER) 
                        printf("int@%s", instruction->ads[i].c->value->str);
                else if (instruction->ads[i].c->type == DOUBLE) 
                        printf("float@%s", instruction->ads[i].c->value->str); 
                else if (instruction->ads[i].c->type == KEY_WORD) //fix!!
                        printf("bool@true");
                else if (instruction->ads[i].c->type == KEY_WORD) //fix!!
                        printf("bool@false");
                else
                        assert(!"I should not be here");
                }
        }
}

void gen_code() {
    puts(".IFJcode18");
    Ins* instruction;
    puts("# SECTION MAIN");
    activate_first_list(main_il);

    while (active_list(main_il)) {
        instruction = (Ins*) get_active_list(main_il);
        assert(instruction != NULL);
        print_ins(instruction);
        printf("\n");
        succ_list(main_il);
    }
    // Jump to end to skip functions
    puts("JUMP $PROGRAM_END");
    printf("\n\n");

    puts("# SECTION FUNCTIONS");
    activate_first_list(func_il);

    while (active_list(func_il)) {
        instruction = (Ins*) get_active_list(func_il);
        assert(instruction != NULL);
        print_ins(instruction);
        printf("\n");
        succ_list(func_il);
    }

    printf("\n\n");
    puts("#VAR DEFINITION");
    activate_first_list(while_def_il);

    while (active_list(while_def_il)) {
        instruction = (Ins*) get_active_list(while_def_il);
        assert(instruction != NULL);
        print_ins(instruction);
        printf("\n");
        succ_list(while_def_il);
    }
    //puts("LABEL PROGRAM_END");
}

void debug_ins(void *inst) {
    Ins* instruction = (Ins*) inst;
    debug("Instruction@%p: {", (void *)instruction);
    if (instruction != NULL) {
        debug("%s ", opcodes_str[instruction->op]);

        for (int i = 0; i < MAX_AD; ++i) {
            if (instruction->ads[i].t == AD_T_S)
                    debug("%s ", instruction->ads[i].s);
            if (instruction->ads[i].t == AD_T_C) {
                    if (instruction->ads[i].c->type == STRING)
                        debug("string@%s ", instruction->ads[i].c->value->str);

                        //INT, REAL, TRUE, FALSE..
            }
        }
    }
    debugs("}");
}
