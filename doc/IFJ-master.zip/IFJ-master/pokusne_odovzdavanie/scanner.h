/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Header file for scanner.c
 *
 * @author Jakub Sadílek xsadil07
 */

#ifndef SCANNER_H
#define SCANNER_H

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include "dynamic_string.h"

// Počet klíčových slov.
#define KEYWORD_NUM 17

// Ukazatel na vstupní soubor.
FILE *file;

/**
 * Stavy pro rozlišení vstupního znaku.
*/
typedef enum {
    S_BEGIN,
    S_ID,
    S_NUMBER,
    S_LITERAL,
    S_PLUS,
    S_MINUS,
    S_MUL,
    S_DIV,
    S_RELATION,
    S_LCOM,
    S_ERROR,
    S_LBRACKET,
    S_RBRACKET,
    S_COMMA,
    S_EOL,
    S_END
} scan_states;

/**
 * Typy, kterých může token nabývat.
*/
typedef enum {
    UNDEFINED,
    IDENTIFICATOR,
    KEY_WORD,
    INTEGER,
    DOUBLE,
    STRING,
    ASSIGNMENT,
    PLUS,
    MINUS,
    MUL,
    DIV,
    LT,
    GT,
    LE,
    GE,
    EQ,
    NEQ,
    LBRACKET,
    RBRACKET,
    COMMA,
    EOL,
    T_EOF,
    END
} token_type;

/**
 * Struktůra tokenu.
*/
typedef struct sToken {
    token_type type;
    dynamic_str *value;
} stToken;

/**
 * Vytvoří nový token. Při úspěchu vrací 0, jinak 1.
*/
int create_token (stToken **token);

/**
 * Smaže token.
*/
void delete_token (stToken *token);

/**
 * Čte znaky ze vstupního souboru a vrátí odpovídající token.
 * Při úspěchu vrací 0, jinak 1.
*/
int get_token (stToken *token);
#endif
