/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Header file for m_manage.c
 *
 * @author Viktória Halečková xhalec00
 */

#ifndef IFJ18_COMPILER_MEMORY_MANAGER_H
#define IFJ18_COMPILER_MEMORY_MANAGER_H

/**
 * Initialize Memory Manager
 */
void init_memory(void);

/**
 * Free Memory Manager and all allocated memory by mm_malloc
 */
void free_memory(void);

/**
 * Allocate memory of given size
 * @param size Number of bytes to allocate
 * @return pointer to allocated memory (never NULL)
 */
void* mm_malloc(size_t size);

/**
 * Reallocate memory pointed to by ptr to given size
 * @param ptr Pointer to memory block to reallocate
 * @param size New size of memory block
 * @return pointer to allocated memory (can be different than given ptr, but never NULL)
 */
void* mm_realloc(void* ptr, size_t size);

/**
 * Free given memory block
 * @param ptr Pointer to memory block
 */
void mm_free(void* ptr);

#endif //IFJ18_COMPILER_MEMORY_MANAGER_H
#ifndef _M_MANAGE_
#define _M_MANAGE_
#include <stdio.h>


/**
 * Štruktúra Memory Manage
 */
typedef struct MMNode{

  void *pointer;
  struct MMNode *next_one;

}tMMNode;

/**
 * Vyčistí pamäť
 * @param f0 súbor
 * @param f1 súbor
 */
void clear_memory(FILE *f0, FILE *f1);

/**
 * Uvoľní pamäť kam ukazuje pointer
 * @param pointer Ukazateľ
 */
void mm_free(void * pointer);

/**
 * Realokuje pamäť pointera na danú veľkosť
 * @param pointer Ukazateľ
 * @param s veľkosť
 */
void *mm_realloc(void *pointer, size_t s);

#endif
