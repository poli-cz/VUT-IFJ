/**
 * Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Expression parser
 *
 * @authors Viktoria Haleckova xhalec00
 *          Peter Dragun xdragu01
 */
#include "expression_parser.h"
#include "three_adress_code.h"
#include "parser.h"
#include "m_manage.h"
#include "symtable.h"
#include <assert.h>

#define GET_TOKEN_M(t)  create_token(&t); err_no = get_token(t); if(err_no!=0){if(err_no == 1) return err_no;}
#define GET_TOKEN_M_EXPR(t) create_token(&t); return_s->err_id = get_token(t);  if(return_s->err_id!=0){return return_s;}


char precedence_table[15][15] = {
    //          0id  1val 2(   3)   4+   5-   6*   7/   8$   9==  10!=  11< 12<= 13> 14>=
    /* 0id  */ {'-', '-', '-', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    /* 1val */ {'-', '-', '-', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    /* 2(   */ {'<', '<', '<', '=', '<', '<', '<', '<', '-', '<', '<', '<', '<', '<', '<'},
    /* 3)   */ {'-', '-', '-', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    /* 4+   */ {'<', '<', '<', '>', '>', '>', '<', '<', '>', '>', '>', '>', '>', '>', '>'},
    /* 5-   */ {'<', '<', '<', '>', '>', '>', '<', '<', '>', '>', '>', '>', '>', '>', '>'},
    /* 6*   */ {'<', '<', '<', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    /* 7/   */ {'<', '<', '<', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    /* 8$   */ {'<', '<', '<', '-', '<', '<', '<', '<', '-', '<', '<', '<', '<', '<', '<'},
    /* 9== */  {'<', '<', '<', '>', '<', '<', '<', '<', '>', '-', '-', '-', '-', '-', '-'},
    /* 10!= */ {'<', '<', '<', '>', '<', '<', '<', '<', '>', '-', '-', '-', '-', '-', '-'},
    /* 11<  */ {'<', '<', '<', '>', '<', '<', '<', '<', '>', '-', '-', '-', '-', '-', '-'},
    /* 12<= */ {'<', '<', '<', '>', '<', '<', '<', '<', '>', '-', '-', '-', '-', '-', '-'},
    /* 13>  */ {'<', '<', '<', '>', '<', '<', '<', '<', '>', '-', '-', '-', '-', '-', '-'},
    /* 14>= */ {'<', '<', '<', '>', '<', '<', '<', '<', '>', '-', '-', '-', '-', '-', '-'},
};

const char * Data_Typ[] = {"integer",
    "float",
    "string",
    "bool",
    "nil",
    "ERROR"};
extern globalTable *gtab;
struct global_symbol *func_id = NULL;
struct parameter *p;
stToken *token;
List *l;

struct global_symbol *g_search(char *k){
    assert(k!=NULL);
    unsigned int idx = hashCode(k);
    struct global_symbol  *temporary = gtab->tHTable[idx];
    while(temporary != NULL){
        if (!strcmp(k,temporary->name))
            return temporary;
        temporary = temporary->next;
    }
    return temporary;

}

char * conv_instr(char *t,char *v_t, var_types d_type){

    if ((d_type == T_FLOAT && !strcmp(t,"integer")) || (d_type == T_INT && !strcmp(t,"float"))){
        if(d_type == T_INT && !strcmp(t,"float")){
            char * unique_variable = gen_u();
            inst_fill(l, OP_DEFVAR, "LF@", unique_variable, NULL, NULL, NULL, NULL);
            inst_fill(l, OP_INT2FLOAT, "LF@", unique_variable, "LF@", v_t, NULL, NULL);
            return unique_variable;
        }/*
          else if(d_type == T_FLOAT && !strcmp(t,"integer")){
          char *unique_variable = gen_u();
          inst_fill(l, OP_DEFVAR, "LF@", unique_variable, NULL, NULL, NULL, NULL);
          inst_fill(l, OP_FLOAT2INT, "LF@", unique_variable, "LF@", v_t, NULL, NULL);
          return unique_variable;
          } */
    }
    else {
        return NULL;
    }
    return NULL;
}

int strcmparray(char *r, char **p, int l) {

    int cnt=0;
    while(cnt<l)
    {
        if (!strcmp(p[cnt], r))
        {
            return 1;
        }
        cnt++;
    }
    return 0;
}

int free_h(token_item *h){
  if (h == NULL) {
    return SUCC;
  }
  while (h->next_one != NULL) {
    stToken *t = h->token_from_i;
    h = h->next_one;
    delete_token(t);
  }
  return SUCC;
}

expr_ret_type  *expr(int assign,List *l,localTable *ltab,stToken *tok_id) {
    expr_ret_type *return_s = mm_malloc(sizeof(expr_ret_type));
    return_s->var_name = NULL;
    return_s->t = T_ELSE;
    return_s->err_id = 0;

    int u_tok_id = 1; //1 -> tok_id nebol pouzity
    stToken *token_2 = token;
    if (assign == 1) {
        char *array[] = {"chr", "ord", "substr", "length", "printf", "inputs", "inputi", "inputf" };
        if (token_2->type == IDENTIFICATOR ||  strcmparray(token_2->value->str, array, 8)) {

            create_token(&token);
            return_s->err_id = get_token(token);
            if (return_s->err_id != 0)
                return return_s;

            if (token->type == LBRACKET) {
                int res = function(token_2,l,ltab);
                return_s->err_id = res;
                if (res == 0) {
                    char *result = gen_u();
                    inst_fill(l,OP_DEFVAR, "LF@", result, NULL, NULL, NULL, NULL);
                    inst_fill(l, OP_POPS, "LF@",result, NULL, NULL, NULL, NULL);
                    return_s->var_name = result;
                    struct global_symbol *g_s = g_search(token_2->value->str);
                    return_s->t = data_type_from_str(g_s->name); //ret type?

                }
                return return_s;
            }
        }
        else {

            if (!strcmp(token->value->str, "then") || !strcmp(token->value->str, "do") || (token->type == EOL) || token->type == COMMA) {

                return_s->err_id= 2;
                return return_s;
            }
            create_token(&token);
            return_s->err_id = get_token(token);
            if (return_s->err_id != 0)
                return return_s;
        }
    }
    else {
        if (!strcmp(token->value->str, "then") || !strcmp(token->value->str, "do") || (token->type == EOL) || token->type == COMMA) {
            fprintf(stderr, "Nastala chyba! Vyraz je prazdny.\n");
            return_s->err_id = 2;
            return return_s;
        }
        if ((tok_id!=NULL)&&(u_tok_id)){
          token = tok_id;
          u_tok_id = 0;
        }else{
          create_token(&token);
          return_s->err_id = get_token(token);
          if (return_s->err_id != 0)
          return return_s;
        }
    }


    token_item *h = mm_malloc(sizeof(token_item));
    h->next_one = NULL;
    h->token_from_i = token_2;

    int left_c = 0;
    int right_c = 0;

    if(token_2->type == LBRACKET)
        left_c++;
    if(token->type == LBRACKET)
        left_c++;
    if(token->type == RBRACKET)
        right_c++;

    while (strcmp(token->value->str, "then") && strcmp(token->value->str, "do") && (token->type != EOL) && token->type != COMMA && !(left_c<right_c)) {
        if (token->type == END){
            fprintf(stderr, "Neocekavany konec souboru.\n");
            return_s->err_id = SYNTH_ERROR;
            return return_s;
        }
        add_last_to_list(h);
        create_token(&token);
        return_s->err_id = get_token(token);
        if (return_s->err_id != 0)
            return return_s;

        if(token->type == LBRACKET)
            left_c++;
        if(token->type == RBRACKET)
            right_c++;
    }

    st *s = mm_malloc(sizeof(st));

    s->array = mm_malloc(4 * list_size(h)*sizeof(st_item));
    s->t = -1;
    s->s = 4*list_size(h);
    int i = 0;
    while (i < s->s) {
        s->array[i] = NULL;
        i++;
    }

    p_b_stack(s);

    add_eof_to_list(h);

    token_item *it = h;
    st_item * tmp = make_item(it->token_from_i);
    if (tmp == NULL) {
        fprintf(stderr,"Nastala chyba! Neplatny vstupny symbol v expression parser. riadok 206\n");
        return_s->err_id = 2;
        return return_s;
    }

    while(s->t != 1 || tmp->t != T_ST_BTM) {
        int inp_i = idx_from_it(tmp);
        if (inp_i == -1) {
            fprintf(stderr, "Nastala chyba! Vstupny symbol precedencnej tabulky SA je neznamy.\n");
            return_s->err_id = 2;
            return return_s;
        }

        int st_i = idx_from_it(s->array[search_for_top_t(s)]);
        if (precedence_table[st_i][inp_i] == '=') {
            p_it(s, tmp);
            it = it->next_one;
            tmp = make_item(it->token_from_i);
            if (tmp == NULL) {
                fprintf(stderr,"Nastala chyba! Neplatny vstupny symbol v expression parser.riadok 226\n");
                return_s->err_id = 2;
                return return_s;
            }

        }
        else if (precedence_table[st_i][inp_i] == '<') {
            ins_less_item(s);
            p_it(s, tmp);
            it = it->next_one;
            tmp = make_item(it->token_from_i);
            if (tmp == NULL) {
                fprintf(stderr,"Nastala chyba! Neplatny vstupny symbol v expression parser.riadok 238\n");
                return_s->err_id = 2;
                return return_s;
            }
        }
        else if (precedence_table[st_i][inp_i] == '>') {
            int res = reduction_rule(s,l,ltab);
            if (res != 0) {
                //printf("res sa nerovna nule.\n");
                return_s->err_id = res;
                return return_s;
            }
        }
        else if (precedence_table[st_i][inp_i] == '-') {
            fprintf(stderr, "Nastala chyba! Nespravna kombinacia vstupneho symbolu  a najvyssieho terminalu na zasobniku.\n");
            return_s->err_id = 2;
            return return_s;
        }
        else {
            fprintf(stderr, "Nastala chyba! Nedefinovany stav.\n");
            return_s->err_id = 99;
            return return_s;
        }
    }
    return_s->var_name = mm_malloc((sizeof(s->array[s->t]->var_n)+1)*sizeof(char));
    strcpy(return_s->var_name,s->array[s->t]->var_n);
    return_s->t = s->array[1]->d_type;
    return_s->err_id = 0;
    free_h(h);
    return return_s;
}

int function(stToken *t2,List *l,localTable *ltab) {

    int err_no;
    char *arr[] = {"chr", "ord", "substr", "length", "printf", "inputs", "inputi", "inputf"};
    if(t2->type != IDENTIFICATOR)
        if (!strcmparray(t2->value->str, arr, 8)){
            return 2;
        }
    if(token->type != LBRACKET){
        return 2;
    }
    GET_TOKEN_M(token)

    func_id = g_search(t2->value->str);
    if (func_id == NULL) {
        return 3;
    }
    p = func_id->par;
    err_no = function_expression_list(l,ltab);

    if(err_no)
        return err_no;
    if(token->type != RBRACKET){
        if (p != NULL)
            return 4;
        return 2;
    }

    inst_fill(l, OP_CALL, "", t2->value->str, NULL, NULL, NULL, NULL);

    GET_TOKEN_M(token)
    return 0;
}

int function_expression_list(List *l,localTable *ltab) {
    if(token->type == RBRACKET){
        if (p != NULL)
            return 4;
        return 0;
    }

    char *arr[] = {"("};
    if(!(token->type == IDENTIFICATOR || token->type == STRING || token->type == INTEGER || token->type == DOUBLE || strcmparray(token->value->str, arr, 1) )) {
        return 2;
    }
    int err_no;

    if (p == NULL) {
        fprintf(stderr, "Nastala chyba! V definicii je menej parametrov ako pri volani funkcie.\n");
        return 4;
    }

    expr_ret_type *ret_st = expr(0,l,ltab,NULL);
    if (ret_st->err_id != 0)
        return ret_st->err_id;

    char *str = NULL;
    char *t = "";
    if (p->type == T_NIL)
        t = "nil";
    else if (p->type == T_INT)
        t = "integer";
    else if (p->type == T_FLOAT)
        t = "float";
    else if (p->type == T_STRING)
        t = "string";
    else if (p->type == T_BOOL)
        t = "bool";


    if(!strcmp(t, Data_Typ[ret_st->t])){
        str =ret_st->var_name;
    }
    else {
        char *type = "";
        if (p->type == T_NIL)
            type = "nil";
        else if (p->type == T_INT)
            type = "integer";
        else if (p->type == T_FLOAT)
            type = "float";
        else if (p->type == T_STRING)
            type = "string";
        else if (p->type == T_BOOL)
            type = "bool";
        str = conv_instr(type, ret_st->var_name, ret_st->t);
        if (str == NULL) {
            fprintf(stderr, "Nastala chyba! Nespravny typ parametra aj po aplikacii implicitnej konverzie.\n");
            return 4;
        }
    }
    p = p->next;
    err_no = function_expression_list_2(l,ltab);

    inst_fill(l, OP_PUSHS, "LF@", str, NULL, NULL, NULL, NULL);

    return err_no;
}

int function_expression_list_2(List *l,localTable *ltab) {
    int err_no;
    if(token->type == RBRACKET){
        if (p != NULL)
            return 4;
        return 0;
    }
    if(token->type != COMMA){
        return 2;
    }
    GET_TOKEN_M(token)
    char *arr[] = {"("};
    if(!(token->type == IDENTIFICATOR || token->type == STRING || token->type == INTEGER || token->type == DOUBLE || strcmparray(token->value->str, arr, 1)||!(strcmp(token->value->str, "nil")))) {
        return 2;
    }

    if (p == NULL) {
        fprintf(stderr, "Nastala chyba! V definicii je menej parametrov ako pri volani funkcie.\n");
        return 4;
    }

    expr_ret_type *ret_st = expr(0,l,ltab,NULL);
    if (ret_st->err_id != 0)
        return ret_st->err_id;

    char *str = NULL;
    char *t = "";
    if (p->type == T_NIL)
        t = "nil";
    else if (p->type == T_INT)
        t = "integer";
    else if (p->type == T_FLOAT)
        t = "float";
    else if (p->type == T_STRING)
        t = "string";
    else if (p->type == T_BOOL)
        t = "bool";

    if(!strcmp(t, Data_Typ[ret_st->t])){
        str = ret_st->var_name;
    }
    else {
        char *type = "";
        if (p->type == T_NIL)
            type = "nil";
        else if (p->type == T_INT)
            type = "integer";
        else if (p->type == T_FLOAT)
            type = "float";
        else if (p->type == T_STRING)
            type = "string";
        else if (p->type == T_BOOL)
            type = "bool";
        str = conv_instr(type, ret_st->var_name, ret_st->t);
        if (str == NULL) {
            fprintf(stderr, "Nastala chyba! Nespravny typ parametra aj po aplikacii implicitnej konverzie.\n");
            return 4;
        }
    }
    p = p->next;
    err_no = function_expression_list_2(l,ltab);

    inst_fill(l, OP_PUSHS, "LF@", str, NULL, NULL, NULL, NULL);

    return err_no;
}

stToken *create_$_token(){
    stToken * pom = mm_malloc(sizeof(stToken));
    pom->value = mm_malloc(sizeof(dynamic_str));
    pom->value->str = mm_malloc(2*sizeof(char));
    pom->value->str[0] = '$';
    pom->value->str[1] = '\0';
    pom->type = END;
    return pom;
}

int list_size(token_item *h){
    if (h == NULL)
        return 0;
    int cnt = 1;
    while (h->next_one != NULL) {
        cnt++;
        h = h->next_one;
    }
    return cnt;
}


void add_last_to_list(token_item *h) {
    token_item *new_one = (token_item*) mm_malloc(sizeof(token_item));

    new_one->token_from_i = token;
    new_one->next_one = NULL;

    while (h->next_one != NULL) {
        h = h->next_one;
    }
    h->next_one = new_one;
    return;
}

int ret_t(token_item *it) {
    if (it == NULL) {
        fprintf(stderr,"Nastala chyba pri citani.\n");
        return 0;
    }
    return (int)it->token_from_i->type;
}

void add_eof_to_list(token_item *h) {
    token_item *new_one = (token_item*) mm_malloc(sizeof(token_item));

    new_one->token_from_i = create_$_token();
    new_one->next_one = NULL;

    while (h->next_one != NULL) {
        h = h->next_one;
    }
    h->next_one = new_one;
    return;
}

st_item *less_item(void) {
    st_item *new_one = mm_malloc(sizeof(st_item));
    new_one->t = T_L;
    new_one->d_type = T_ELSE;
    new_one->tok = NULL;
    new_one->isTerm = false;
    return new_one;
}


int search_for_top_t(st *s) {
    int i = s->t;
    while (i > -1) {
        if (s->array[i]->isTerm == true)
            return i;
        i--;
    }
    return i;
}


int search_less_item(st *s) {
    int i = s->t;
    while (i > -1) {
        if (s->array[i]->t == T_L)
            return i;
        i--;
    }
    return i;
}


void ins_less_item(st *s) {
    if ((s->t+1) == (s->s-1)) {
        fprintf(stderr,"Nastala chyba! Zasobnik sa pri vkladani symbolu '<' preplnil.\n");
        return;
    }

    int i = s->t;
    while (i > search_for_top_t(s)) {
        s->array[i+1] = s->array[i];
        i--;
    }

    s->array[i+1] = less_item();
    (s->t)++;
    return;
}


void p_b_stack(st *s) {
    st_item *new_one = mm_malloc(sizeof(st_item));
    new_one->t = T_ST_BTM;
    new_one->d_type = T_ELSE;
    new_one->tok = NULL;
    new_one->isTerm = true;
    p_it(s,new_one);
}


void p_it(st *s, st_item *it){
    if (s->t == (s->s - 1)) {
        fprintf(stderr,"Nastala chyba! Zasobnik expression parser je plny.\n");
        return;
    }

    s->array[++(s->t)] = it;
    return;
}


st_item *make_item(stToken *token){
    char *op[] = {"(",")","+","-", "*", "/"};
    char *rel_op[] =  {"==","!=","<","<=", ">", ">="};

    if (token == NULL) {
        fprintf(stderr,"Ukazatel na vstupny token nieje platny.\n");
        printf("token je NULL.\n");
        return NULL;
    }

    if (strcmparray(token->value->str, op, 6)) {
        st_item *new_one = mm_malloc(sizeof(st_item));
        new_one->t = T_OP;
        new_one->tok = token;
        new_one->isTerm = true;
        return new_one;
    }
    else if (strcmparray(token->value->str, rel_op, 6)) {
        st_item * new_one = mm_malloc(sizeof(st_item));
        new_one->t = T_OP_REL;
        new_one->tok = token;
        new_one->isTerm = true;
        return new_one;
    }
    else if ((token->type == INTEGER) || (token->type == DOUBLE) || (token->type == STRING) || (token->type == IDENTIFICATOR) || (!strcmp(token->value->str,"nil"))) {
        st_item *new_one = mm_malloc(sizeof(st_item));
        if (token->type == IDENTIFICATOR)
            new_one->t = T_ID;
        else
            new_one->t = T_VAL;
        new_one->tok = token;
        new_one->isTerm = true;
        return new_one;
    }
    else if (token->type == END){
        if (!strcmp(token->value->str,"$")) {
            st_item *new_one = mm_malloc(sizeof(st_item));
            new_one->t = T_ST_BTM;
            new_one->d_type = T_ELSE;
            new_one->tok =token;
            new_one->isTerm = true;
            return new_one;
        }
    }
    //printf("po vsetkych ifoch to returne NULL.\n");
    return NULL;
}

void print_s(st *s) {
    printf("Vypis hodnot na zasobniku:vrchol\n");
    int i = s->t;
    while (i > -1) {
        printf("%d. typ: %d\n", i, s->array[i]->t);
        i--;
    }
    printf("Spodok zasobnika, koniec vypisu.\n");
}


int reduction_rule(st *s, List *l, localTable *ltab){
    int tmp = search_less_item(s);
    if (tmp == (s->t - 1)) {
        if(T_ID == s->array[s->t]->t || T_VAL == s->array[s->t]->t ) {
            st_item *new = mm_malloc(sizeof(st_item));
            new->t = T_EXPR;

            if (s->array[s->t]->t == T_ID) {
                new->d_type = terminal_d_type(s->array[s->t],ltab);
                new->var_n = s->array[s->t]->tok->value->str;
            }
            else {
                if (s->array[s->t]->tok->type == DOUBLE)
                    new->d_type = T_FLOAT;
                else if (s->array[s->t]->tok->type == INTEGER)
                    new->d_type = T_INT;
                else if (s->array[s->t]->tok->type == STRING)
                    new->d_type = T_STRING;
                else if (!strcmp(s->array[s->t]->tok->value->str,"nil"))
                    new->d_type = T_NIL;
                else new->d_type = T_ELSE;
                char *var = gen_u();
                  inst_fill(while_def_il,OP_DEFVAR, "LF@", var,NULL,NULL,NULL,NULL);
                if (s->array[s->t]->tok->type == STRING) {
                    inst_fill(l, OP_MOVE,"LF@", var, "string@", s->array[s->t]->tok->value->str, NULL, NULL);
                }
                else if(s->array[s->t]->tok->type == INTEGER) {
                    inst_fill(l, OP_MOVE, "LF@", var, "int@", s->array[s->t]->tok->value->str, NULL, NULL);
                }
                else if(s->array[s->t]->tok->type == DOUBLE) {
                    inst_fill(l, OP_MOVE, "LF@", var, "float@", s->array[s->t]->tok->value->str, NULL, NULL);
                }
                else if(!strcmp(s->array[s->t]->tok->value->str,"nil")) {
                    inst_fill(l, OP_MOVE, "LF@", var, "nil@", s->array[s->t]->tok->value->str, NULL, NULL);
                }
                new->var_n = var;
            }

            if(new->d_type == T_ELSE) {
                return 3;
            }

            new->tok = s->array[s->t]->tok;
            new->isTerm = false;
            s->array[--(s->t)] = new;
            return 0;

        }
        else {
            fprintf(stderr, "V expression_parser neexistuje redukcne pravidlo.\n");
            return 2;
        }
    }
    else if((s->t - 3) == tmp) {
        if(s->array[s->t]->t == T_EXPR && s->array[(s->t)-2]->t == T_EXPR && s->array[(s->t)-1] != NULL) {
            if(s->array[(s->t)-1]->t == T_OP || s->array[(s->t)-1]->t == T_OP_REL) {
                if (s->array[(s->t)-1]->tok->type==DIV) {
                  if ((s->array[(s->t)]->d_type==T_INT)&&(!strcmp(s->array[(s->t)]->tok->value->str,"0"))) {
                    fprintf(stderr, "ERROR: Zero division\n");
                    return RUNN_ERROR;
                  }else if ((s->array[(s->t)]->d_type==T_FLOAT)&&(!strcmp(s->array[(s->t)]->tok->value->str,"0x0p+0"))){
                    fprintf(stderr, "ERROR: Zero division\n");
                    return RUNN_ERROR;
                  }
                }
                st_item *new_item = type_control(l, s->array[(s->t)-2], s->array[s->t], s->array[(s->t)-1]->tok);
                if (new_item == NULL) {
                    fprintf(stderr, "Nastala chyba! Operatory su nekompatibilne.\n");
                    return 4;
                }
                //new_item->tok = s->array[(s->t)-1]->tok;
                s->t -= 3;
                s->array[s->t] = new_item;
            }
            else {
                fprintf(stderr, "Neexistuje pravidlo pre operator %d\n", s->array[s->t]->t);
                return 2;
            }
        }
        else if (s->array[(s->t)-1]->t == T_EXPR && s->array[(s->t)-2]->t == T_OP && s->array[s->t]->t == T_OP) {
            if (!strcmp(s->array[(s->t)-2]->tok->value->str,"(") && !strcmp(s->array[s->t]->tok->value->str,")")) { //(s->array[(s->t)-2]->tok->type == RBRACKET)
                s->array[(s->t)-3] = s->array[(s->t)-1];
                s->t -=3;
            }
            else {
                fprintf(stderr, "Neexistuje pravidlo pre operatory %d, %d\n", s->array[(s->t)-2]->t, s->array[s->t-2]->t);
                return 2;
            }
        }
        else {
            fprintf(stderr, "Nespravna konstalacia pre aplikaciu pravidla.\n");
            return 2;
        }
    }
    else  {
        fprintf(stderr, "V expression_parser neexistuje redukcne pravidlo.\n");
        return 2;
    }

    return 0;
}

int idx_from_it(st_item *it){
    if (it->t == T_ID)
        return 0;
    else if(it->t == T_VAL)
        return 1;
    else if(it->t == T_OP) {
        if (it->tok != NULL){
            if (!strcmp(it->tok->value->str, "("))
                return 2;
            else if (!strcmp(it->tok->value->str, ")"))
                return 3;
            else if (!strcmp(it->tok->value->str, "+"))
                return 4;
            else if (!strcmp(it->tok->value->str, "-"))
                return 5;
            else if (!strcmp(it->tok->value->str, "*"))
                return 6;
            else if (!strcmp(it->tok->value->str, "/"))
                return 7;
        }
    }else if(it->t == T_ST_BTM)
        return 8;
    else if(it->t == T_OP_REL) {
        if (it->tok != NULL){
            if (!strcmp(it->tok->value->str, "=="))
                return 9;
            else if (!strcmp(it->tok->value->str, "!="))
                return 10;
            else if (!strcmp(it->tok->value->str, "<"))
                return 11;
            else if (!strcmp(it->tok->value->str, "<="))
                return 12;
            else if (!strcmp(it->tok->value->str, ">"))
                return 13;
            else if (!strcmp(it->tok->value->str, ">="))
                return 14;
        }
    }
    else return -1;
    return -1;
}

var_types terminal_d_type(st_item *it,localTable *ltab) {

    struct local_symbol  *s_item = local_Search(ltab, it->tok->value->str);
    if (s_item == NULL) {
        fprintf(stderr, "ERR: premenna %s nedefinovana!\n", it->tok->value->str);
        return T_ELSE;
    }

    if (s_item->type == T_INT) {
        return T_INT;
    }
    else if (s_item->type == T_FLOAT) {
        return T_FLOAT;
    }
    else if (s_item->type == T_STRING) {
        return T_STRING;
    }
    else if (s_item->type == T_NIL) {
        return T_NIL;
    }
    else{
        fprintf(stderr, "Nastala chyba! Premenna je neznameho typu.\n");
        return T_ELSE;
    }
}


var_types data_type_from_str(char * val) {
    if (!strcmp(val, "integer"))
        return 0;
    else if(!strcmp(val, "float"))
        return 1;
    else if(!strcmp(val, "string"))
        return 2;
    else return 4;
}
void inst_fill(List* il,op_enum op,char*pref1,char *var1,char*pref2,char *var2,char*pref3,char *var3){
    Ad ad1,ad2,ad3;
    if ((var1==NULL)||(pref1 == NULL)) {
        ad1.t = AD_T_E;
        ad1.s = NULL;
    }else{
        ad1 = ad_for_symbol(pref1,var1);
    }
    if ((var2==NULL)||(pref2 == NULL)) {
        ad2.t = AD_T_E;
        ad2.s = NULL;
    }else{
        ad2 = ad_for_symbol(pref2,var2);
    }
    if ((var3==NULL)||(pref3 == NULL)) {
        ad3.t = AD_T_E;
        ad3.s = NULL;
    }else{
        ad3 = ad_for_symbol(pref3,var3);
    }
    Ins* i = init_ins(op,ad1,ad2,ad3);
    add_to_il(il, i);
}

int int2double_convert (List *l,struct stack_item **item1, struct stack_item **item2){
    char *u_id = gen_u();
    if (((*item1)->d_type == T_INT)&&((*item2)->d_type == T_FLOAT)) {
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_INT2FLOAT, "LF@", u_id, "LF@", (*item1)->var_n,NULL,NULL);
      (*item1)->var_n=u_id;
    }else if (((*item1)->d_type == T_FLOAT)&&((*item2)->d_type == T_INT)) {
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_INT2FLOAT, "LF@", u_id, "LF@", (*item2)->var_n,NULL,NULL);
      (*item2)->var_n=u_id;
    }else{//chyba vysledok porovnania bude nil
        return TYPE_ERROR;
    }
    return SUCC;
}


struct stack_item *type_control(List *l,struct stack_item *item1, struct stack_item *item2, stToken *op){
  int err_n = 0;
  struct stack_item *vys =  s_item_init();
  if((item1->tok->type!=IDENTIFICATOR)&&(item2->tok->type!=IDENTIFICATOR)){
    if ((op->type == MINUS)||(op->type == MUL)) {
        if (item1->d_type == item2->d_type) {
            if (item1->d_type != T_STRING) {
                vys->d_type = item1->d_type;
                char *u_id=gen_u();
                  inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
                if (op->type == MINUS) {
                    inst_fill(l,OP_SUB, "LF@", u_id,"LF@",item1->var_n,"LF@",item2->var_n);
                }else{
                    inst_fill(l,OP_MUL, "LF@", u_id,"LF@",item1->var_n,"LF@",item2->var_n);
                }
                vys->var_n = u_id;
                return vys;
            }else{
                return NULL;
                //odpocitavanie a nasobenie string nie je dovolene
            }
        }else{//rozny type
            err_n = int2double_convert(l,&item1,&item2);
            if (err_n!=0) {
                return NULL;
            }
            vys->d_type = T_FLOAT;
            char *u_id=gen_u();
              inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
            if (op->type == MINUS) {
              inst_fill(l,OP_SUB, "LF@", u_id,"LF@",item1->var_n,"LF@",item2->var_n);
            }else{
              inst_fill(l,OP_MUL, "LF@", u_id,"LF@",item1->var_n,"LF@",item2->var_n);
            }
            vys->var_n = u_id;
            return vys;
        }
    }else if (op->type == PLUS) {
        if (item1->d_type == item2->d_type) {
            char *u_id=gen_u();
              inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
            if (item1->d_type == T_STRING) {
                inst_fill(l,OP_CONCAT, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
            }else{
                inst_fill(l,OP_ADD, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
            }
            vys->d_type = item1->d_type;
            vys->var_n = u_id;
            return vys;
        }else{
            err_n = int2double_convert(l,&item1,&item2);
            if (err_n!=0) {
                return NULL;
            }
            vys->d_type = T_FLOAT;
            char *u_id=gen_u();
              inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_ADD, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
            vys->var_n = u_id;
            return vys;
        }
    }else if (op->type == DIV){
        vys->d_type = T_FLOAT;
        if (item1->d_type == item2->d_type) {
            if (item1->d_type == T_FLOAT) {
                char *u_id=gen_u();
                  inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
                inst_fill(l,OP_DIV, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
                vys->var_n = u_id;
            }else if (item1->d_type == T_INT) {
                vys->d_type = T_INT;
                char *u_id=gen_u();
                char *u_id1=gen_u();
                char *u_id2=gen_u();
                  inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
                  inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
                  inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id2,NULL,NULL,NULL,NULL);
                inst_fill(l,OP_INT2FLOAT, "LF@", u_id1, "LF@", item1->var_n,NULL,NULL);
                inst_fill(l,OP_INT2FLOAT, "LF@", u_id2, "LF@", item2->var_n,NULL,NULL);
                inst_fill(l,OP_DIV, "LF@", u_id, "LF@", u_id1 , "LF@", u_id2);
                inst_fill(l,OP_FLOAT2INT,"LF@", u_id, "LF@", u_id,NULL,NULL);
                vys->var_n = u_id;
                return vys;
            }
        }else {//rozdielne typy
            err_n = int2double_convert(l,&item1,&item2);
            if (err_n!=0) {
                return NULL;
            }
            char *u_id=gen_u();
              inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_DIV, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
            vys->var_n = u_id;
        }
        return vys;
    }else if(!strcmp(op->value->str, "<")||!strcmp(op->value->str, ">")||!strcmp(op->value->str, "<=")||!strcmp(op->value->str, ">=")||!strcmp(op->value->str, "!=")||!strcmp(op->value->str, "==")){
        if ((item1->d_type == T_NIL)||(item2->d_type == T_NIL)) {
          if (!strcmp(op->value->str, "!=")||!strcmp(op->value->str, "==")) {
            vys->d_type = T_BOOL;
            char *u_id_nil=gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id_nil,NULL,NULL,NULL,NULL);
            if ((item1->d_type == T_NIL)&&(item2->d_type != T_NIL)) {
              if (!strcmp(op->value->str, "!=")) {
                inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","true",NULL,NULL);
              }else{
                inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","false",NULL,NULL);
              }
            }else if ((item1->d_type != T_NIL)&&(item2->d_type == T_NIL)) {
              if (!strcmp(op->value->str, "!=")) {
                inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","true",NULL,NULL);
              }else{
                inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","false",NULL,NULL);
              }
            }else if ((item1->d_type == T_NIL)&&(item2->d_type == T_NIL)) {
              if (!strcmp(op->value->str, "!=")) {
                inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","false",NULL,NULL);
              }else{
                inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","true",NULL,NULL);
              }
            }
            vys->var_n=u_id_nil;
            return vys;
          }else{//chyba
            return NULL;
          }
        }
        if (item1->d_type != item2->d_type) {
            err_n = int2double_convert(l,&item1,&item2);
            if (err_n!=0) {
                return NULL;
            }
        }
        char *u_id=gen_u();
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        vys->d_type = T_BOOL;
        vys->var_n = u_id;
        if(!strcmp(op->value->str, "<")){//<
            inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, ">")) {//>
            inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, ">=")) {//> or =
            inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            char *u_id1=gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
        } else if (!strcmp(op->value->str, "<=")) {//< or =
            inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            char *u_id1=gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
        } else if (!strcmp(op->value->str, "==")) {//=
            inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, "!=")) {//not =
            inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_NOT, "LF@", u_id,  "LF@", u_id,NULL,NULL);
        }
        return vys;
    }else {
        return NULL;
    }
    return NULL;
  }else if((item1->tok->type==IDENTIFICATOR)&&(item2->tok->type!=IDENTIFICATOR)){
    char *re =item1->var_n;
    if (item2->d_type == T_NIL) {
      if (!strcmp(op->value->str, "!=")||!strcmp(op->value->str, "==")) {
        char *u_id_nil=gen_u();
        char *t1_nil=gen_u();
        char *comp_nil=gen_u();
        char *label_nil=gen_u();
        char *label_nil_e=gen_u();
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id_nil,NULL,NULL,NULL,NULL);
        inst_fill(while_def_il,OP_DEFVAR, "LF@", comp_nil,NULL,NULL,NULL,NULL);
        inst_fill(while_def_il,OP_DEFVAR, "LF@", t1_nil,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_TYPE,"LF@",t1_nil,"LF@",item1->var_n,NULL,NULL);
        inst_fill(l,OP_EQ, "LF@", comp_nil, "LF@", t1_nil , "string@", "nil");
        if (!strcmp(op->value->str, "!=")) {
          inst_fill(l,OP_JUMPIFEQ,"",label_nil,"LF@",comp_nil,"bool@","true");
          inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","true",NULL,NULL);
          inst_fill(l,OP_JUMP, "", label_nil_e,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_LABEL, "", label_nil,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","false",NULL,NULL);
        }else{
          inst_fill(l,OP_JUMPIFEQ,"",label_nil,"LF@",comp_nil,"bool@","true");
          inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","false",NULL,NULL);
          inst_fill(l,OP_JUMP, "", label_nil_e,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_LABEL, "", label_nil,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","true",NULL,NULL);
        }
        inst_fill(l,OP_LABEL, "", label_nil_e,NULL,NULL,NULL,NULL);
        vys->d_type = T_BOOL;
        vys->var_n=u_id_nil;
        return vys;
      }else{//chyba
        return NULL;
      }
    }
    if(item2->d_type==T_INT){
      char *t_it1 = gen_u();
      char *c = gen_u();
      char *no_c = gen_u();
      inst_fill(while_def_il,OP_DEFVAR, "LF@", t_it1,NULL,NULL,NULL,NULL);
      inst_fill(while_def_il,OP_DEFVAR, "LF@", c,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_TYPE,"LF@",t_it1,"LF@",item1->var_n,NULL,NULL);
      inst_fill(l,OP_EQ, "LF@", c, "LF@", t_it1 , "string@", "int");
      inst_fill(l,OP_JUMPIFEQ,"",no_c,"LF@",c,"bool@","true");
      inst_fill(l,OP_EQ, "LF@", c, "LF@", t_it1 , "string@", "float");
      inst_fill(l,OP_JUMPIFNEQ,"","$error4_exit","LF@",c,"bool@","true");
      inst_fill(l,OP_INT2FLOAT, "LF@", item2->var_n, "LF@", item2->var_n,NULL,NULL);
      inst_fill(l,OP_LABEL, "", no_c,NULL,NULL,NULL,NULL);
    }else{
      re = type_asm_ch(l,item1->var_n,item2->d_type);//v pripade ze je potrebne pretypovenia urobi sa tu
    }
    if ((item2->d_type==T_INT)||(item2->d_type==T_FLOAT)) {
      item1->var_n = re;
      vys->d_type = item2->d_type;
      char *u_id=gen_u();
      vys->var_n = u_id;
      inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
      if (op->type==PLUS) {
        inst_fill(l,OP_ADD, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      }else if (op->type==MINUS){
        inst_fill(l,OP_SUB, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      }else if (op->type==MUL){
        inst_fill(l,OP_MUL, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      }else if (op->type==DIV){
        if(item2->d_type==T_INT){//celociselne delenie
          char *not_i = gen_u();
          char *jmp = gen_u();
          char *id1 = gen_u();
          char *id2 = gen_u();
          char *it1 = gen_u();
          char *cm = gen_u();
          inst_fill(while_def_il,OP_DEFVAR, "LF@", id1,NULL,NULL,NULL,NULL);
          inst_fill(while_def_il,OP_DEFVAR, "LF@", id2,NULL,NULL,NULL,NULL);
          inst_fill(while_def_il,OP_DEFVAR, "LF@", it1,NULL,NULL,NULL,NULL);
          inst_fill(while_def_il,OP_DEFVAR, "LF@", cm,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_TYPE,"LF@",it1,"LF@",item1->var_n,NULL,NULL);
          inst_fill(l,OP_EQ, "LF@", cm, "LF@", it1 , "string@", "int");
          inst_fill(l,OP_JUMPIFNEQ,"",not_i,"LF@",cm,"bool@","true");
          inst_fill(l,OP_INT2FLOAT, "LF@", id1, "LF@", item1->var_n,NULL,NULL);
          inst_fill(l,OP_INT2FLOAT, "LF@", id2, "LF@", item2->var_n,NULL,NULL);
          inst_fill(l,OP_DIV, "LF@", u_id, "LF@", id1, "LF@", id2);
          inst_fill(l,OP_FLOAT2INT, "LF@", u_id, "LF@", u_id,NULL,NULL);
          inst_fill(l,OP_JUMP, "", jmp,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_LABEL, "", not_i,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_DIV, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
          inst_fill(l,OP_LABEL, "", jmp,NULL,NULL,NULL,NULL);
        }else{
          inst_fill(l,OP_DIV, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
        }
      }else if(!strcmp(op->value->str, "<")||!strcmp(op->value->str, ">")||!strcmp(op->value->str, "<=")||!strcmp(op->value->str, ">=")||!strcmp(op->value->str, "!=")||!strcmp(op->value->str, "==")){
        vys->d_type = T_BOOL;
        if(!strcmp(op->value->str, "<")){//<
            inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, ">")) {//>
            inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, ">=")) {//> or =
            inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            char *u_id1=gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
        } else if (!strcmp(op->value->str, "<=")) {//< or =
            inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            char *u_id1=gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
        } else if (!strcmp(op->value->str, "==")) {//=
            inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, "!=")) {//not =
            inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_NOT, "LF@", u_id,  "LF@", u_id,NULL,NULL);
        }
      }
      return vys;
    }else if(item2->d_type==T_STRING){
      if (op->type == PLUS) {
        char *u_id=gen_u();
        vys->var_n = u_id;
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_CONCAT, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
        vys->d_type = T_STRING;
        return vys;
      }else if(!strcmp(op->value->str, "<")||!strcmp(op->value->str, ">")||!strcmp(op->value->str, "<=")||!strcmp(op->value->str, ">=")||!strcmp(op->value->str, "!=")||!strcmp(op->value->str, "==")){
        vys->d_type = T_BOOL;
        char *u_id=gen_u();
        vys->var_n = u_id;
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        if(!strcmp(op->value->str, "<")){//<
            inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, ">")) {//>
            inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, ">=")) {//> or =
            inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            char *u_id1=gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
        } else if (!strcmp(op->value->str, "<=")) {//< or =
            inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            char *u_id1=gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
        } else if (!strcmp(op->value->str, "==")) {//=
            inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, "!=")) {//not =
            inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_NOT, "LF@", u_id,  "LF@", u_id,NULL,NULL);
        }
        return vys;
      }else{
        return NULL;
      }
    }else if(item2->d_type==T_NIL){
      return NULL;
    }else{
      return NULL;
    }
  }else if((item1->tok->type!=IDENTIFICATOR)&&(item2->tok->type==IDENTIFICATOR)){
    char *re =item2->var_n;
    if (item1->d_type == T_NIL) {
      if (!strcmp(op->value->str, "!=")||!strcmp(op->value->str, "==")) {
        char *u_id_nil=gen_u();
        char *t2_nil=gen_u();
        char *comp_nil=gen_u();
        char *label_nil=gen_u();
        char *label_nil_e=gen_u();
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id_nil,NULL,NULL,NULL,NULL);
        inst_fill(while_def_il,OP_DEFVAR, "LF@", comp_nil,NULL,NULL,NULL,NULL);
        inst_fill(while_def_il,OP_DEFVAR, "LF@", t2_nil,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_TYPE,"LF@",t2_nil,"LF@",item2->var_n,NULL,NULL);
        inst_fill(l,OP_EQ, "LF@", comp_nil, "LF@", t2_nil , "string@", "nil");
        if (!strcmp(op->value->str, "!=")) {
          inst_fill(l,OP_JUMPIFEQ,"",label_nil,"LF@",comp_nil,"bool@","true");
          inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","true",NULL,NULL);
          inst_fill(l,OP_JUMP, "", label_nil_e,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_LABEL, "", label_nil,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","false",NULL,NULL);
        }else{
          inst_fill(l,OP_JUMPIFEQ,"",label_nil,"LF@",comp_nil,"bool@","true");
          inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","false",NULL,NULL);
          inst_fill(l,OP_JUMP, "", label_nil_e,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_LABEL, "", label_nil,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_MOVE,"LF@",u_id_nil,"bool@","true",NULL,NULL);
        }
        inst_fill(l,OP_LABEL, "", label_nil_e,NULL,NULL,NULL,NULL);
        vys->d_type = T_BOOL;
        vys->var_n=u_id_nil;
        return vys;
      }else{//chyba
        return NULL;
      }
    }
    if (op->type==DIV){
      char *t2_div_0 = gen_u();//typ
      char *c_div_0 = gen_u();//compare
      char *l_i_div_0 = gen_u();//label int
      char *l_e_div_0 = gen_u();//label end control
      inst_fill(while_def_il,OP_DEFVAR, "LF@", c_div_0,NULL,NULL,NULL,NULL);
      inst_fill(while_def_il,OP_DEFVAR, "LF@", t2_div_0,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_TYPE,"LF@",t2_div_0,"LF@",item2->var_n,NULL,NULL);
      inst_fill(l,OP_EQ,"LF@",c_div_0,"LF@",t2_div_0,"string@","float");
      inst_fill(l,OP_JUMPIFNEQ,"",l_i_div_0,"LF@",c_div_0,"bool@","true");
      inst_fill(l,OP_EQ,"LF@",c_div_0,"LF@",item2->var_n,"float@","0x0p+0");
      inst_fill(l,OP_JUMPIFEQ,"","$error9_exit","LF@",c_div_0,"bool@","true");
      inst_fill(l,OP_JUMP,"",l_e_div_0,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_LABEL,"",l_i_div_0,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_EQ,"LF@",c_div_0,"LF@",t2_div_0,"string@","int");
      inst_fill(l,OP_JUMPIFNEQ,"",l_e_div_0,"LF@",c_div_0,"bool@","true");
      inst_fill(l,OP_EQ,"LF@",c_div_0,"LF@",item2->var_n,"int@","0");
      inst_fill(l,OP_JUMPIFEQ,"","$error9_exit","LF@",c_div_0,"bool@","true");
      inst_fill(l,OP_LABEL,"",l_e_div_0,NULL,NULL,NULL,NULL);
    }
    if(item1->d_type==T_INT){
      char *t_it2 = gen_u();
      char *c = gen_u();
      char *no_c = gen_u();
        inst_fill(while_def_il,OP_DEFVAR, "LF@", t_it2,NULL,NULL,NULL,NULL);
        inst_fill(while_def_il,OP_DEFVAR, "LF@", c,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_TYPE,"LF@",t_it2,"LF@",item2->var_n,NULL,NULL);
      inst_fill(l,OP_EQ, "LF@", c, "LF@", t_it2 , "string@", "int");
      inst_fill(l,OP_JUMPIFEQ,"",no_c,"LF@",c,"bool@","true");
      inst_fill(l,OP_EQ, "LF@", c, "LF@", t_it2 , "string@", "float");
      inst_fill(l,OP_JUMPIFNEQ,"","$error4_exit","LF@",c,"bool@","true");
      inst_fill(l,OP_INT2FLOAT, "LF@", item1->var_n, "LF@", item1->var_n,NULL,NULL);
      inst_fill(l,OP_LABEL, "", no_c,NULL,NULL,NULL,NULL);
    }else{
      re = type_asm_ch(l,item2->var_n,item1->d_type);//v pripade ze je potrebne pretypovenia urobi sa tu
    }
    if ((item1->d_type==T_INT)||(item1->d_type==T_FLOAT)) {
      item2->var_n = re;
      vys->d_type = item1->d_type;
      char *u_id=gen_u();
      vys->var_n = u_id;
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
      if (op->type==PLUS) {
        inst_fill(l,OP_ADD, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      }else if (op->type==MINUS){
        inst_fill(l,OP_SUB, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      }else if (op->type==MUL){
        inst_fill(l,OP_MUL, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      }else if (op->type==DIV){
        if(item1->d_type==T_INT){//celociselne delenie
          char *not_i = gen_u();
          char *jmp = gen_u();
          char *id1 = gen_u();
          char *id2 = gen_u();
          char *it2 = gen_u();
          char *cm = gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", id1,NULL,NULL,NULL,NULL);
            inst_fill(while_def_il,OP_DEFVAR, "LF@", id2,NULL,NULL,NULL,NULL);
            inst_fill(while_def_il,OP_DEFVAR, "LF@", it2,NULL,NULL,NULL,NULL);
            inst_fill(while_def_il,OP_DEFVAR, "LF@", cm,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_TYPE,"LF@",it2,"LF@",item2->var_n,NULL,NULL);
          inst_fill(l,OP_EQ, "LF@", cm, "LF@", it2 , "string@", "int");
          inst_fill(l,OP_JUMPIFNEQ,"",not_i,"LF@",cm,"bool@","true");
          inst_fill(l,OP_INT2FLOAT, "LF@", id1, "LF@", item1->var_n,NULL,NULL);
          inst_fill(l,OP_INT2FLOAT, "LF@", id2, "LF@", item2->var_n,NULL,NULL);
          inst_fill(l,OP_DIV, "LF@", u_id, "LF@", id1, "LF@", id2);
          inst_fill(l,OP_FLOAT2INT, "LF@", u_id, "LF@", u_id,NULL,NULL);
          inst_fill(l,OP_JUMP, "", jmp,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_LABEL, "", not_i,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_DIV, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
          inst_fill(l,OP_LABEL, "", jmp,NULL,NULL,NULL,NULL);
        }else{
          inst_fill(l,OP_DIV, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
        }
      }else if(!strcmp(op->value->str, "<")||!strcmp(op->value->str, ">")||!strcmp(op->value->str, "<=")||!strcmp(op->value->str, ">=")||!strcmp(op->value->str, "!=")||!strcmp(op->value->str, "==")){
        vys->d_type = T_BOOL;
        if(!strcmp(op->value->str, "<")){//<
            inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, ">")) {//>
            inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, ">=")) {//> or =
            inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            char *u_id1=gen_u();
              inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
        } else if (!strcmp(op->value->str, "<=")) {//< or =
            inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            char *u_id1=gen_u();
              inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
        } else if (!strcmp(op->value->str, "==")) {//=
            inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, "!=")) {//not =
            inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_NOT, "LF@", u_id,  "LF@", u_id,NULL,NULL);
        }
      }
      return vys;
    }else if(item1->d_type==T_STRING){
      if (op->type == PLUS) {
        char *u_id=gen_u();
        vys->var_n = u_id;
          inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_CONCAT, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
        vys->d_type = T_STRING;
        return vys;
      }else if(!strcmp(op->value->str, "<")||!strcmp(op->value->str, ">")||!strcmp(op->value->str, "<=")||!strcmp(op->value->str, ">=")||!strcmp(op->value->str, "!=")||!strcmp(op->value->str, "==")){
        vys->d_type = T_BOOL;
        char *u_id=gen_u();
        vys->var_n = u_id;
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        if(!strcmp(op->value->str, "<")){//<
            inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, ">")) {//>
            inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, ">=")) {//> or =
            inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            char *u_id1=gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
        } else if (!strcmp(op->value->str, "<=")) {//< or =
            inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            char *u_id1=gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
        } else if (!strcmp(op->value->str, "==")) {//=
            inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
        } else if (!strcmp(op->value->str, "!=")) {//not =
            inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
            inst_fill(l,OP_NOT, "LF@", u_id,  "LF@", u_id,NULL,NULL);
        }
        return vys;
      }else{
        return NULL;
      }
    }else if(item1->d_type==T_NIL){
      return NULL;
    }else{
      return NULL;
    }
  }else{//oba su identifikatory
    if (op->type==DIV){
      char *t2_div_0 = gen_u();//typ
      char *c_div_0 = gen_u();//compare
      char *l_i_div_0 = gen_u();//label int
      char *l_e_div_0 = gen_u();//label end control
        inst_fill(while_def_il,OP_DEFVAR, "LF@", c_div_0,NULL,NULL,NULL,NULL);
        inst_fill(while_def_il,OP_DEFVAR, "LF@", t2_div_0,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_TYPE,"LF@",t2_div_0,"LF@",item2->var_n,NULL,NULL);
      inst_fill(l,OP_EQ,"LF@",c_div_0,"LF@",t2_div_0,"string@","float");
      inst_fill(l,OP_JUMPIFNEQ,"",l_i_div_0,"LF@",c_div_0,"bool@","true");
      inst_fill(l,OP_EQ,"LF@",c_div_0,"LF@",item2->var_n,"float@","0x0p+0");
      inst_fill(l,OP_JUMPIFEQ,"","$error9_exit","LF@",c_div_0,"bool@","true");
      inst_fill(l,OP_JUMP,"",l_e_div_0,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_LABEL,"",l_i_div_0,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_EQ,"LF@",c_div_0,"LF@",t2_div_0,"string@","int");
      inst_fill(l,OP_JUMPIFNEQ,"",l_e_div_0,"LF@",c_div_0,"bool@","true");
      inst_fill(l,OP_EQ,"LF@",c_div_0,"LF@",item2->var_n,"int@","0");
      inst_fill(l,OP_JUMPIFEQ,"","$error9_exit","LF@",c_div_0,"bool@","true");
      inst_fill(l,OP_LABEL,"",l_e_div_0,NULL,NULL,NULL,NULL);
    }
    char *t1=gen_u();
    char *t2=gen_u();
    char *u_id=gen_u();
    vys->var_n = u_id;
      inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
      inst_fill(while_def_il,OP_DEFVAR, "LF@", t1,NULL,NULL,NULL,NULL);
      inst_fill(while_def_il,OP_DEFVAR, "LF@", t2,NULL,NULL,NULL,NULL);
    inst_fill(l,OP_TYPE,"LF@",t1,"LF@",item1->var_n,NULL,NULL);
    inst_fill(l,OP_TYPE,"LF@",t2,"LF@",item2->var_n,NULL,NULL);
    char *comp=gen_u();
      inst_fill(while_def_il,OP_DEFVAR, "LF@", comp,NULL,NULL,NULL,NULL);
    inst_fill(l,OP_EQ, "LF@", comp, "LF@", t1 , "LF@", t2);
    char *no_conv=gen_u();
    inst_fill(l,OP_JUMPIFEQ,"",no_conv,"LF@",comp,"bool@","true");
    inst_fill(l,OP_EQ, "LF@", comp, "LF@", t1 , "string@", "int");
    char *not_int=gen_u();
    char *i2f=gen_u();
      inst_fill(while_def_il,OP_DEFVAR, "LF@", i2f,NULL,NULL,NULL,NULL);
    inst_fill(l,OP_JUMPIFEQ,"",not_int,"LF@",comp,"bool@","true");
    inst_fill(l,OP_EQ, "LF@", comp, "LF@", t2 , "string@", "float");
    inst_fill(l,OP_JUMPIFNEQ,"","$error4_exit","LF@",comp,"bool@","true");
    inst_fill(l,OP_INT2FLOAT, "LF@", i2f, "LF@", item1->var_n,NULL,NULL);
    inst_fill(l,OP_MOVE, "LF@", item1->var_n,"LF@",i2f,NULL,NULL);
    inst_fill(l,OP_LABEL,"",not_int,NULL,NULL,NULL,NULL);
    inst_fill(l,OP_EQ, "LF@", comp, "LF@", t1 , "string@", "float");
    inst_fill(l,OP_JUMPIFNEQ,"","$error4_exit","LF@",comp,"bool@","true");
    inst_fill(l,OP_EQ, "LF@", comp, "LF@", t2 , "string@", "int");
    inst_fill(l,OP_JUMPIFNEQ,"","$error4_exit","LF@",comp,"bool@","true");
    inst_fill(l,OP_INT2FLOAT, "LF@", i2f, "LF@", item2->var_n,NULL,NULL);
    inst_fill(l,OP_MOVE, "LF@", item2->var_n,"LF@",i2f,NULL,NULL);
    inst_fill(l,OP_LABEL,"",no_conv,NULL,NULL,NULL,NULL);
    if (op->type==PLUS) {
      inst_fill(l,OP_EQ, "LF@", comp, "LF@", t1 , "string@", "string");
      char *n_s=gen_u();
      inst_fill(l,OP_JUMPIFNEQ,"",n_s,"LF@",comp,"bool@","true");
      char *end_plus=gen_u();
      inst_fill(l,OP_CONCAT, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      inst_fill(l,OP_JUMP,"",end_plus,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_LABEL,"",n_s,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_ADD, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      inst_fill(l,OP_LABEL,"",end_plus,NULL,NULL,NULL,NULL);
    }else if (op->type==MINUS){
      inst_fill(l,OP_EQ, "LF@", comp, "LF@", t1 , "string@", "string");
      inst_fill(l,OP_JUMPIFEQ,"","$error4_exit","LF@",comp,"bool@","true");
      inst_fill(l,OP_SUB, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
    }else if (op->type==MUL){
      inst_fill(l,OP_EQ, "LF@", comp, "LF@", t1 , "string@", "string");
      inst_fill(l,OP_JUMPIFEQ,"","$error4_exit","LF@",comp,"bool@","true");
      inst_fill(l,OP_MUL, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
    }else if (op->type==DIV){
      char *divf=gen_u();
      char *div_end = gen_u();
      char *id1 = gen_u();
      char *id2 = gen_u();
        inst_fill(while_def_il,OP_DEFVAR, "LF@", id1,NULL,NULL,NULL,NULL);
        inst_fill(while_def_il,OP_DEFVAR, "LF@", id2,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_EQ, "LF@", comp, "LF@", t1 , "string@", "string");
      inst_fill(l,OP_JUMPIFEQ,"","$error4_exit","LF@",comp,"bool@","true");
      inst_fill(l,OP_EQ, "LF@", comp, "LF@", t1 , "string@", "nil");
      inst_fill(l,OP_JUMPIFEQ,"","$error4_exit","LF@",comp,"bool@","true");
      inst_fill(l,OP_EQ, "LF@", comp, "LF@", t1 , "string@", "int");
      inst_fill(l,OP_JUMPIFNEQ,"",divf,"LF@",comp,"bool@","true");
      inst_fill(l,OP_INT2FLOAT, "LF@", id1, "LF@", item1->var_n,NULL,NULL);
      inst_fill(l,OP_INT2FLOAT, "LF@", id2, "LF@", item2->var_n,NULL,NULL);
      inst_fill(l,OP_DIV, "LF@", u_id, "LF@", id1, "LF@", id2);
      inst_fill(l,OP_FLOAT2INT, "LF@", u_id, "LF@", u_id,NULL,NULL);
      inst_fill(l,OP_JUMP, "", div_end,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_LABEL,"",divf,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_DIV, "LF@", u_id, "LF@", item1->var_n, "LF@", item2->var_n);
      inst_fill(l,OP_LABEL, "", div_end,NULL,NULL,NULL,NULL);
    }else if(!strcmp(op->value->str, "<")||!strcmp(op->value->str, ">")||!strcmp(op->value->str, "<=")||!strcmp(op->value->str, ">=")||!strcmp(op->value->str, "!=")||!strcmp(op->value->str, "==")){
      vys->d_type = T_BOOL;
      if(!strcmp(op->value->str, "<")){//<
          inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
      } else if (!strcmp(op->value->str, ">")) {//>
          inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
      } else if (!strcmp(op->value->str, ">=")) {//> or =
          inst_fill(l,OP_GT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
          char *u_id1=gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
          inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
      } else if (!strcmp(op->value->str, "<=")) {//< or =
          inst_fill(l,OP_LT, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
          char *u_id1=gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id1,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_EQ, "LF@", u_id1, "LF@", item1->var_n , "LF@", item2->var_n);
          inst_fill(l,OP_OR, "LF@", u_id,  "LF@", u_id,  "LF@", u_id1);
      } else if (!strcmp(op->value->str, "==")) {//=
          inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
      } else if (!strcmp(op->value->str, "!=")) {//not =
          inst_fill(l,OP_EQ, "LF@", u_id, "LF@", item1->var_n , "LF@", item2->var_n);
          inst_fill(l,OP_NOT, "LF@", u_id,  "LF@", u_id,NULL,NULL);
      }
    }
    return vys;
  }
}



struct stack_item *s_item_init(){
    struct stack_item *temp = (struct stack_item *) mm_malloc(sizeof(struct stack_item));
    temp->t = T_EXPR;
    temp->d_type = T_ELSE;
    temp->tok = mm_malloc(sizeof(stToken));
    temp->tok->type = IDENTIFICATOR;
    temp->isTerm = false;
    temp->var_n = NULL;
    return temp;
}


char *type_asm_ch (List *l,char *name,var_types type){
    char *u_id_t=gen_u();
    char *u_id_e=gen_u();
    char *label=gen_u();
    char *ret=gen_u();
    int ret_null = 1;
      inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id_t,NULL,NULL,NULL,NULL);
    inst_fill(l,OP_TYPE,"LF@",u_id_t,"LF@",name,NULL,NULL);
      inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id_e,NULL,NULL,NULL,NULL);
    if (type == T_NIL) {
        inst_fill(l,OP_EQ, "LF@",u_id_e,"LF@",u_id_t, "string@", "nil");
        inst_fill(l,OP_JUMPIFNEQ,"","$error4_exit","LF@",u_id_e,"bool@","true");
    }else if(type == T_INT){
          inst_fill(while_def_il,OP_DEFVAR, "LF@", ret,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_EQ, "LF@",u_id_e,"LF@",u_id_t, "string@", "int");
        inst_fill(l,OP_MOVE, "LF@", ret, "LF@", name,NULL,NULL);
        inst_fill(l,OP_JUMPIFEQ,"",label,"LF@",u_id_e,"bool@","true");
        inst_fill(l,OP_EQ, "LF@",u_id_e,"LF@",u_id_t, "string@", "float");
        inst_fill(l,OP_JUMPIFNEQ,"","$error4_exit","LF@",u_id_e,"bool@","true");//konverzia na float
        inst_fill(l,OP_FLOAT2INT, "LF@", ret, "LF@", name,NULL,NULL);
        ret_null = 0;
    }else if(type == T_FLOAT){
          inst_fill(while_def_il,OP_DEFVAR, "LF@", ret,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_EQ, "LF@",u_id_e,"LF@",u_id_t, "string@", "float");
        inst_fill(l,OP_MOVE, "LF@", ret, "LF@", name,NULL,NULL);
        inst_fill(l,OP_JUMPIFEQ,"",label,"LF@",u_id_e,"bool@","true");
        inst_fill(l,OP_EQ, "LF@",u_id_e,"LF@",u_id_t, "string@", "int");
        inst_fill(l,OP_JUMPIFNEQ,"","$error4_exit","LF@",u_id_e,"bool@","true");//konverzia na int
        inst_fill(l,OP_INT2FLOAT, "LF@", ret, "LF@", name,NULL,NULL);
        ret_null = 0;
    }else if(type == T_STRING){
        inst_fill(l,OP_EQ, "LF@",u_id_e,"LF@",u_id_t, "string@", "string");
        inst_fill(l,OP_JUMPIFNEQ,"","$error4_exit","LF@",u_id_e,"bool@","true");
    }else if(type == T_BOOL){
        inst_fill(l,OP_EQ, "LF@",u_id_e,"LF@",u_id_t, "string@", "string");
        inst_fill(l,OP_JUMPIFNEQ,"","$error4_exit","LF@",u_id_e,"bool@","true");
    }else {
        return NULL;
    }
    inst_fill(l,OP_LABEL,"",label,NULL,NULL,NULL,NULL);
    if (ret_null) {
        return NULL;
    } else {
        return ret;
    }
}
