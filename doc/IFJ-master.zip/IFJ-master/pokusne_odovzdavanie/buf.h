/**
 * Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Buffer, header file
 *
 * @author Viktoria Haleckova xhalec00
 *          
 */

#ifndef IFJ18_COMPILER_BUFFER_H
#define IFJ18_COMPILER_BUFFER_H

#include <stddef.h>
#include <stdbool.h>

#define CHUNK_BUF 10

/**
 * Buffer object structure
 *
 * Buffer allocates more memory than needed, to avoid large amount
 * of reallocations. Buffer is reallocated by BUFFER_CHUNK only
 * when it runs out of memory.
 *
 * Buffer always holds a valid C string in arr. Buffer takes
 * care of appending '\0' at the end of the string.
 */
typedef struct {
    char* string;              /// Character array with dimension of buffer_size
    size_t length;             /// Valid string length in arr
    size_t buff_size;     /// Allocated arr size
} Buff;

/**
 * Allocate new buffer of given size, size has to be at least 1 for binary zero.
 * Size is automatically clamped to at least 1
 * @param size ...
 * @return new Buffer
 */
Buff* init_buffer(size_t size);

/**
 * Deallocates buffer memory
 * @param b buffer
 */
void free_buffer(Buff* b);

/**
 * Append one character to buffer
 * @param b buffer
 * @param c character to append
 */
void append_char_to_buff(Buff* b, char c);

/**
 * Append string to buffer
 * @param b buffer
 * @param str string to append
 */
void append_string_to_buff(Buff* b, const char* str);

/**
 * Reallocates buffer to default size and sets length to 0
 * @param b buffer
 */
void clear_buffer(Buff* b);

/**
 * Copies given string to buffer
 * @param b buffer
 * @param str string to copy
 */
void set_string_to_buffer(Buff* b, const char* str);

/**
 * Debug print for buffer
 * @param b Buffer
 */
void debug_buffer(void* b);

#endif //IFJ18_COMPILER_BUFFER_H
