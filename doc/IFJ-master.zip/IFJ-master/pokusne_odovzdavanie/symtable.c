/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Symtable
 *
 * @author Patricia Ramosova xramos00
 */

#include "symtable.h"


int hashCode ( char* key ) {
    int retval = 1;
    int keylen = strlen(key);
    for ( int i=0; i<keylen; i++ )
        retval += key[i];
    return ( retval % 12289 );
}


void global_Init ( globalTable* ptr ) {

    if(ptr == NULL){
        return;
    }
    for(int i = 0; i < 12289; i++){
        ptr->tHTable[i] = NULL;
    }

}


struct global_symbol* global_Search ( globalTable* ptr, char* key ){

    int index = hashCode(key);
    struct global_symbol* tmp = ptr->tHTable[index];
    while(tmp != NULL){
        if(!strcmp(key, tmp->name)){
            return tmp;
        }
        tmp = tmp->next;
    }
    return NULL;
}



void global_InsertDeclared ( globalTable* ptr, char* name){

    int index = hashCode(name);

    struct global_symbol* newItem = mm_malloc(sizeof(struct global_symbol));
    if(newItem == NULL){
        return;
    }

    newItem->next = ptr->tHTable[index];
    ptr->tHTable[index] = newItem;
    newItem->name = name;
    newItem->isDeclared = true;
    newItem->isDefined = false;
    newItem->par = NULL;
    ptr->last = newItem;

}



void global_InsertDefined(globalTable* ptr, char* name){

    int index = hashCode(name);

    struct global_symbol* newItem = mm_malloc(sizeof(struct global_symbol));
    if(newItem == NULL){
        return;
    }

    newItem->next = ptr->tHTable[index];
    ptr->tHTable[index] = newItem;
    newItem->name = name;
    newItem->isDeclared = true;
    newItem->isDefined = true;
    newItem->par = NULL;
    ptr->last = newItem;

}



int global_isDeclared (globalTable* ptr, char* key){

    struct global_symbol* tmp = global_Search(ptr, key);

    if(tmp == NULL){
        return -1;
    }

    if(tmp->isDeclared){
        return 1;
    }
    return 0;
}



int global_isDefined (globalTable* ptr, char* key){

    struct global_symbol* tmp = global_Search(ptr, key);

    if(tmp == NULL){
        return -1;
    }

    if(tmp->isDefined){
        return 1;
    }
    return 0;
}



struct parameter* global_addParam (globalTable* ptr, struct parameter* param){

    if (ptr == NULL){
        return NULL;
    }
    if (ptr->last == NULL){
        return NULL;
    }
    struct parameter* tmp = ptr->last->par;
    if (tmp==NULL){
        ptr->last->par = param;
        return param;
    }
    while(tmp->next!=NULL){
        tmp = tmp->next;
    }
    tmp->next = param;
    return param;

}



void local_Init(localTable* ptr){

    if(ptr == NULL){
        return;
    }
    for(int i = 0; i < 12289; i++) {
        (*ptr)[i]= NULL;
    }
}



struct local_symbol* local_Search (localTable* ptr, char* key){

    int index = hashCode(key);
    struct local_symbol* tmp = (*ptr)[index];
    while(tmp != NULL){
        if(!strcmp(key, tmp->name)){
            return tmp;
        }
        tmp = tmp->next;
    }
    return NULL;
}



void local_InsertDeclared (localTable* ptr, struct local_symbol* symbol){

    int index = hashCode(symbol->name);

    symbol->next = (*ptr)[index];
    (*ptr)[index] = symbol;
}



int local_isDeclared (localTable* ptr, char* key){
    if (key == NULL)
        return 0;
    struct local_symbol* tmp = local_Search(ptr, key);

    if(tmp == NULL){
        return 0;
    }

    return 1;
}
