/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Parser
 *
 * @author Peter Dragúň xdragu01
 *         Jakub Sadílek xsadil07
 */
#include "parser.h"


#define GET_TOKEN  delete_token(tok); create_token(&tok); if(get_token(tok)==1){ fprintf(stderr,"Chyba pri nacitani tokenu\n"); return LEX_ERROR;}
#define SERROR(exp) fprintf(stderr,"SYNTAX ERROR on line %d : Expecting %s\n",line,exp); return(SYNTH_ERROR);
#define SEMERROR(exp,err) fprintf(stderr,"SEMANTIC ERROR on line %d : %s\n",line,exp); return(err);


globalTable *gtab;

int u_cnt = 0;//pre generovanie unikatnych premennych
stToken *tok;// -globalna premenna
int line = 0;//riadok v subore pre error nepocita riadky s blokovym komentarom resp. pocita za 1 riadok

char *gen_u(){
  char id[10] = {0};
  char *ptr = (char *) mm_malloc(11*sizeof(char));
  sprintf(id, "%d", u_cnt);
  u_cnt++;
  strcpy(ptr,"$");
  strcat(ptr, id);
  return ptr;
}

int check_sem_ud(char *name, struct parameter *p){
  struct global_symbol *f = global_Search (gtab, name);
  if (f->isDefined == false)
    return 0;
  struct parameter *ptr = p;
  while (f->par != NULL){
    if (ptr == NULL){
      fprintf(stderr, "Spatny pocet parametru funkce %s!\n", name);
      return PARAM_ERROR;
    }
    ptr = ptr->next;
    f->par = f->par->next;
  }
  if (ptr != NULL){
    fprintf(stderr, "Spatny pocet parametru funkce %s!\n", name);
    return PARAM_ERROR;
  }
  return 0;
}

int del_e_line(){//zmaze prazdne riadky
  while (tok->type == EOL) {
    GET_TOKEN;
    line++;
  }
  return SUCC;//pre kontrolu lexikalnej analyzy
}

int prog(){
  int err_n = 0;//ERROR NUMBER
  localTable *ltab;
  inst_fill(main_il,OP_CREATEFRAME, NULL, NULL, NULL,NULL, NULL, NULL);
  inst_fill(main_il,OP_PUSHFRAME, NULL, NULL, NULL,NULL, NULL, NULL);
  inst_fill(main_il,OP_JUMP,"$main_defvar","",NULL,NULL,NULL,NULL);
  inst_fill(main_il,OP_LABEL,"$b2main","",NULL,NULL,NULL,NULL);
  inst_fill(while_def_il,OP_LABEL,"$main_defvar","",NULL,NULL,NULL,NULL);
  ltab = mm_malloc(sizeof(localTable));
  local_Init(ltab);
  err_n = del_e_line();
  if (err_n != 0) {
    return err_n;
  }
  if (tok->type == END) {//pre pripad prazdneho suboru
    inst_fill(while_def_il,OP_JUMP,"$b2main","",NULL,NULL,NULL,NULL);
    return SUCC;
  }
  err_n = stat_list(0,ltab,false,main_il,NULL);
  if (err_n <= RETEND) {
    fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected end or else\n",line);
  }
  if ((err_n > 0)||(err_n <= RETEND)) { //chyba v programe najdi koniec riadku a pokracuj v analyze
    /*while (tok->type != EOL) {
      if (tok->type == END) {
        return SYNTH_ERROR;
      }
      GET_TOKEN;
    }
    GET_TOKEN;
    if (tok->type == END) {
      return SYNTH_ERROR;
    }
    line++;
    prog();*/
    if (err_n <= RETEND) {
      err_n = SYNTH_ERROR;
    }
    return err_n;
  }
  if (tok->type != END) {
    SERROR("EOF");
  }
  inst_fill(while_def_il,OP_JUMP,"$b2main","",NULL,NULL,NULL,NULL);
  return SUCC;
}

int stat_list (int ew,localTable *ltab, int def,List* l,char **last_stat_ret){
  if (tok->type == KEY_WORD) { //koniec sekvencie prikazov v definicii funkcie pripadne v if a while
    if (!strcmp(tok->value->str,"end")) {
      return RETEND;
    }else if (!strcmp(tok->value->str,"else")) {
      return RETELSE;
    }else if (!strcmp(tok->value->str,"do")) { //chyba
      fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected do\n",line);
      return(SYNTH_ERROR);
    }else if (!strcmp(tok->value->str,"then")) { //chyba
      fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected then\n",line);
      return(SYNTH_ERROR);
    }
  }
  int err_n = stat(ltab,def,l,last_stat_ret); //ERROR NUMBER
  if (err_n != 0) {
    return err_n;
  }
  if (tok->type != EOL) {//koniec riadku za instrukciou
    SERROR("EOL");
  }else{
    err_n = del_e_line();
    if (err_n != 0) {
      return err_n;
    }
  }
  if (tok->type == END) {//koniec suboru
    if (ew != 0) {
      fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected EOF\n",line);
      return(SYNTH_ERROR);
    }
    return SUCC;
  }
  err_n = stat_list(ew,ltab,def,l,last_stat_ret);
  if ((ew == 1)&&(err_n == RETEND)) {//skonict ak prisiel end
    return err_n;
  } else if ((ew == 2)&&(err_n == RETELSE)) {//skonict ak prisiel else
    return err_n;
  } else if (err_n <= RETEND){//prisiel end alebo else ale neocakavali sme ho
    fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected keyword\n",line);
    return(SYNTH_ERROR);
  }
  return err_n;
}
int check_sem_dek(globalTable *gtab, char *name, struct parameter *p){
  struct global_symbol *tmp = global_Search(gtab, name);
  if (tmp == NULL){
    fprintf(stderr, "Funkce nebyla nalezena\n");
    return UNDEF_ERROR;
  }
  struct parameter *ptr = p;
  while ((tmp != NULL) && (!strcmp(tmp->name, name))){
    while (ptr->type != T_NDEF){
      if (tmp->par->type != ptr->type){
        fprintf(stderr, "Spatny datovy typ argumentu funkce!\n");
        return PARAM_ERROR;
      }
      ptr = ptr->next;
      tmp->par = tmp->par->next;
    }
    if (tmp->par != NULL)
      return PARAM_ERROR;
    ptr = p;
    tmp = tmp->next;
  }
  return 0;
}
int stat(localTable *ltab,int def,List* l,char **last_stat_ret){
  int err_n = 0; //ERROR NUMBER
  if (tok->type == IDENTIFICATOR) {//funkcie a premenne
    char *name=mm_malloc(sizeof(char) * (tok->value->length+1));
    strcpy(name,tok->value->str);
    stToken *tok_id=tok;
    create_token(&tok);
    if(get_token(tok)==1){
      fprintf(stderr,"Chyba pri nacitani tokenu\n");
      delete_token(tok_id);
      return LEX_ERROR;
    }
    //GET_TOKEN;
    struct local_symbol *var = mm_malloc(sizeof(struct local_symbol));
    if (tok->type == EOL){//funkcia alebo premenna?
      delete_token(tok_id);
      if(!local_isDeclared(ltab,name)){
        if (global_isDefined(gtab,name)==0) {//nie je definovana ale je deklarovana
          if (!def) {
            SEMERROR("Not defined variable/function",UNDEF_ERROR);
          }else{
            struct global_symbol *tmp = global_Search(gtab, name);
            if (tmp->par == NULL){
              inst_fill(l,OP_CALL,"",name,NULL,NULL,NULL,NULL);
              return SUCC;
            }
            SEMERROR("Nespravny pocet parametrov",PARAM_ERROR);
          }
        }else if (global_isDefined(gtab,name)==-1) {//nie je deklaraovana
          if (def!=1) {
            SEMERROR("Not defined variable/function",UNDEF_ERROR);
          }else{
            global_InsertDeclared(gtab,name);
            global_addParam(gtab,NULL);
          }
        }//inak definovana funkcia
        if (def==1) {
          if(last_stat_ret!=NULL){
            char * u_id = gen_u();
            inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_CALL,"",name,NULL,NULL,NULL,NULL);
            inst_fill(l,OP_POPS,"LF@",u_id,NULL,NULL,NULL,NULL);
            *last_stat_ret = u_id;
          }
        }
        return SUCC;
      }
      if (def==1) {
        if(last_stat_ret!=NULL){
          *last_stat_ret = name;
        }
      }
      return SUCC;
    }
    if(!local_isDeclared(ltab,name)){
      if ((name[strlen(name)-1]=='!')||(name[strlen(name)-1]=='?')){
        fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected \"!\" or \"?\" in variable name\n",line);
        return(SYNTH_ERROR);
      }
      var->type = T_NIL;
      var->name = mm_malloc((strlen(name)+1)*sizeof(char));
      strcpy(var->name,name);
      local_InsertDeclared(ltab,var);
      inst_fill(while_def_il,OP_DEFVAR, "LF@", name,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_MOVE, "LF@", name,"nil@","nil",NULL,NULL);
    }
    if (tok->type != ASSIGNMENT){//pridat moznost funkcie
      unsigned int p_fun[]={LBRACKET,IDENTIFICATOR,INTEGER,STRING,DOUBLE,EOL};//EOL->funkcia bez zatvoriek a parametrov
      int n_fun = 0;//1->dalsia je funkcia 0->dalsi je vyraz
      for (int i = 0; i < 5; i++) {
        if (tok->type==p_fun[i]) {
          n_fun = 1;
          break;
        }
      }
      int dek = false;//funkcia nebola definovana ideme ju deklarovat(plati iba v definicii inej funkcie)
      if (n_fun) {
        delete_token(tok_id);
        if (global_isDefined(gtab,name)<=0) {
          //v definicii funkcie bez error inak semanticka chyba
          if((def==1)&&(global_isDeclared(gtab,name)<=0)){
            global_InsertDeclared(gtab,name);
            dek = true;
          }else if(!def){
            SEMERROR("Not defined function",UNDEF_ERROR);
          }//bola deklarovana ale nie definovana
        }
        struct parameter *p = mm_malloc(sizeof(struct parameter));
        if (dek) {
          if(!global_addParam(gtab,p)){
            return INTERN_ERROR;
          }
        }
        int *par_cnt = mm_malloc(sizeof(int));
        *par_cnt = 0;
        err_n = func(p,l,par_cnt,ltab);
        if (err_n) {
          return err_n;
        }
        if (check_sem_ud(name, p))
          return SEM_ERROR;
        else{
          if (def==1) {
            if(last_stat_ret!=NULL){//co sem ulozit? funkcia nebola deklarovana neviem aku bude mat navratovu hodnotu
              //last_stat_ret = expr_ret;
            }
          }
          return SUCC;
         }
      }else {
        token=tok_id;
        expr_ret_type *ret = mm_malloc(sizeof(expr_ret_type));
        ret = expr(0,l,ltab,tok);
        if (ret->err_id!=0) {
          return ret->err_id;
        }
        tok=token;
        if (def==1) {
          if(last_stat_ret!=NULL){
            *last_stat_ret = ret->var_name;
          }
        }
        return SUCC;
      }
    }
    delete_token(tok_id);
    GET_TOKEN;
    var_types *t = mm_malloc(sizeof(int));
    char *expr_ret = mm_malloc(sizeof(char));
    err_n = value(t,def,l,ltab,&expr_ret);
    if (err_n!=0) {
      return err_n;
    }
    var->type = *t;
    if (def==1) {
      if(last_stat_ret!=NULL){
        *last_stat_ret = name;
      }
    }
    inst_fill(l,OP_MOVE,"LF@",name,"LF@",expr_ret,NULL,NULL);
    return SUCC; //pridat do tabulky symbolo a inicializovat na hodnotu podla value (pravdepodobne cez parameter odkazom)
  }else if (tok->type == KEY_WORD) {//if, while , value
    if (!strcmp(tok->value->str,"def")) { //definicia funkcie
      if(def){
        fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected def\n",line);
        return(SYNTH_ERROR);
      }
      GET_TOKEN;
      if (tok->type != IDENTIFICATOR) {
        SERROR("identificator");
      }
      char *name=mm_malloc(sizeof(char) * (tok->value->length+1));
      strcpy(name,tok->value->str);
      if (global_isDefined(gtab,name)==1) {
        //error redefinicia funkcie
        SEMERROR("Redefinition of function",UNDEF_ERROR);
      }
      if (local_isDeclared(ltab,name)) {
        SEMERROR("Redefinition of variable",UNDEF_ERROR);
        //error premenna s rovnakym menom v hlavnom programe
      }
      bool dek = false;//funkcia bola deklarovana pred definiciou
      if (global_isDeclared(gtab,name)==1) {  //ak bola dekalrovana len zmenit na defined
        struct global_symbol* tmp = global_Search(gtab,name);
        tmp->isDefined=true;
        dek = true;
      }else{
        global_InsertDefined(gtab,name);
        //ulozit identificator do tabulky funkcii
      }
      inst_fill(func_il,OP_LABEL,"",name,NULL,NULL,NULL,NULL);
      localTable *fun_ltab;
      fun_ltab = mm_malloc(sizeof(localTable));
      local_Init(fun_ltab);
      inst_fill(func_il,OP_CREATEFRAME,NULL,NULL,NULL,NULL,NULL,NULL);
      inst_fill(func_il,OP_PUSHFRAME,NULL,NULL,NULL,NULL,NULL,NULL);
      char ch_line[12] = {0};
      sprintf(ch_line, "%d", line);
      inst_fill(while_def_il,OP_JUMP,"$j_o_d_dv",ch_line,NULL,NULL,NULL,NULL);
      inst_fill(while_def_il,OP_LABEL,"$def_defvar",ch_line,NULL,NULL,NULL,NULL);
      inst_fill(func_il,OP_JUMP,"$def_defvar",ch_line,NULL,NULL,NULL,NULL);
      inst_fill(func_il,OP_LABEL,"$b2def",ch_line,NULL,NULL,NULL,NULL);
      GET_TOKEN;
      if (tok->type != LBRACKET) {
        SERROR("left bracket");
      }
      GET_TOKEN;
      if (tok->type != RBRACKET) {//preskakuje parametre ak je dalsi token ")"
        struct parameter *p = mm_malloc(sizeof(struct parameter));
        if(!dek){
          if(!global_addParam(gtab,p)){
            return INTERN_ERROR;
          }
        }
        err_n = param(p,1,func_il,fun_ltab);
        if (err_n != 0) {
          return err_n;
        }
        p->next = mm_malloc(sizeof(struct parameter));
        int *par_cnt = mm_malloc(sizeof(int));
        *par_cnt = 0;
        err_n = param_list(p->next,1,func_il,par_cnt,fun_ltab);
        if (dek){//skontrolovat parametre v deklaracii s parametrami v definicii
          if (check_sem_dek(gtab, name, p))
           return SYNTH_ERROR;
        }
        if (err_n != 0) {
          return err_n;
        }
        if (tok->type != RBRACKET) {
          SERROR("right bracket");
        }
      }
      GET_TOKEN;
      if (tok->type != EOL) {
        SERROR("EOL");
      }
      err_n = del_e_line();
      if (err_n != 0) {
        return err_n;
      }
      char *last_st = mm_malloc(sizeof(char));
      err_n = stat_list(1,fun_ltab,1,func_il,&last_st);
      if (err_n > 0 ) {
        return err_n;
      }
      if (err_n != RETEND) {
        SERROR("end");
      }
      GET_TOKEN;
      if(!strcmp(last_st,"nil@nil")){
        inst_fill(func_il,OP_PUSHS,"",last_st,NULL,NULL,NULL,NULL);
      }else{
        inst_fill(func_il,OP_PUSHS,"LF@",last_st,NULL,NULL,NULL,NULL);
      }
      inst_fill(while_def_il,OP_JUMP,"$b2def",ch_line,NULL,NULL,NULL,NULL);
      inst_fill(func_il,OP_POPFRAME,NULL,NULL,NULL,NULL,NULL,NULL);
      inst_fill(func_il,OP_RETURN,NULL,NULL,NULL,NULL,NULL,NULL);
      inst_fill(while_def_il,OP_LABEL,"$j_o_d_dv",ch_line,NULL,NULL,NULL,NULL);
      return SUCC;
    } else if (!strcmp(tok->value->str,"if")) { //if
      char ch_line[12] = {0};
      sprintf(ch_line, "%d", line);
      char lab_f [12] = {0};
      strcpy(lab_f,ch_line);
      strcat(lab_f,"$iff");
      GET_TOKEN;
      token=tok;
      expr_ret_type *ret = mm_malloc(sizeof(expr_ret_type));
      ret = expr(0,l,ltab,NULL);
      if (ret->err_id!=SUCC) {
        return ret->err_id;
      }
      tok=token;
      inst_fill(l,OP_JUMPIFNEQ,"$iff",ch_line,"LF@",ret->var_name,"bool@","true");
      if (tok->type == KEY_WORD) {
        if (strcmp(tok->value->str,"then")) {
          SERROR("then");
        }
      }else{
        SERROR("then");
      }
      GET_TOKEN;
      if (tok->type != EOL) {
        SERROR("EOL");
      }
      err_n = del_e_line();
      if (err_n != 0) {
        return err_n;
      }
      err_n = stat_list(2,ltab,2,l,NULL);
      if (err_n > 0 ) {
        return err_n;
      }
      inst_fill(l,OP_JUMP,"$ife",ch_line,NULL,NULL,NULL,NULL);
      if (err_n != RETELSE) {
        SERROR("else");
      }
      GET_TOKEN;
      if (tok->type != EOL) {
        SERROR("EOL");
      }
      inst_fill(l,OP_LABEL,"$iff",ch_line,NULL,NULL,NULL,NULL);
      err_n = del_e_line();
      if (err_n != 0) {
        return err_n;
      }
      err_n = stat_list(1,ltab,2,l,NULL);
      if (err_n > 0 ) {
        return err_n;
      }
      if (err_n != RETEND) {
        SERROR("end");
      }
      GET_TOKEN;
      if (def==1) {
        if(last_stat_ret!=NULL){
          *last_stat_ret = "nil@nil";
        }
      }
      inst_fill(l,OP_LABEL,"$ife",ch_line,NULL,NULL,NULL,NULL);
      return SUCC;
    } else if (!strcmp(tok->value->str,"while")) { //while
      char ch_line[12] = {0};
      sprintf(ch_line, "%d", line);
      inst_fill(l,OP_LABEL,"$whi",ch_line,NULL,NULL,NULL,NULL);
      GET_TOKEN;
      token=tok;
      expr_ret_type *ret = expr(0,l,ltab,NULL);
      if (ret->err_id!=SUCC) {
        return ret->err_id;
      }
      tok=token;
      inst_fill(l,OP_JUMPIFNEQ,"$whe",ch_line,"LF@",ret->var_name,"bool@","true");
      if (tok->type == KEY_WORD) {
        if (strcmp(tok->value->str,"do")) {
          SERROR("do");
        }
      }else{
        SERROR("do");
      }
      GET_TOKEN;
      if (tok->type != EOL) {
        SERROR("EOL");
      }
      //JUMP podla podmienky false = jump na whe (end)
      err_n = del_e_line();
      if (err_n != 0) {
        return err_n;
      }
      err_n = stat_list(1,ltab,2,l,last_stat_ret);
      if (err_n > 0 ) {
        return err_n;
      }
      if (err_n != RETEND) {
        SERROR("end");
      }
      GET_TOKEN;
      inst_fill(l,OP_JUMP,"$whi",ch_line,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_LABEL,"$whe",ch_line,NULL,NULL,NULL,NULL);
      if (def==1) {
        if(last_stat_ret!=NULL){
          *last_stat_ret = "nil@nil";
        }
      }
      return SUCC;
    }
  }
  var_types *t = mm_malloc(sizeof(int));
  char **expr_ret = mm_malloc(sizeof(char*));
  err_n = value(t,def,l,ltab,expr_ret);
  if (err_n != 0) {
    return err_n;
  }
  if (def==1) {
    if(last_stat_ret!=NULL){
      last_stat_ret = expr_ret;
    }
  }
  return 0;
}
int check_sem(char *val, struct parameter *p,List *l,localTable *ltab){
  if (!strcmp(val, "input")){
    if (p->type == T_NDEF)
      return 0;
    fprintf(stderr, "Funkce typu input nesmi mit zadne argumenty!\n");
    return PARAM_ERROR;
  }
  else if (!strcmp(val, "print")){
    if (p->type != T_NDEF)
      return 0;
    fprintf(stderr, "Funkce print musi mit aspon 1 parametr!\n");
    return PARAM_ERROR;
  }
  else if (!strcmp(val, "length")){
    if (p->next  != NULL)
    if (p->next->type == T_NDEF){
      if(local_isDeclared(ltab,p->name)){
        type_asm_ch(l,p->name,T_STRING);
        return 0;
      }else if(p->type == T_STRING){
        return 0;
      }
    }
    fprintf(stderr, "Spatny datovy typ argumentu ve funkci length!\n");
    return PARAM_ERROR;
  }
  else if (!strcmp(val, "substr")){
    var_types tmp[] = { T_STRING, T_INT, T_INT, T_NDEF };
    for (int i = 0; i < 4; i++){
      if (i == 3) { //kontrola poctu parametrov
        if (tmp[i] != p->type) {
          fprintf(stderr, "Spatny pocet argumentu ve funkci substr!\n");
          return PARAM_ERROR;
        }
        return 0;
      }
      if(!local_isDeclared(ltab,p->name)){//konstanta
        if (tmp[i] != p->type){
          if (i == 1 || i == 2){
            if (p->type == T_FLOAT){//konverzia na INT
              char *u_id = gen_u();
              inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
              inst_fill(l,OP_FLOAT2INT, "LF@", u_id, "float@", p->name,NULL,NULL);
              p->name = u_id;
              p->type = T_ELSE;
              p = p->next;
              continue;
            }
          }
          fprintf(stderr, "Spatny datovy typ argumentu ve funkci substr!\n");
          return SEM_ERROR;
        }
      }else{//premenna -> dynamicka kontrola typov
        char *ret = type_asm_ch(l,p->name,tmp[i]);
        if (ret != NULL) {
          p->name = ret;
        }
      }
      p = p->next;
    }
    return 0;
  }
  else if (!strcmp(val, "ord")){
    var_types tmp[] = { T_STRING, T_INT, T_NDEF };
    for (int i = 0; i < 3; i++){
      if (i == 2) { //kontrola poctu parametrov
        if (tmp[i] != p->type) {
          fprintf(stderr, "Spatny pocet argumentu ve funkci ord!\n");
          return PARAM_ERROR;
        }
        return 0;
      }
      if(!local_isDeclared(ltab,p->name)){//konstanta
        if (tmp[i] != p->type){
          if (i == 1){
            if (p->type == T_FLOAT){//konverzia na INT
              char *u_id = gen_u();
              inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
              inst_fill(l,OP_FLOAT2INT, "LF@", u_id, "float@", p->name,NULL,NULL);
              p->name = u_id;
              p->type = T_ELSE;
              p = p->next;
              continue;
            }
          }
          fprintf(stderr, "Spatny datovy typ argumentu ve funkci ord!\n");
          return SEM_ERROR;
        }
      }else{//premenna -> dynamicka kontrola typov
        char *ret = type_asm_ch(l,p->name,tmp[i]);
        if (ret != NULL) {
          p->name = ret;
        }
      }
      p = p->next;
    }
    return 0;
  }
  else if (!strcmp(val, "chr")){
    if(!local_isDeclared(ltab,p->name)){//konstanta
      if (T_INT != p->type){
        if (p->type == T_FLOAT){//konverzia na INT
          char *u_id = gen_u();
          inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_FLOAT2INT, "LF@", u_id, "float@", p->name,NULL,NULL);
          p->name = u_id;
          p->type = T_ELSE;
          p = p->next;
        }else{
          fprintf(stderr, "Spatny datovy typ argumentu ve funkci chr!\n");
          return SEM_ERROR;
        }
      }
    }else{//premenna -> dynamicka kontrola typov
      char *ret = type_asm_ch(l,p->name,T_INT);
      if (ret != NULL) {
        p->name = ret;
      }
    }
     //kontrola poctu parametrov
    if (T_NDEF != p->next->type) {
      fprintf(stderr, "Spatny pocet argumentu ve funkci chr!\n");
      return PARAM_ERROR;
    }
    return 0;
  }
  return 0;
}

int value (var_types *t,int def,List* l,localTable *ltab,char **expr_ret){
  int err_n = 0;
  if (tok->type == KEY_WORD) {
    struct parameter *p = mm_malloc(sizeof(struct parameter));
    p->type = T_NDEF;
    /*************************INPUT******************************/
    if (!strcmp(tok->value->str,"inputs")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, "input");
      GET_TOKEN;
      *t = T_STRING;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      err_n = func(p,l,par_cnt,ltab);
      if (err_n){
        return err_n;
      }
      err_n = check_sem(val, p,l,ltab);
      if (err_n)
        return err_n;
      else{
        char *u_id = gen_u();
        inst_fill(l,OP_CALL,"input","s",NULL,NULL,NULL,NULL);
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_POPS,"LF@",u_id,NULL,NULL,NULL,NULL);
        *expr_ret=u_id;
        return SUCC;
      }
    }else if (!strcmp(tok->value->str,"inputi")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, "input");
      GET_TOKEN;
      *t = T_INT;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      err_n = func(p,l,par_cnt,ltab);
      if (err_n){
        return err_n;
      }
      err_n = check_sem(val, p,l,ltab);
      if (err_n)
        return err_n;
      else{
          inst_fill(l,OP_CALL,"input","i",NULL,NULL,NULL,NULL);
          char *u_id = gen_u();
          inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
          inst_fill(l,OP_POPS,"LF@",u_id,NULL,NULL,NULL,NULL);
          *expr_ret=u_id;
          return SUCC;
      }
    }else if (!strcmp(tok->value->str,"inputf")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, "input");
      GET_TOKEN;
      *t = T_FLOAT;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      err_n = func(p,l,par_cnt,ltab);
      if (err_n){
        return err_n;
      }
      err_n = check_sem(val, p,l,ltab);
      if (err_n)
        return err_n;
      else{
        inst_fill(l,OP_CALL,"input","f",NULL,NULL,NULL,NULL);
        char *u_id = gen_u();
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_POPS,"LF@",u_id,NULL,NULL,NULL,NULL);
        *expr_ret=u_id;
        return SUCC;
      }
    /*********************************PRINT*************************/
    }else if (!strcmp(tok->value->str,"print")) {
      char *val = mm_malloc(sizeof(tok->value->length)+2*sizeof(char));
      strcpy(val, tok->value->str);
      GET_TOKEN;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      err_n = func(p,l,par_cnt,ltab);
      if (err_n){
        return err_n;
      }
      err_n = check_sem(val, p,l,ltab);
      if (err_n)
        return err_n;
      else{
        struct parameter *o_p = p; //original parameter list
        while (o_p->type!=T_NDEF) {//otoci poradie parametrov
          p = o_p;
          while (p->next->type!=T_NDEF) {
            p=p->next;
          }
          if (p->type == T_ELSE) {
            inst_fill(l,OP_PUSHS,"LF@",p->name,NULL,NULL,NULL,NULL);
          }else if (p->type == T_INT) {
            inst_fill(l,OP_PUSHS,"int@",p->name,NULL,NULL,NULL,NULL);
          }else if (p->type == T_FLOAT) {
            inst_fill(l,OP_PUSHS,"float@",p->name,NULL,NULL,NULL,NULL);
          }else if (p->type == T_STRING) {
            inst_fill(l,OP_PUSHS,"string@",p->name,NULL,NULL,NULL,NULL);
          }else if (p->type == T_NIL){
            inst_fill(l,OP_PUSHS,"nil@","nil",NULL,NULL,NULL,NULL);
          }
          p->type = T_NDEF;
        }
        char ch_p_c[5] = {0};
        sprintf(ch_p_c, "%d", *par_cnt);
        inst_fill(l,OP_PUSHS,"int@",ch_p_c,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_CALL,"prin","t",NULL,NULL,NULL,NULL);
        char *u_id = gen_u();
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_MOVE,"LF@",u_id,"nil@","nil",NULL,NULL);
        *expr_ret=u_id;
        return SUCC;
      }
    /******************************LENGTH****************************/
    }else if (!strcmp(tok->value->str,"length")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, tok->value->str);
      GET_TOKEN;
      *t = T_INT;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      err_n = func(p,l,par_cnt,ltab);
      if (err_n){
        return err_n;
      }
      err_n = check_sem(val, p,l,ltab);
      if (err_n)
        return err_n;
      else{
        push_par (p,l);
        inst_fill(l,OP_CALL,"lengt","h",NULL,NULL,NULL,NULL);
        char *u_id = gen_u();
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_POPS,"LF@",u_id,NULL,NULL,NULL,NULL);
        *expr_ret=u_id;
        return SUCC;
      }
    /******************************ORD******************************/
    }else if (!strcmp(tok->value->str,"ord")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, tok->value->str);
      GET_TOKEN;
      *t = T_INT;//v pripade chyby T_NIL
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      err_n = func(p,l,par_cnt,ltab);
      if (err_n){
        return err_n;
      }
      err_n = check_sem(val, p,l,ltab);
      if (err_n)
        return err_n;
      else{
        push_par (p,l);
        inst_fill(l,OP_CALL,"or","d",NULL,NULL,NULL,NULL);
        char *u_id = gen_u();
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_POPS,"LF@",u_id,NULL,NULL,NULL,NULL);
        *expr_ret=u_id;
        return SUCC;
      }
    /******************************CHR******************************/
    }else if (!strcmp(tok->value->str,"chr")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, tok->value->str);
      GET_TOKEN;
      *t = T_STRING;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      err_n = func(p,l,par_cnt,ltab);
      if (err_n){
        return err_n;
      }
      err_n = check_sem(val, p,l,ltab);
      if (err_n)
        return err_n;
      else{
        push_par (p,l);
        inst_fill(l,OP_CALL,"ch","r",NULL,NULL,NULL,NULL);
        char *u_id = gen_u();
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_POPS,"LF@",u_id,NULL,NULL,NULL,NULL);
        *expr_ret=u_id;
        return SUCC;
      }
      /*************************SUBSTR******************************/
    }else if (!strcmp(tok->value->str,"substr")) {
      char *val = mm_malloc(sizeof(tok->value->length)+sizeof(char));
      strcpy(val, tok->value->str);
      GET_TOKEN;
      *t = T_STRING;
      int *par_cnt = mm_malloc(sizeof(int));
      *par_cnt = 0;
      err_n = func(p,l,par_cnt,ltab);
      if (err_n){
        return err_n;
      }
      err_n = check_sem(val, p,l,ltab);
      if (err_n)
        return err_n;
      else{
        push_par (p,l);
        inst_fill(l,OP_CALL,"sub","str",NULL,NULL,NULL,NULL);
        char *u_id = gen_u();
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_POPS,"LF@",u_id,NULL,NULL,NULL,NULL);
        *expr_ret=u_id;
        return SUCC;
      }
    }else if (!strcmp(tok->value->str,"nil")) {
      char *u_id = gen_u();
      inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_MOVE,"LF@",u_id,"nil@","nil",NULL,NULL);
      *expr_ret = u_id;
      *t = T_NIL;
      GET_TOKEN;
    }else {
      SERROR("function name");
    }
  /********************ID******************************/
  }else if (tok->type == IDENTIFICATOR) { //volanie funkcie pripadne vyraz!!!!
      char *name=mm_malloc(sizeof(char) * (strlen(tok->value->str)+1));
      strcpy(name,tok->value->str);
      if(local_isDeclared(ltab,name)){
        token=tok;
        expr_ret_type *ret = expr(0,l,ltab,NULL);
        if (ret->err_id!=SUCC) {
          return ret->err_id;
        }
        tok=token;
        *t =  ret->t;
        *expr_ret = ret->var_name;
        return SUCC;
      }
      GET_TOKEN;
      unsigned int p_fun[]={LBRACKET,IDENTIFICATOR,INTEGER,STRING,DOUBLE,EOL};//EOL->funkcia bez zatvoriek a parametrov
      int n_fun = 0;//1->dalsia je funkcia 0->dalsi je vyraz
      for (int i = 0; i < 6; i++) {
        if (tok->type==p_fun[i]) {
          n_fun = 1;
          break;
        }
      }
      int dek = false;//funkcia nebola definovana ideme ju deklarovat(plati iba v definicii inej funkcie)
      if (n_fun) {//skontrolovat ci sa funkcia nachadza v tabulke symbolov, ak nie nastavit na declarated (pripadne error v hlavnom tele)
        if (global_isDefined(gtab,name)<=0) {
          //v definicii funkcie bez error inak semanticka chyba
          if((def==1)&&(global_isDeclared(gtab,name)<=0)){
            global_InsertDeclared(gtab,name);
            dek = true;
          }else if(!def){
            SEMERROR("Not defined function",UNDEF_ERROR);
          }
        }
        struct parameter *p = mm_malloc(sizeof(struct parameter));
        p->type = T_NDEF;
        if (dek) {
          if(!global_addParam(gtab,p)){
            return INTERN_ERROR;
          }
        }
        int *par_cnt = mm_malloc(sizeof(int));
        *par_cnt = 0;
        int err_n = func(p,l,par_cnt,ltab);
        if (err_n != 0) {
          return err_n;
        }
        push_par (p,l);
        inst_fill(l,OP_CALL,name,"",NULL,NULL,NULL,NULL);
        char *u_id = gen_u();
        inst_fill(while_def_il,OP_DEFVAR, "LF@", u_id,NULL,NULL,NULL,NULL);
        inst_fill(l,OP_POPS,"LF@",u_id,NULL,NULL,NULL,NULL);
        *expr_ret=u_id;
        return SUCC;
      }else{//vyraz , nedefinovana premenna?
        token=tok;
        expr_ret_type *ret = expr(0,l,ltab,NULL);
        if (ret->err_id!=SUCC) {
          return ret->err_id;
        }
        tok=token;
        *t =  ret->t;
        *expr_ret = ret->var_name;
      }
  }else{ //vyhodnot vyraz
    token=tok;
    expr_ret_type *ret = expr(0,l,ltab,NULL);
    if (ret->err_id!=SUCC) {
      return ret->err_id;
    }
    *t =  ret->t;
    tok=token;
    *expr_ret = ret->var_name;
  }
  return SUCC;
}

int func(struct parameter *p,List *l, int *par_cnt,localTable *ltab){
  int lb = 0;//LEFT bracket -> 1 ak parametre zacinaju zatvorkou
  int err_n = 0;//ERROR NUMBER
  if (tok->type == EOL) {
    return SUCC; //funkcia bez parametrov a zatvoriek
  }
  if (tok->type == LBRACKET) {
    lb = 1;
    GET_TOKEN;
  }
  if (tok->type == RBRACKET) {
    if (lb==0) {
      fprintf(stderr,"SYNTAX ERROR on line %d : Unexpected )\n",line);
      return(SYNTH_ERROR);
    }
    GET_TOKEN;
    return SUCC; //funkcia bez parametrov
  }
  err_n = param(p,0,l,ltab);
  if (err_n != 0) {
    return err_n;
  }
  (*par_cnt)++;
  p->next = mm_malloc(sizeof(struct parameter));
  p->next->type = T_NDEF;
  err_n = param_list(p->next,0,l,par_cnt,ltab);
  if (err_n != 0) {
    return err_n;
  }
  if (lb) {
    if (tok->type != RBRACKET) {
      SERROR("right bracket");
    }else{
      GET_TOKEN;
    }
  }
  return SUCC;
}

int param_list(struct parameter *p,int def,List *l, int *par_cnt,localTable *ltab){
  int err_n = 0;//ERROR NUMBER
  if (tok->type == COMMA) {
    GET_TOKEN;
    err_n = param(p,def,l,ltab);
    if (err_n != 0) {
      return err_n;
    }
    (*par_cnt)++;
    p->next = mm_malloc(sizeof(struct parameter));
    p->next->type = T_NDEF;
    err_n = param_list(p->next,def,l,par_cnt,ltab);
    if (err_n != 0) {
      return err_n;
    }
  }
  return SUCC;
}

int param(struct parameter *p,int def,List *l,localTable *ltab){
  if (def==1){
    if (tok->type == IDENTIFICATOR) {
      p->name = mm_malloc(sizeof(char)*(tok->value->length+1));
      strcpy(p->name,tok->value->str);
      /*if (local_isDeclared(ltab,p->name)) {
        return SUCC;//je to chyba?
      }*/
      struct local_symbol *var = mm_malloc(sizeof(struct local_symbol));
      var->type = T_NIL;
      var->name = mm_malloc((strlen(p->name)+1)*sizeof(char));
      strcpy(var->name,p->name);
      local_InsertDeclared(ltab,var);
      inst_fill(l,OP_DEFVAR, "LF@",p->name,NULL,NULL,NULL,NULL);
      inst_fill(l,OP_POPS,"LF@",p->name,NULL,NULL,NULL,NULL);
      GET_TOKEN;
      return SUCC;
    }else{
      SERROR(tok->value->str);
    }
  }
  if (tok->type == IDENTIFICATOR) {//parameter je premenna
    p->name = mm_malloc(sizeof(char)*(tok->value->length+1));
    strcpy(p->name,tok->value->str);
    p->type = T_ELSE;
  }else if (tok->type == INTEGER) {//ulozit hodnotu a typ parametra do tabulky symbolov
    p->name = mm_malloc(sizeof(char)*(tok->value->length+1));
    strcpy(p->name,tok->value->str);
    p->type = T_INT;
  }else if (tok->type == DOUBLE) {
    p->name = mm_malloc(sizeof(char)*(tok->value->length+1));
    strcpy(p->name,tok->value->str);
    p->type = T_FLOAT;
  }else if (tok->type == STRING) {
    p->name = mm_malloc(sizeof(char)*(tok->value->length+1));
    strcpy(p->name,tok->value->str);
    p->type = T_STRING;
  }else if (!strcmp(tok->value->str,"nil")){
    p->name = NULL;
    p->type = T_NIL;
  }else{
    SERROR("identificator or constant");
  }
  GET_TOKEN;
  return SUCC;
}
void push_par (struct parameter *p,List *l){
  while (p->type != T_NDEF) {
    if (p->type == T_ELSE) {
      inst_fill(l,OP_PUSHS,"LF@",p->name,NULL,NULL,NULL,NULL);
    }else if (p->type == T_INT) {
      inst_fill(l,OP_PUSHS,"int@",p->name,NULL,NULL,NULL,NULL);
    }else if (p->type == T_FLOAT) {
      inst_fill(l,OP_PUSHS,"float@",p->name,NULL,NULL,NULL,NULL);
    }else if (p->type == T_STRING) {
      inst_fill(l,OP_PUSHS,"string@",p->name,NULL,NULL,NULL,NULL);
    }else if (p->type == T_NIL){
      inst_fill(l,OP_PUSHS,"nil@","nil",NULL,NULL,NULL,NULL);
    }
    p = p->next;
  }
}

int main() {
  file = stdin;
  ungetc('\n', file);
  int err_n = 0;//ERROR NUMBER
  create_token(&tok);
  init_memory();
  init_il();
  gtab = mm_malloc(sizeof(globalTable));
  global_Init(gtab);
  GET_TOKEN;
  err_n = prog();
  if (err_n==SUCC) {//prejde celu tabulku premennych a skontruje ci vsetky deklarovane fun boli aj definovane
    for (int i = 0; i < 12289; i++) {
      if (gtab->tHTable[i] != NULL){
        if ((gtab->tHTable[i]->isDeclared == true)&&(gtab->tHTable[i]->isDefined == false)) {
          err_n = UNDEF_ERROR;
          fprintf(stderr, "Funkcia '%s' bola deklarovana ale nebola definovana\n", gtab->tHTable[i]->name);
          break;
        }
      }
    }
  }
  if (err_n==SUCC) {
    gen_code();
    printf("\n\n# INBUILD FUNCTIONS\n");
    create_inbuildFce();
    printf("\n# ERROR EXITS\n");
    printf("LABEL $error4_exit\n");
    printf("EXIT int@4\n");
    printf("LABEL $error9_exit\n");
    printf("EXIT int@9\n");
    printf("LABEL $PROGRAM_END\n");
  }
  delete_token(tok);
  free_memory();
  fclose(file);
return err_n;
}
