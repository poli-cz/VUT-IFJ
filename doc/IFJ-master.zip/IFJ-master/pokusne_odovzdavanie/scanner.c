/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief File scanner
 *
 * @author Jakub Sadílek xsadil07
 */

#include "scanner.h"
#include "dynamic_string.h"

/**
 * Seznam klíčových slov.
*/
const char *KEY_WORDS[] = { "def", "do", "else", "end", "if", "not", "nil", "then", "while",
 "inputs", "inputi", "inputf", "print", "length", "substr", "ord", "chr" };

static scan_states state;   // Stavy automatu podle načteného znaku.
static int symbol;          // Promněná pro načtený znak.
FILE *file = NULL;          // Ukazatel na vstupní soubor.

/**
 * Funkce zkontroluje jestli načtený identifikátor není klíčové slovo.
*/
static void check_token_type (stToken *token){
    for (int i = 0; i < KEYWORD_NUM; i++){
		if (!strcmp(token->value->str, KEY_WORDS[i])) {
			token->type = KEY_WORD;
			return;
		}
    }
}

/**
 * Funkce načte identifikátor ze souboru. Identifikátor začíná malým písmenkem nebo '_'.
 * Pokud načte jiný znak než alfanumerický nebo '_', vratí identifikátor.
 * Pokud načte znak ? nebo ! vrací identifikátor včetně znaku.
*/
static int do_id (stToken *token){
    add_char(symbol, token->value);

    while (true){
        symbol = getc(file);
        if (isalnum(symbol) || symbol == '_' || symbol == '?' || symbol == '!'){
            if (add_char(symbol, token->value))
                return 1;
            if (symbol == '?' || symbol == '!'){
                token->type = IDENTIFICATOR;
                symbol = getc(file);
                if (symbol == '_' || symbol == '?' || symbol == '!' || isalnum(symbol)){
                    ungetc(symbol, file);
                    fprintf(stderr, "Neplatny nazev identificatoru.\n");
                    return 1;
                }
                ungetc(symbol, file);
                return 0;
            }
        }
        else {
            ungetc(symbol, file);
            token->type = IDENTIFICATOR;
            check_token_type(token);
            return 0;
        }
    }
}

/**
 * Funkce překonvertuje hodnotu double na floating point hexa.
 * Vrací 0 při úspěchu, jinak 1.
*/
static int conv2fp(stToken *token){
    double tmp = strtod(token->value->str, NULL);
    token->value->str = (char *)realloc(token->value->str, 30 * (sizeof(char)));
    if (token->value->str == NULL){
        fprintf(stderr, "Realokace tokenu se nezdarila.\n");
        return 1;
    }
    sprintf(token->value->str, "%a", tmp);
    token->value->allocated = 30;
    token->value->length = strlen(token->value->str);
    return 0;
}

/**
 * Funkce načítá exponenciální část čísla typu DOUBLE začínající znakem 'e' nebo 'E'.
 * Následuje libovolné znaménko '+' nebo '-'. Počáteční číslice '0' jsou ignorovány.
 * Vrací hodnotu 0 v případě úspěchu, jinak 1 pokud je exponeciální část prázdná.
*/
static int do_exp (stToken *token){
    if (add_char(symbol, token->value))
        return 1;
    symbol = getc(file);
    if (symbol == '+' || symbol == '-'){
        if (add_char(symbol, token->value))
            return 1;
        symbol = getc(file);
    }
    if (!isdigit(symbol)){
        ungetc(symbol, file);
        fprintf(stderr, "Exponenciální část desetinného čísla nesmí být prázdná!\n");
        return 1;
    }
    while (symbol == '0')
        symbol = getc(file);
    if (!isdigit(symbol)){
        if (add_char('0', token->value))
            return 1;
        ungetc(symbol, file);
        token->type = DOUBLE;
        return 0;
    }
    if (add_char(symbol, token->value))
        return 1;

    while (isdigit(symbol = getc(file))){
        if (add_char(symbol, token->value))
            return 1;
    }
    ungetc(symbol, file);
    token->type = DOUBLE;
    if (conv2fp(token))
        return 1;
    return 0;
}

/**
 * Funkce čte desetinnou část čísla typu DOUBLE začínající znakem '.'.
 * Pokud uspěje vrací 0, v případě, že je desetinná část prázdná vrací
 * chybu resp. 1. Následovat může exponenciální část.
*/
static int do_double (stToken *token){
    if (add_char(symbol, token->value))
        return 1;
    if (!isdigit(symbol = getc(file))){
        fprintf(stderr, "Desetinná část nesmí být prázdná!\n");
        return 1;
    }
    if (add_char(symbol, token->value))
        return 1;

    while (isdigit(symbol = getc(file))){
        if (add_char(symbol, token->value))
            return 1;
    }

    if (symbol == 'e' || symbol == 'E')
        return (do_exp(token)) ? 1 : 0;
    else {
        ungetc(symbol, file);
        token->type = DOUBLE;
    }
    if (conv2fp(token))
        return 1;
    return 0;
}

/**
 * Čte číslice ze souboru dokud nenarazí na jiný znak. Následovat může desetinná
 * nebo exponenciální část. Vrací 0 pokud uspěje, jinak 1 pokud nastane chyba např.
 * celá část nemůže začínat čislicí '0' nebo je porušeno pravidlo pro jinou část čísla.
 * Pokud nenásleduje des. ani exp. část jedná se o typ INTEGER, jinak DOUBLE.
*/
static int do_number (stToken *token){
    if (symbol == '0'){
        int tmp = symbol;
        if (isdigit(symbol = getc(file))){
            fprintf(stderr, "Počáteční číslice nemůže být 0!\n");
            return 1;
        }
        ungetc(symbol, file);
        symbol = tmp;
    }
    add_char(symbol, token->value);

    while (isdigit(symbol = getc(file))){
        if (add_char(symbol, token->value))
            return 1;
    }

    if (symbol == '.')
        return (do_double(token)) ? 1 : 0;
    else if (symbol == 'e' || symbol == 'E')
        return (do_exp(token)) ? 1 : 0;
    else {
        ungetc(symbol, file);
        token->type = INTEGER;
    }
    return 0;
}

/**
 * Funkce převede zadanou sekvenci znaku hexadecimálního čísla
 * "\xFF" na znak tomu odpovídající. Vrací 0 v případě úspěchu,
 * jinak 1 v případě chyby (např. neznámá sekvence hex. čísla).
*/
static int do_hex (dynamic_str *string){
    char x1, x2, hexStr[10];
    if (isxdigit(x1 = getc(file))){
        if (!isxdigit(x2 = getc(file))){
            ungetc(x2, file);
            sprintf(hexStr, "%c", x1);
        }
        else
            sprintf(hexStr, "%c%c", x1, x2);
    }
    else {
        fprintf(stderr, "Neznámá sekvence znaků \\x%c, očekávám hexadecimální číslo!\n", x1);
        return 1;
    }
    symbol = (int)strtol(hexStr, NULL, 16);
    switch (symbol){
        case '\"':
            if (add_char('\\', string))
                return 1;
            if (add_char('0', string))
                return 1;
            if (add_char('3', string))
                return 1;
            if (add_char('4', string))
                return 1;
            return 0;
        case '\n':
            if (add_char('\\', string))
                return 1;
            if (add_char('0', string))
                return 1;
            if (add_char('1', string))
                return 1;
            if (add_char('0', string))
                return 1;
            return 0;
        case '\t':
            if (add_char('\\', string))
                return 1;
            if (add_char('0', string))
                return 1;
            if (add_char('0', string))
                return 1;
            if (add_char('9', string))
                return 1;
            return 0;
        case ' ':
            if (add_char('\\', string))
                return 1;
            if (add_char('0', string))
                return 1;
            if (add_char('3', string))
                return 1;
            if (add_char('2', string))
                return 1;
            return 0;
        case '\\':
            if (add_char('\\', string))
                return 1;
            if (add_char('0', string))
                return 1;
            if (add_char('9', string))
                return 1;
            if (add_char('2', string))
                return 1;
            return 0;
        default:
            if (add_char(symbol, string))
                return 1;
            return 0;
    }
}

/**
 * Funkce čte řetězec ze souboru začínající '"' dokud nenarazí opět na '"'.
 * Řetězec může bý pouze na jednom řádku a podporuje speciální znaky.
 * Vrací 0 při úspěchu, jinak 1.
*/
static int do_literal (stToken *token){
    while ((symbol = getc(file)) != '\"'){
        if (symbol == '\n'){
            fprintf(stderr, "Řeťezcový literál může být pouze na jediném řádku!\n");
            return 1;
        }
        else if (symbol == '\\'){
            switch (symbol = getc(file)){
                case '\"':
                    if (add_char('\\', token->value))
                        return 1;
                    if (add_char('0', token->value))
                        return 1;
                    if (add_char('3', token->value))
                        return 1;
                    if (add_char('4', token->value))
                        return 1;
                    break;
                case 'n':
                    if (add_char('\\', token->value))
                        return 1;
                    if (add_char('0', token->value))
                        return 1;    
                    if (add_char('1', token->value))
                        return 1;
                    if (add_char('0', token->value))
                        return 1;
                    break;
                case 't':
                    if (add_char('\\', token->value))
                        return 1;
                    if (add_char('0', token->value))
                        return 1;
                    if (add_char('0', token->value))
                        return 1;
                    if (add_char('9', token->value))
                        return 1;
                    break;
                case 's':   // Mezera \s není podporovaná?
                    if (add_char('\\', token->value))
                        return 1;
                    if (add_char('0', token->value))
                        return 1;
                    if (add_char('3', token->value))
                        return 1;
                    if (add_char('2', token->value))
                        return 1;
                    break;
                case '\\':
                    if (add_char('\\', token->value))
                        return 1;
                    if (add_char('0', token->value))
                        return 1;
                    if (add_char('9', token->value))
                        return 1;
                    if (add_char('2', token->value))
                        return 1;
                    break;
                case 'x':
                    if (do_hex(token->value))
                        return 1;
                    break;
                default:
                    if (add_char(symbol, token->value))
                        return 1;
                    continue;
            }
        }
        else if (symbol == ' '){
            if (add_char('\\', token->value))
                return 1;
            if (add_char('0', token->value))
                return 1;
            if (add_char('3', token->value))
                return 1;
            if (add_char('2', token->value))
                return 1;
        }
        else if (symbol == EOF){
            fprintf(stderr, "Neočekávaný konec souboru!\n");
            return 1;
        }
        else {
            if (add_char(symbol, token->value))
                return 1;
        }
    }
    token->type = STRING;
    return 0;
}

/**
 * Funkce přiřadí tokenu znaménko podle typu 't'.
*/
static int do_sign (stToken *token, token_type t){
    add_char(symbol, token->value);
    token->type = t;
    return 0;
}

/**
 * Funkce kontroluje jestli zadaná sekvence v blokovém komentáři
 * odpovídá sekvenci pro ukončení.
 * POZOR: Vrací 1 v případě úspěchu, jiank 0.
*/
static int end_com (){
    int end[4] = { '=', 'e', 'n', 'd' }, c[4], conf = 0;
    c[0] = getc(file);
    for (int i = 0; i < 4; i++){
        if (c[i] == end[i]){
            conf++;
            if (conf == 4){
                return 1;
            }
            c[i+1] = getc(file);
        }
        else {
            for (int j = 0; j <= conf; conf--)
                ungetc(c[conf], file);
            return 0;
        }
    }
    return 0;
}

/**
 * Funkce čte znaky v blokovém komentáři a hledá jeho konec.
 * Pokud blokový komentář skončí vrátí 0, jinak 1 pokud chybí ukončení.
*/
static int do_block_com (){
    while (true){
        symbol = getc(file);
        if (symbol == '\n'){
            if (end_com()){
                while (true){
                    symbol = getc(file);
                    if (symbol == '\n' || symbol == EOF)
                        break;
                }
                return 0;
            }
        }
        if (symbol == EOF){
            fprintf (stderr, "Chybí ukončení blokového komentáře!\n");
            return 1;
        }
    }
}

/**
 * Funkce zkontroluje jestli zadaná sekvence odpovídá sekvenci pro
 * začátek blokového komentáře.
 * POZOR: vrací 1 pokud uspěje, 2 pokud je nazacatku '=', ale "begin tam neni", jinak 0.
*/
static int begin_com (){
    int begin[6] = { '=', 'b', 'e', 'g', 'i', 'n' }, c[6], conf = 0;
    while (isspace(c[0] = getc(file)));
    for (int i = 0; i < 6; i++){
        if (c[i] == begin[i]){
            conf++;
            if (conf == 6){
                return 1;
            }
            c[i+1] = getc(file);
        }
        else {
            if (conf >= 1){
                fprintf(stderr, "Neocekavany znak na zacatku radku\n");
                return 2;
            }
            for (int j = 0; j <= conf; conf--)
                ungetc(c[conf], file);
            return 0;
        }
    }
    return 0;
}

/**
 * Funkce rozpozná načtený relační operátor a naplní token.
 * Vrací 0 pokud uspěje, jinak 1.
*/
static int do_relation (stToken *token){
    add_char(symbol, token->value);
    switch (symbol){
        case '=':
            if ((symbol = getc(file)) == '='){
                add_char(symbol, token->value);
                token->type = EQ;
                return 0;
            }
            else {
                ungetc(symbol, file);
                token->type = ASSIGNMENT;
                return 0;
            }
        case '!':
            if ((symbol = getc(file)) == '='){
                add_char(symbol, token->value);
                token->type = NEQ;
                return 0;
            }
            else {
                ungetc(symbol, file);
                fprintf(stderr, "Neočekávaný znak '!'\n");
                return 1;
            }
        case '<':
            if ((symbol = getc(file)) == '='){
                add_char(symbol, token->value);
                token->type = LE;
                return 0;
            }
            else {
                ungetc(symbol, file);
                token->type = LT;
                return 0;
            }
        case '>':
            if ((symbol = getc(file)) == '='){
                add_char(symbol, token->value);
                token->type = GE;
                return 0;
            }
            else {
                ungetc(symbol, file);
                token->type = GT;
                return 0;
            }
    }
    return 0;
}

/**
 * Identifikován znak pro řádkový komentář.
 * Funkce čte znaky dokud nenarazí na '\n' nebo EOF.
*/
static void do_line_com (){
    while((symbol = getc(file))){
        if (symbol == '\n' || symbol == EOF){
            ungetc(symbol, file);
            break;
        }
    }
    state = S_BEGIN;
}

/**
 * Funkce přiřadí tokenu speciální znak a typ podle hdonoty 't'.
*/
static int do_special (stToken *token, token_type t){
    token->type = t;
    add_char(symbol, token->value);
    return 0;
}

/**
 * Funkce zkontroluje jestli se jedná o EOL nebo o blokový komentář.
 * Vrací 0 při úspěchu, 1 při chybě.
*/
static int do_eol (stToken *token){
    add_char(symbol, token->value);
    int tmp = 0;
    if ((tmp = begin_com()) == 1){
        if (do_block_com())
            return 1;
    }
    else if (tmp == 2)
        return 1;
    token->type = EOL;
    return 0;
}

/**
 * Funkce alokuje a inicializuje token.
 * Při úspěchu vrací 0, jinak 1.
*/
int create_token (stToken **token){
    if ((*token = malloc(sizeof(struct sToken))) == NULL){
        fprintf(stderr, "Inicializace tokenu se nezdařila!\n");
        return 1;
    }
    (*token)->type = UNDEFINED;
    if (init_string(&(*token)->value)){
        free(*token);
        return 1;
    }
    return 0;
}

/**
 * Funkce uvolní alokovanou paměť tokenu.
*/
void delete_token (stToken *token){
	free(token->value->str);
    free(token->value);
    free(token);
}

/**
 * Funkce přiřadí tokenu hodnotu a typ podle načtených znaků ze souboru.
 * Vrací 0 v případě úspěchu, jinak 1 při chybě a -1 při EOF.
*/
int get_token (stToken *token){
    state = S_BEGIN;
    while (true){
        switch (state){
            case S_BEGIN:
                symbol = getc(file);
                if (symbol == EOF) { state = S_END; }
                else if (symbol == '\n') { state = S_EOL; }
                else if (islower(symbol) || symbol == '_') { state = S_ID; }
                else if (isdigit(symbol)) { state = S_NUMBER; }
                else if (isspace(symbol)) { state = S_BEGIN; }
                else if (symbol == '\"') { state = S_LITERAL; }
                else if (symbol == '+') { state = S_PLUS; }
                else if (symbol == '-') { state = S_MINUS; }
                else if (symbol == '*') { state = S_MUL; }
                else if (symbol == '/') { state = S_DIV; }
                else if (symbol == '=') { state = S_RELATION; }
                else if (symbol == '<') { state = S_RELATION; }
                else if (symbol == '>') { state = S_RELATION; }
                else if (symbol == '!') { state = S_RELATION; }
                else if (symbol == '#') { state = S_LCOM; }
                else if (symbol == '(') { state = S_LBRACKET; }
                else if (symbol == ')') { state = S_RBRACKET; }
                else if (symbol == ',') { state = S_COMMA; }
                else state = S_ERROR;
            break;
            case S_END:
                return (do_special(token, END)) ? 1 : 0;
            case S_EOL:
                return (do_eol(token)) ? 1 : 0;
            case S_ID:
                return (do_id(token)) ? 1 : 0;
            case S_NUMBER:
                return (do_number(token)) ? 1 : 0;
            case S_LITERAL:
                return (do_literal(token)) ? 1 : 0;
            case S_PLUS:
                return (do_sign(token, PLUS)) ? 1 : 0;
            case S_MINUS:
                return (do_sign(token, MINUS)) ? 1 : 0;
            case S_MUL:
                return (do_sign(token, MUL)) ? 1 : 0;
            case S_DIV:
                return (do_sign(token, DIV)) ? 1 : 0;
            case S_RELATION:
                return (do_relation(token)) ? 1 : 0;
            case S_LBRACKET:
                return do_special(token, LBRACKET);
            case S_RBRACKET:
                return do_special(token, RBRACKET);
            case S_COMMA:
                return do_special(token, COMMA);
            case S_LCOM:
                do_line_com();
                break;
            case S_ERROR:
                fprintf(stderr, "Neočekávaný znak '%c'!\n", symbol);
                return 1;
        }
    }
}
