/**
 * Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Debug file
 *
 * @author Viktoria Haleckova xhalec00
 *          
 */

#include "deb.h"

void deb_int(void* i) {
    if (i == NULL) {
        debug("%p", i);
    } else {
        debug("%d", *(int*) i);
    }
}

void deb_float(void* f) {
    if (f == NULL) {
        debug("%p", f);
    } else {
        debug("%g", *(float*) f);
    }
}
