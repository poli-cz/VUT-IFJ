/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Parser
 *
 * @author Peter Dragúň xdragu01
 *         Jakub Sadílek xsadil07
 */
#ifndef PARSER_H
#define PARSER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "scanner.h"
#include "m_manage.h"
#include "symtable.h"
#include "err.h"
#include "expression_parser.h"
#include "three_adress_code.h"
#include "inbuildfce.h"



#define RETEND -5 //return z stat_list v pripade ze posledny token bol end
#define RETELSE -6 //return z stat_list v pripade ze posledny token bol else

/*
 *Funkcia generuje unikatne ID, ktore sa pouzivaju v IFJcode18
 */
char *gen_u();


/*
 * Inicializacia pociatocnych struktur a kontrola na EOF na konci suboru. Spracovava chyby programu
 */
int prog();


/*
 * Spracuvava samotny kod zo vstupu.
 * ew(end when)
 * ew = 0 ->prikazy mimo cyklu
 * ew = 1 ->ocakava end
 * ew = 2 ->ocakava else
 * ltab = odkaz na lokalnu tabulku symbolov
 * def = sme v definici funkcie
 * l = miesto kam ulozit instrukcie v IFJcode18 (main,funcie...)
 * last_stat_ret = odkaz na meno premennej, kde je navratova hodnota posledneho prikazu
 */
int stat_list (int ew,localTable *ltab,int def,List* l,char **last_stat_ret);


/*
 * Spracovava jeden riadok kodu zo vstupu.
 * ltab = odkaz na lokalnu tabulku symbolov
 * def = sme v definici funkcie
 * l = miesto kam ulozit instrukcie v IFJcode18 (main,funcie...)
 * last_stat_ret = odkaz na meno premennej, kde je navratova hodnota posledneho prikazu
 */
int stat(localTable *ltab,int def,List* l,char **last_stat_ret);


/*
 * Vyhodnocuje hodnotu vyrazu. V priprade funckie vola func. V pripade vyrazu vola expression_parser
 * t = navratovy typ v pripade ze sa da nastavit implicitne
 * def = sme v definici funkcie
 * ltab = odkaz na lokalnu tabulku symbolov
 * expr_ret = odkaz na meno premennej, v ktorej je ulozeny vysledok z expression_parser
 */
int value (var_types *t, int def,List* l,localTable *ltab,char **expr_ret);


/*
 * Spracovava argumentovu cast volania funkcie
 * p = odkaz na linerny zoznam parametrov
 * l = miesto kam ulozit instrukcie v IFJcode18 (main,funcie...)
 * par_cnt = pocet parametrov, vyuziva sa v pripade funkcie print, kde je premenny pocet parametrov
 * ltab = odkaz na lokalnu tabulku symbolov
 */
int func(struct parameter *p,List *l,int *par_cnt,localTable *ltab);


/*
 * Spracovava mnozinu parametrov
 * p = odkaz na linerny zoznam parametrov
 * def = sme v definici funkcie
 * l = miesto kam ulozit instrukcie v IFJcode18 (main,funcie...)
 * par_cnt = pocet parametrov, vyuziva sa v pripade funkcie print, kde je premenny pocet parametrov
 * ltab = odkaz na lokalnu tabulku symbolov
 */
int param_list(struct parameter *p,int def,List *l, int *par_cnt,localTable *ltab);


/*
 * Spracovava jeden parameter
 * p = odkaz na linerny zoznam parametrov
 * def = sme v definici funkcie
 * l = miesto kam ulozit instrukcie v IFJcode18 (main,funcie...)
 * ltab = odkaz na lokalnu tabulku symbolov
 */
int param(struct parameter *p,int def,List *l,localTable *ltab);


/*
 * Pri volani funkcie vlozi parametre na zasobnik
 * p = odkaz na linerny zoznam parametrov
 * l = miesto kam ulozit instrukcie v IFJcode18 (main,funcie...)
 */
void push_par (struct parameter *p,List *l);



#endif
