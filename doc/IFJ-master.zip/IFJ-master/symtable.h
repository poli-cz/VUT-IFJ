/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Symtable
 *
 * @author Patricia Ramosova xramos00
 */

#ifndef _HASHTABLE_H_
#define _HASHTABLE_H_

#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef enum {
  T_NIL,
  T_INT,
  T_FLOAT,
  T_STRING,
  T_BOOL,
  T_ELSE,
  T_NDEF
}var_types;


// GLOBALNA TABULKA SYMBOLOV

struct parameter {
    var_types type;
    char* name;
    struct parameter* next;
};

struct global_symbol {
    char* name;
    struct parameter* par;
    struct global_symbol* next;
    bool isDeclared;
    bool isDefined;
};

typedef struct table {
    struct global_symbol* tHTable[12289];
    struct global_symbol* last;
}globalTable;


// LOKALNA TABULKA SYMBOLOV

struct local_symbol {
    var_types type;
    char* name;
    struct local_symbol* next;
};

typedef struct local_symbol* localTable[12289];



// DEKLARACIE FUNKCII
/**
 * spocita hodnotu hashovacej funkcie pre zadany kluc
 * @param kluc
 * @return hodnota hashovacej funkcie pre zadany kluc
 */
int hashCode ( char* key );

/**
 * Inicializuje globalnu tabulku
 * @param ukazatel na globalnu tabulku
 */
void global_Init(globalTable* ptr);

/**
 * Vyhlada v globalnej tabulke predanej ukazatelom kluc
 * @param ukazatel na globalnu tabulku
 * @param hladany kluc v tabulke
 * @return ukazatel na symbol, ktory obsahuje hladany kluc
 */
struct global_symbol* global_Search ( globalTable* ptr, char* key );

/**
 * Vlozi zadane meno globalneho symbolu do tabulky a nastavi symbol ako deklarovany
 * @param ukazatel na globalnu tabulku
 * @param ukazatel na meno globalneho symbolu
 */
void global_InsertDeclared ( globalTable* ptr, char* name);

/**
 * Vlozi zadane meno globalneho symbolu do tabulky a nastavi symbol ako definovany
 * @param ukazatel na globalnu tabulku
 * @param ukazatel na meno globalneho symbolu
 */
void global_InsertDefined ( globalTable* ptr, char* name);

/**
 * Zisti, ci je globalny symbol deklarovany
 * @param ukazatel na globalnu tabulku
 * @param kluc symbolu, ktory zistujeme ci je definovany
 * @return -1 ak symbol nie je v tabulke, 0 ak nie je deklarovany, 1 ak symbol deklarovany je
 */
int global_isDeclared (globalTable* ptr, char* key);

/**
 * Zisti, ci je globalny symbol definovany
 * @param ukazatel na globalnu tabulku
 * @param kluc symbolu, ktory zistujeme ci je definovany
 * @return -1 ak symbol nie je v tabulke, 0 ak nie je definovany, 1 ak symbol definovany je
 */
int global_isDefined (globalTable* ptr, char* key);

/**
 * Prida parameter do posledne definovaneho/deklarovaneho symbolu
 * @param ukazatel na globalnu tabulku
 * @param parameter, ktory chceme pridat
 * @return ukazatel na parameter
 */
struct parameter* global_addParam (globalTable *ptr, struct parameter* param);

/**
 * Inicializuje lokalnu tabulku
 * @param ukazatel na lokalnu tabulku
 */
void local_Init(localTable* ptr);

/**
 * Vyhlada v lokalnej tabulke predanej ukazatelom kluc
 * @param ukazatel na lokalnu tabulku
 * @param hladany kluc v tabulke
 * @return ukazatel na symbol, ktory obsahuje hladany kluc
 */
struct local_symbol* local_Search (localTable* ptr, char* key);

/**
 * Vlozi zadane meno lokalneho symbolu do tabulky a nastavi symbol ako deklarovany
 * @param ukazatel na lokalnu tabulku
 * @param ukazatel na meno lokalneho symbolu
 */
void local_InsertDeclared (localTable* ptr, struct local_symbol* symbol);

/**
 * Zisti, ci je lokalny symbol deklarovany
 * @param ukazatel na lokalnu tabulku
 * @param kluc symbolu, ktory zistujeme ci je definovany
 * @return 0 ak symbol nie je v tabulke, 1 ak je deklarovaný
 */
int local_isDeclared (localTable* ptr, char* key);


#endif
