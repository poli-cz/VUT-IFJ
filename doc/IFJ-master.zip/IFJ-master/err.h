//
//  err.h
//  IFJ projekt
//
//  
//

#ifndef err_h
#define err_h

#define SUCC 0

#define LEX_ERROR 1

#define SYNTH_ERROR 2

#define UNDEF_ERROR 3

#define TYPE_ERROR 4

#define PARAM_ERROR 5

#define SEM_ERROR 6

#define RUNN_ERROR 9

#define INTERN_ERROR 99


#endif /* err_h */
