/**
 * File is part of project IFJ2018.
 *
 * Brno University of Technology, Faculty of Information Technology
 *
 * @package IFJ2018
 * @authors
 */
#include "expression_parser.h"
#include "three_adress_code.h"
#include "parser.h"
#include "types.h"
#include "m_manage.h"
#include "symtable.h"
#include <assert.h>

#define GET_TOKEN_M(t)  err_no = get_token(t); if(err_no!=0){if(err_no == 1) return err_no;}
#define GET_TOKEN_M_EXPR(t) return_s->err_id = get_token(t);  if(return_s->err_id!=0){return return_s;}


char precedence_table[16][16] = {
    //          0id  1val 2(   3)   4+   5-   6*   7/   8\  9$   10= 11!=  12< 13<=  14> 15>=
    /* 0id  */ {'-', '-', '-', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    /* 1val */ {'-', '-', '-', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    /* 2(   */ {'<', '<', '<', '=', '<', '<', '<', '<', '<', '-', '<', '<', '<', '<', '<', '<'},
    /* 3)   */ {'-', '-', '-', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    /* 4+   */ {'<', '<', '<', '>', '>', '>', '<', '<', '<', '>', '>', '>', '>', '>', '>', '>'},
    /* 5-   */ {'<', '<', '<', '>', '>', '>', '<', '<', '<', '>', '>', '>', '>', '>', '>', '>'},
    /* 6*   */ {'<', '<', '<', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    /* 7/   */ {'<', '<', '<', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>', '>'},
    /* 8\   */ {'<', '<', '<', '>', '>', '>', '<', '<', '>', '>', '>', '>', '>', '>', '>', '>'},
    /* 9$   */ {'<', '<', '<', '-', '<', '<', '<', '<', '<', '-', '<', '<', '<', '<', '<', '<'},
    /* 10=  */ {'<', '<', '<', '>', '<', '<', '<', '<', '<', '>', '-', '-', '-', '-', '-', '-'},
    /* 11!= */ {'<', '<', '<', '>', '<', '<', '<', '<', '<', '>', '-', '-', '-', '-', '-', '-'},
    /* 12<  */ {'<', '<', '<', '>', '<', '<', '<', '<', '<', '>', '-', '-', '-', '-', '-', '-'},
    /* 13<= */ {'<', '<', '<', '>', '<', '<', '<', '<', '<', '>', '-', '-', '-', '-', '-', '-'},
    /* 14>  */ {'<', '<', '<', '>', '<', '<', '<', '<', '<', '>', '-', '-', '-', '-', '-', '-'},
    /* 15>= */ {'<', '<', '<', '>', '<', '<', '<', '<', '<', '>', '-', '-', '-', '-', '-', '-'},
};

extern const char *Data_Typ[];
extern globalTable *g_sym_table;
struct global_symbol *func_id = NULL;  
struct fce_param_list_item *parameter;
stToken *token;

void inst_fill(List* il,op_enum op,char*pref1,char *var1,char*pref2,char *var2,char*pref3,char *var3){
    Ad ad1,ad2,ad3;
    if ((var1==NULL)||(pref1 == NULL)) {
        ad1.t = AD_T_E;
        ad1.s = NULL;
    }else{
        ad1 = ad_for_symbol(pref1,var1);
    }
    if ((var2==NULL)||(pref2 == NULL)) {
        ad2.t = AD_T_E;
        ad2.s = NULL;
    }else{
        ad2 = ad_for_symbol(pref2,var2);
    }
    if ((var2==NULL)||(pref2 == NULL)) {
        ad3.t = AD_T_E;
        ad3.s = NULL;
    }else{
        ad3 = ad_for_symbol(pref3,var3);
    }
    Ins* i = init_ins(op,ad1,ad2,ad3);
    add_to_il(il, i);
}

struct global_symbol *g_search(char *k){
    assert(k!=NULL);
    unsigned int idx = HashCode(k);
    struct global_symbol  *temporary = g_sym_table->tHTable[idx];
    while(temporary != NULL){
        if (!strcmp(k,temporary->))
            return temporary;
        temporary = temporary->next;
    }
    return temporary;
    
}

expr_ret_type  *expr(List *l, int assign) {
    expr_ret_type *return_s = mm_malloc(sizeof(expr_ret_type));
    return_s->var_name = NULL;
    return_s->t = T_ELSE;
    return_s->err_id = 0;
    
    stToken *token_2 = token;
    if (assign == 1) {
        char *array[] = {"chr", "ord", "substr", "length", "printf", "inputs", "inputi", "inputf" };
        if (token_2->type == IDENTIFICATOR ||  strcmparray(token_2->value->str, array, 4)) {
            
            return_s->err_id = get_token(token);
            if (return_s->err_id != 0)
                return return_s;
            
            if (token->type == LBRACKET) {
                int res = function(); 
                return_s->err_id = res;
                if (res == 0) {
                    char *result = gen_u();
                    inst_fill(l,OP_DEFVAR, "LF@", result, NULL, NULL, NULL, NULL);
                    inst_fill(l, OP_POPS, "LF@",result, NULL, NULL, NULL, NULL);
                    return_s->var_name = result;
                    //struct global_symbol *g_s = g_search(token_2->value);
                    //return_s->t = data_type_from_str(g_s->);
                    
                }
                return return_s;
            }
        }
        else {
            if (!strcmp(token->value->str, "then") || (token->type == EOL) || token->type == COMMA) {
                
                return_s->err_id= 2;
                return return_s;
            }
            return_s->err_id = get_token(token);
            if (return_s->err_id != 0)
                return return_s;
        }
    }
    else {
        if (!strcmp(token->value->str, "then") || (token->type == EOL) || token->type == COMMA) {
            fprintf(stderr, "Nastala chyba! Vyraz je prazdny.\n");
            return_s->err_id = 2;
            return return_s;
        }
        return_s->err_id = get_token(token);
        if (return_s->err_id != 0)
            return return_s;
    }
    
    
    token_item *h = mm_malloc(sizeof(token_item));
    h->next_one = NULL;
    h->token_from_i = token_2;
    
    int left_c = 0;
    int right_c = 0;
    
    if(token_2->type == LBRACKET)
        left_c++;
    if(token->type == LBRACKET)
        left_c++;
    if(token->type == RBRACKET)
        right_c++;
    
    while (strcmp(token->value->str, "then") && (token->type != EOL) && token->type != COMMA && !(left_c<right_c)) {
        add_last_to_list(h);
        return_s->err_id = get_token(token);
        if (return_s->err_id != 0)
            return return_s;
        
        if(token->type == LBRACKET)
            left_c++;
        if(token->type == RBRACKET)
            right_c++;
    }

    st *s = mm_malloc(sizeof(st));

    s->array = mm_malloc(4 * list_size(h)*sizeof(st_item));
    s->t = -1;
    s->s = 4*list_size(h);
    int i = 0;
    while (i < s->s) {
        s->array[i] = NULL;
        i++;
    }
    
    p_b_stack(s);
    
    add_eof_to_list(h);
    
    token_item *it = h;
    st_item * tmp = make_item(it->token_from_i);
    if (tmp == NULL) {
        fprintf(stderr,"Nastala chyba! Neplatny vstupny symbol v expression parser.\n");
        return_s->err_id = 2;
        return return_s;
    }
    
    while(s->t != 1 || tmp->t != T_ST_BTM) {
        int inp_i = idx_from_it(tmp);
        if (inp_i == -1) {
            fprintf(stderr, "Nastala chyba! Vstupny symbol precedencnej tabulky SA je neznamy.\n");
            return_s->err_id = 2;
            return return_s;
        }
        
        int st_i = idx_from_it(s->array[search_for_top_t(s)]);
        
        if (precedence_table[st_i][inp_i] == '=') {
            p_it(s, tmp);
            it = it->next_one;
            tmp = make_item(it->token_from_i);
            if (tmp == NULL) {
                fprintf(stderr,"Nastala chyba! Neplatny vstupny symbol v expression parser.\n");
                return_s->err_id = 2;
                return return_s;
            }
            
        }
        else if (precedence_table[st_i][inp_i] == '<') {
            ins_less_item(s);
            p_it(s, tmp);
            it = it->next_one;
            tmp = make_item(it->token_from_i);
            if (tmp == NULL) {
                fprintf(stderr,"Nastala chyba! Neplatny vstupny symbol v expression parser.\n");
                return_s->err_id = 2;
                return return_s;
            }
        }
        else if (precedence_table[st_i][inp_i] == '>') {
            int res = reduction_rule(s);
            if (res != 0) {
                return_s->err_id = res;
                return return_s;
            }
        }
        else if (precedence_table[st_i][inp_i] == '-') {
            fprintf(stderr, "Nastala chyba! Nespravna kombinacia vstupneho symbolu  a najvyssieho terminalu na zasobniku.\n");
           return_s->err_id = 2;
            return return_s;
        }
        else {
            fprintf(stderr, "Nastala chyba! Nedefinovany stav.\n");
            return_s->err_id = 99;
            return return_s;
        }
    }
    
    return_s->var_name = s->array[s->t]->var_n;
    return_s->t = s->array[1]->d_type;
    return_s->err_id = 0;
    return return_s;
}

int function(stToken *t2, List *l) {
    
    int err_no;
    char *arr[] = {"chr", "ord", "substr", "length", "printf", "inputs", "inputi", "inputf"};
    if(t2->type != IDENTIFICATOR)
        if (!strcmparray(t2->value->str, arr, 4)){
            return 2;
        }
    if(token->type != LBRACKET){
        return 2;
    }
    GET_TOKEN_M(token)
    
    func_id = g_search(t2->value->str);
    if (func_id == NULL) {
        return 3;
    }
    //parameter = func_id->;
    //err = func_expr_list();
    
    if(err_no)
        return err_no;
    if(token->type != RBRACKET){
        if (parameter != NULL)
            return 4;
        return 2;
    }
    
    inst_fill(l, OP_CALL, "", t2->value->str, NULL, NULL, NULL, NULL);
    
    GET_TOKEN_M(token)
    return 0;
}

int function_expression_list(List *l) {
    if(token->type == RBRACKET){
        if (parameter != NULL)
            return 4;
        return 0;
    }
    
    char *arr[] = {"("};
    if(!(token->type == IDENTIFICATOR || token->type == STRING || token->type == INTEGER || token->type == DOUBLE || strcmparray(token->value->str, arr, 1) )) {
        return 2;
    }
    int err_no;
    
    if (parameter == NULL) {
        fprintf(stderr, "Nastala chyba! V definicii je menej parametrov ako pri volani funkcie.\n");
        return 4;
    }
    
    expr_ret_type *ret_st = expr(0);
    if (ret_st->err_id != 0)
        return ret_st->err_id;
    
    char *str = NULL;
    
    if(!strcmp(parameter->type->value, Data_Typ[ret_st->t])){
        str =ret_st->var_name;
    }
    else {
        str = conv_instr(parameter->type->value, ret_st->var_name, ret_st->t);
        if (str == NULL) {
            fprintf(stderr, "Nastala chyba! Nespravny typ parametra aj po aplikacii implicitnej konverzie.\n");
            return 4;
        }
    }
    parameter = parameter->next;
    err_no = function_expression_list_2();
    
    inst_fill(l, OP_PUSHS, "LF@", ret_st, NULL, NULL, NULL, NULL);
    
    return err;
}

int function_expression_list_2(List *l) {
    int err_no;
    if(token->type == RBRACKET){
        if (parameter != NULL)
            return 4;
        return 0;
    }
    if(token->type != COMMA){
        return 2;
    }
    GET_TOKEN_M(token)
    char *arr[] = {"("};
    if(!(token->type == IDENTIFICATOR || token->type == STRING || token->type == INTEGER || token->type == DOUBLE || strcmparray(token->value->str, arr, 1) )) {
        return 2;
    }
    
    if (parameter == NULL) {
        fprintf(stderr, "Nastala chyba! V definicii je menej parametrov ako pri volani funkcie.\n");
        return 4;
    }
    
    expr_ret_type *ret_st = expr(0);
    if (ret_st->err_id != 0)
        return ret_st->err_id;
    
    char *str = NULL;
    
    if(!strcmp(parameter->type->value, Data_Typ[ret_st->t])){
        str = ret_st->var_name;
    }
    else {
        str = conv_instr(parameter->type->value, ret_st->var_name, ret_st->t);
        if (str == NULL) {
            fprintf(stderr, "Nastala chyba! Nespravny typ parametra aj po aplikacii implicitnej konverzie.\n");
            return 4;
        }
    }
    parameter = parameter->next;
    err_no = func_expr_list2();
    
    inst_fill(l, OP_PUSHS, "LF@", ret_st, NULL, NULL, NULL, NULL);
    
    return err_no;
}

stToken *create_$_token(){
    stToken * pom = mm_malloc(sizeof(stToken));
    pom->value = mm_malloc(2*sizeof(char));
    pom->value[0] = '$';
    pom->value[1] = '\0';
    pom->type = T_EOF;
    return pom;
}

int list_size(token_item *h){
    if (h == NULL)
        return 0;
    int cnt = 1;
    while (h->next_one != NULL) {
        cnt++;
        h = h->next_one;
    }
    return cnt;
}


void add_last_to_list(token_item *h) {
    token_item *new_one = (token_item*) mm_malloc(sizeof(token_item));
    
    new_one->token_from_i = token;
    new_one->next_one = NULL;
    
    while (h->next_one != NULL) {
        h = h->next_one;
    }
    h->next_one = new_one;
    return;
}

int ret_t(token_item *it) {
    if (it == NULL) {
        fprintf(stderr,"Nastala chyba pri citani.\n");
        return 0;
    }
    return (int)it->token_from_i->type;
}

void add_eof_to_list(token_item *h) {
    token_item *new_one = (token_item*) mm_malloc(sizeof(token_item));
    
    new_one->token_from_i = create_$_token();
    new_one->next_one = NULL;
    
    while (h->next_one != NULL) {
        h = h->next_one;
    }
    h->next_one = new_one;
    return;
}

st_item *less_item(void) {
    st_item *new_one = mm_malloc(sizeof(st_item));
    new_one->t = T_L;
    new_one->d_type = T_ELSE;
    new_one->tok = NULL;
    new_one->isTerm = false;
    return new_on;
}


int search_for_top_t(st *s) {
    int i = s->t;
    while (i > -1) {
        if (s->array[i]->isTerm == true)
            return i;
        i--;
    }
    return i;
}


int search_less_item(st *s) {
    int i = s->t;
    while (i > -1) {
        if (s->array[i]->t == T_L)
            return i;
        i--;
    }
    return i;
}


void ins_less_item(st *s) {
    if ((s->t+1) == (s->s-1)) {
        fprintf(stderr,"Nastala chyba! Zasobnik sa pri vkladani symbolu '<' preplnil.\n");
        return;
    }
    
    int i;
    while (i > search_for_top_t(s)) {
        s->array[i+1] = s->array[i];
        i--;
    }
    
    s->array[i+1] = less_item();
    (s->t)++;
    return;
}


void p_b_stack(st *s) {
    st_item *new_one = mm_malloc(sizeof(st_item));
    new_one->t = T_ST_BTM;
    new_one->d_type = T_ELSE;
    new_one->tok = NULL;
    new_one->isTerm = true;
    p_it(s,new_one);
}


void p_it(st *s, st_item *it){
    if (s->t == (s->s - 1)) {
        fprintf(stderr,"Nastala chyba! Zasobnik expression parser je plny.\n");
        return;
    }
    
    s->array[++(s->t)] = it;
    return;
}


st_item *make_item(stToken *token){
    char *op[] = {"(",")","+","-", "*", "/", "\\"};
    char *rel_op[] =  {"=","!=","<","<=", ">", ">="};
    
    if (token == NULL) {
        fprintf(stderr,"Ukazatel na vstupny token nieje platny.\n");
        return NULL;
    }
    
    if (strcmparray(tok->value, op, 7)) {
        st_item *new_one = mm_malloc(sizeof(st_item)); ++init
        new_one->t = T_OP;
        new_one->tok = token;
        new_one->isTerm = true;
        return new_one;
    }
    else if (strcmparray(t->value, rel_op, 6)) {
        st_item * new_one = mm_malloc(sizeof(st_item));
        new_one->t = T_OP_REL;
        new_one->tok = token;
        new_one->isTerm = true;
        return new_one;
    }
    else if ((token->type == INTEGER) || (token->type == DOUBLE) || (token->type == STRING) || (token->type == IDENTIFICATOR)) {
        st_item *new_one = mm_malloc(sizeof(st_item));
        if (token->type == IDENTIFICATOR)
            new_one->t = T_ID;
        else
            new_one->t = T_VAL);
        new_one->tok = token;
        new_one->isTerm = true;
        return new_one;
    }
    else if (token->type == T_EOF)
        if (!strcmp(token->value,"$")) {
        st_item *new_one = mm_malloc(sizeof(st_item));
            new_one->t = T_ST_BTM;
            new_one->d_type = T_ELSE;
            new_one->tok =token;
            new_one->isTerm = true;
            return new_one;
        }
    else {
        return NULL;
    }
}

void print_s(st *s) {
    printf("Vypis hodnot na zasobniku:vrchol\n");
    int i = s->t;
    while (i > -1) {
        printf("%d. typ: %d\n", i, s->array[i]->t);
        i--;
    }
    printf("Spodok zasobnika, koniec vypisu.\n");
}


int reduction_rule(st *s, List *l){
    int tmp = search_less_item(s);
    if (tmp == (s->t - 1)) {
        if(T_ID == s->array[s->t]->t || T_VAL == s->array[s->t]->t ) {
            st_item *new = mm_malloc(sizeof(st_item));
            new->t = T_EXPR;
            
            if (s->array[s->t]->t == T_ID) {
                new->d_type = terminal_d_type(s->array[s->t]);
                new->var_n = s->array[s->t]->tok->value;
            }
            else {
                if (s->array[s->t]->tok->type == DOUBLE)
                    new->d_type = T_FLOAT;
                else if (s->array[s->t]->tok->type == INTEGER)
                    new->d_type = T_INT;
                else if (s->array[s->t]->tok->type == STRING)
                    new->d_type = T_STRING;
               // else if (s->array[s->t]->tok->type == NIL)
                    //new->d_type = T_NIL;
                else new->d_type = T_ELSE;
                char *var = gen_u();
                
                inst_fill(l, OP_DEFVAR, "LF@", tmp, NULL, NULL, NULL, NULL);
                if (s->array[s->t]->tok->type == STRING) {
                    inst_fill(l, OP_MOVE,"LF@", tmp, "string@", s->array[s->t]->tok->value->str, NULL, NULL);
                }
                else if(s->array[s->t]->tok->type == INTEGER) {
                    inst_fill(l, OP_MUL, "LF@", tmp, "int@", s->array[s->t]->tok->value->str, NULL, NULL);
                }
                else if(s->array[s->t]->tok->type == DOUBLE) {
                    inst_fill(l, OP_MOVE, "LF@", tmp, "float@", s->array[s->t]->tok->value->str, NULL, NULL);
                }
                new->var_n = tmp;
            }
            
            if(new->d_type == T_ELSE) {
                return 3;
            }
            
            new->tok = s->array[s->t]->tok;
            new->isTerm = false;
            s->array[--(s->t)] = new;
            
        }
        else {
            fprintf(stderr, "V expression_parser neexistuje redukcne pravidlo.\n");
            return 2;
        }
    }
    else if((s->t - 3) == tmp) {
        if(s->array[s->t]->t == T_EXPR)
            if (s->array[(s->t)-2]->t == T_EXPR)
                if (s->array[(s->t)-1]->t != NULL) {
                    if(s->array[(s->t)-1]->t == T_OP || s->array[(s->t)-1]->t == T_OP_REL) {
                
                        st_item *new_item = type_control(l, s->array[(s->t)-2], s->array[s->t], s->array[(s->t)-1]->tok);
                        if(new_item == NULL) {
                            fprintf(stderr, "Nastala chyba! Operatory su nekompatibilne.\n");
                            return 4;
                        }
                        new_item->tok = s->array[(s->t)-1]->tok;
                        s->t -= 3;
                        s->array[s->t] = new_item;
                }
                else {
                    fprintf(stderr, "Neexistuje pravidlo pre operator %d\n", s->array[s->t]->t);
                    return 2;
                }
        }
        else if (s->array[(s->t)-1]->t == T_EXPR)
            if (s->array[(s->t)-2]->t == T_OP)
                if (s->array[s->t]->t == T_OP) {
                    if (!strcmp(s->array[(s->t)-2]->tok->value,"("))
                        if (!strcmp(s->array[s->t]->tok->value,")")) {
                            s->array[(s->t)-3] = s->array[(s->t)-1];
                            s->t -=3;
                        }
            else {
                fprintf(stderr, "Neexistuje pravidlo pre operatory %d, %d\n", s->array[(s->t)-2]->t, s->array[s->t-2]->t);
                return 2;
            }
        }
        else {
            fprintf(stderr, "Nespravna konstalacia pre aplikaciu pravidla.\n");
            return 2;
        }
    }
    else {
        fprintf(stderr, "V expression_parser neexistuje redukcne pravidlo.\n");
        return 2;
    }
    
    return 0;
}

int idx_from_it(st_item *it){
    if (it->t == T_ID)
        return 0;
    else if(it->t == T_VAL)
        return 1;
    else if(it->t == T_OP) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, "("))
                return 2;
    }
    else if(it->t == T_OP) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, ")"))
                return 3;
    }
    else if(it->t == T_OP) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, "+"))
                return 4;
    }
    else if(it->t == T_OP) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, "-"))
                return 5;
    }
    else if(it->t == T_OP) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, "*"))
                return 6;
    }
    else if(it->t == T_OP) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, "/"))
                return 7;
    }
    else if(it->t == t_op) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, "\\"))
                return 8;
    }
    else if(it->t == T_ST_BTM)
        return 9;
    else if(it->t == T_OP_REL) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, "="))
                return 10;
    }
    else if(it->t == T_OP_REL) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, "!="))
                return 11;
    }
    else if(it->t == T_OP_REL) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, "<"))
                return 12;
    }
    else if(it->t == T_OP_REL) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, "<="))
                return 13;
    }
    else if(it->t == T_OP_REL) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, ">"))
                return 14;
    }
    else if(it->t == T_OP_REL) {
        if (it->tok != NULL)
            if (!strcmp(it->tok->value->str, ">="))
                return 15;
    }
    else return -1;
}

type_of_data terminal_d_type(st_item *it) {
    //struct local_sym_htab * top_frame_stack = local_frame_stack_return();
    struct local_sym_item * symtab_item = local_htab_search(item->t->value);
    if (symtab_item == NULL) {
        fprintf(stderr, "ERR: premenna %s nedefinovana!\n", item->t->value);
        return t_else;
    }
    
    if (!strcmp(symtab_item->type->value, "integer")) {
        return t_int;
    }
    else if (!strcmp(symtab_item->type->value, "double")) {
        return t_double;
    }
    else if (!strcmp(symtab_item->type->value, "string")) {
        return t_string;
    }
    else{
        fprintf(stderr, "ERR: premenna neznameho typu!\n");
        return t_else;
    }
}


type_of_data data_type_from_str(char * val) {
    if (!strcmp(val, "integer"))
        return 0;
    else if(!strcmp(val, "double"))
        return 1;
    else if(!strcmp(val, "string"))
        return 2;
    else return 4;
}
