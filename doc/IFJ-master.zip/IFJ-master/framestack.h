/**
 * Project: Implementácia prekladača imperatívneho jazyka IFJ18.
 *
 * @brief Framestack
 *
 * @author Patricia Ramosova xramos00
 */

#ifndef _FRAMESTACK_H_
#define _FRAMESTACK_H_


#include "symtable.h"


struct frame {
    struct localTable* table;
    struct frame* next;
};

struct framestack {
    struct frame* last;
};


struct frame* pushFrame (struct framestack* ptr_stack, struct frame* ptr_frame);

void popFrame (struct framestack* ptr);

struct frame* topFrame (struct framestack* ptr);

bool isFrameStackEmpty (struct framestack* ptr);


#endif