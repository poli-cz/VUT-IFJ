/**
 * File is part of project IFJ2018.
 *
 * Brno University of Technology, Faculty of Information Technology
 *
 * @package IFJ2018
 * @authors
 */

#ifndef IFJ18_COMPILER_DEBUG_H
#define IFJ18_COMPILER_DEBUG_H

#include <stdio.h>

#ifndef NDEBUG

#define debugs(s) fprintf(stderr, "%s", s);
#define debug(format, ...) fprintf(stderr, format, __VA_ARGS__);

#else

#define debugs(s)
#define debug(format, ...)

#endif

typedef void (*debug_func) (void*);

/**
 * Debug integer value
 * @param i int
 */
void deb_int(void* i);

/**
 * Debug double value
 * @param f float
 */
void deb_float(void* f);

#endif //IFJ18_COMPILER_DEBUG_H
