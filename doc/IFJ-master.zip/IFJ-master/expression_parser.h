/**
 * File is part of project IFJ2018.
 *
 * Brno University of Technology, Faculty of Information Technology
 *
 * @package IFJ2018
 * @authors
 */
#ifndef EXPR_PARSER_H
#define EXPR_PARSER_H

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "scanner.h"
#include <string.h>
#include "types.h"
#include "symtable.h"
#include "framestack.h"
#include "three_adress_code.h"

extern char precedence_table[16][16];

extern struct local_frame_stack *local_stack;
extern int strcmparray(char *retazec, char **pole, int len);

stToken *token;

/**
 * Return type of expression
 */
typedef struct expr_return {
    char *var_name; //name of variable
    var_types t; //data type of return
    int err_id; //identificator in case of error
}expr_ret_type;

struct global_symbol *g_search(char *k);

/**
 * Main function to evaluate expressions
 * @param assign switch
 * @return expr_ret_type
 */
expr_ret_type *expr(List *l, int assign);

/**
 * Enum of st_item types
 */
typedef enum {
    T_ID,
    T_VAL,
    T_OP,
    T_OP_REL,
    T_ST_BTM,
    T_L,
    T_EXPR
} st_item_type;

/**
 * Item in list of tokens from input
 */
typedef struct token_listitem {
    stToken *token_from_i;
    struct token_item *next_one;
}token_item;

/**
 * Adds item to the end of list
 * @param it Item to add
 */
void add_last_to_list(token_item *it);

/**
 * Creates token $ - means end of input file
 * @return stToken
 */
stToken *create_$_token(void);

/**
 * Adds $ to the end of list - $ means end of input file
 * @param h $ to add
 */
void add_eof_to_list(token_item * h);

/**
 * Returns token type of item
 * @param it Item
 * @return Integer
 */
int ret_t(token_item *it);

/**
 * Returns size of list
 * @param h Pointer to the first item of list
 * @return Integer
 */
int list_size(token_item *h);

/**
 * Function for recursion, simulation of rule
 * @return Integer
 */
int function(stToken *t2, List *l);

/**
 * Function for recursion, simulation of rule
 * @return Integer
 */
int function_expression_list(List *l);

/**
 * Function for recursion, simulation of rule
 * @return Integer
 */
int function_expression_list_2(List *l);

/**
 * Stack item
 */
typedef struct stack_item {
    st_item_type t; //type of item
    type_of_data d_type; //type of data
    stToken *tok; //token
    bool isTerm; //if value is terminal
    char *var_n; //name of temporary variable
}st_item;

/**
 * Stack of precedence table
 */
typedef struct stack{
    st_item **array; //array of item pointers
    int t; //pointer to the top
    int s; //size of stack
}st;

/**
 * Creates item '<' for stack
 * @return pointer to item '<'
 */
st_item *less_item(void);

/**
 * Finds top terminal of stack
 * @param s Pointer to stack
 * @return index, in case of error returns -1
 */
int search_for_top_t(st *s);

/**
 * Finds nearest '<' to the top of stack
 * @param s Pointer to stack
 * @return index, in case of error returns -1
 */
int search_less_item(st *s);

/**
 * Inserts '<' to array
 * @param s Pointer to stack
 */
void ins_less_item(st *s);

/**
 * Push bottom of stack to stack
 * @param s Pointer to stack
 */
void p_b_stack(st *s);

/**
 * Push item to stack
 * @param s Pointer to stack
 * @param i Pointer to item
 */
void p_it(st *s, st_item *i);

/**
 * Creates item
 * @param token Pointer to token
 * @return Pointer to item
 */
st_item *make_item(stToken *token);

/**
 * Applies rule for reduction of stack
 * @param s Pointer to stack
 * @return 1 if successfully, otherwise 0
 */
int reduction_rule(st *s, List *l);

/**
 * Prints all values of stack, from top to bottom
 * @param s Pointer to stack
 */
void print_s(st *s);

/**
 * Makes index in precedence table from item in stack
 * @param it Pointer to item
 * @return index in precedence table
 */
int idx_from_it(st_item *it);

/**
 * Gets data type of terminal
 * @param it Pointer to item
 * @return data type, t_else for undefined (err3)
 */
type_of_data terminal_d_type(st_item *it);

/**
 * Gets data type from string
 * @param val String
 * @return data type
 */
type_of_data data_type_from_str(char *val);


#endif

